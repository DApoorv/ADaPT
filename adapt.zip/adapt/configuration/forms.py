from flask_wtf import FlaskForm
from wtforms import SubmitField, FileField, StringField, SelectField, PasswordField, HiddenField, validators
from flask_wtf.file import DataRequired, FileAllowed, FileRequired
from wtforms.fields.core import SelectFieldBase, SelectField
from wtforms.validators import InputRequired
from markupsafe import escape, Markup
from wtforms.widgets import html_params
from wtforms.compat import text_type

class CustomSelect(object):
    """
    Renders a select field.

    If `multiple` is True, then the `size` property should be specified on
    rendering to make the field useful.

    The field must provide an `iter_choices()` method which the widget will
    call on rendering; this method must yield tuples of
    `(value, label, selected)`.
    """
    def __init__(self, multiple=False):
        self.multiple = multiple

    def __call__(self, field, **kwargs):
        kwargs.setdefault('id', field.id)
        if self.multiple:
            kwargs['multiple'] = True
        if 'required' not in kwargs and 'required' in getattr(field, 'flags', []):
            kwargs['required'] = True
        html = ['<select %s>' % html_params(name=field.name, **kwargs)]
        for val, label, selected in field.iter_choices():
            html.append(self.render_option(val, label, selected))
        html.append('</select>')
        return Markup(''.join(html))

    @classmethod
    def render_option(cls, value, label, selected, **kwargs):
        if value is True:
            # Handle the special case of a 'True' value.
            value = text_type(value)

        options = dict(kwargs, value=value)
        if selected:
            options['selected'] = True
        if label not in ['Google Cloud Platform', 'Microsoft Azure', 'OnPremises', 'Amazon Web Services']:
            return Markup('<option %s>%s</option>' % (html_params(**options), escape(label)))
        return Markup('<option %s disabled>%s</option>' % (html_params(**options), escape(label)))

class CustomSelectField(SelectField):
    widget = CustomSelect()


class TSFormOrch(FlaskForm):
    form_name = HiddenField(default="ts_form")
    etl_name = StringField("ETL Name", validators=[InputRequired()])
    # test_script_loc = FileField("Test Script Location", validators=[InputRequired()])
    test_objective_path = SelectField("Select Test Script", validators=[InputRequired()], choices=[("", "Select Test Script")])
    test_objective_sheet_name = StringField("Objective Sheet Name", validators=[InputRequired()])
    pipeline_sheet_name = StringField("Pipeline Sheet Name", validators=[InputRequired()])
    # src_ftype = SelectField("Source File Type", validators=[InputRequired()], choices=[("", "Select File Type"), (".csv", ".csv"), (".excel", ".excel"), (".paraquet", ".paraquet")])
    # tgt_ftype = SelectField("Target File Type", validators=[InputRequired()], choices=[("", "Select File Type"), (".csv", ".csv"), (".excel", ".excel"), (".paraquet", ".paraquet")])
    submit = SubmitField()


class TSForm(FlaskForm):
    identifier = HiddenField(default="ts_form")
    form_type = HiddenField(default="manual")
    etl_name = StringField("ETL Name", validators=[InputRequired()])
    # test_script_loc = FileField("Test Script Location", validators=[InputRequired()])
    test_script_path = SelectField("Select Test Script", validators=[InputRequired()], choices=[("", "Select Test Script")])
    # src_ftype = SelectField("Source File Type", validators=[InputRequired()], choices=[("", "Select File Type"), (".csv", ".csv"), (".excel", ".excel"), (".paraquet", ".paraquet")])
    # tgt_ftype = SelectField("Target File Type", validators=[InputRequired()], choices=[("", "Select File Type"), (".csv", ".csv"), (".excel", ".excel"), (".paraquet", ".paraquet")])
    submit = SubmitField()


class ConfigureF2DB(FlaskForm):
    identifier = HiddenField(default='dbform')
    path = SelectField("Select Test Script", validators=[InputRequired()],
                                   choices=[("", "Select Test Script")])
    TestScriptName = StringField("Test Script Location", validators=[DataRequired()])
    Bucket = StringField("Bucket Name", validators=[DataRequired()])
    Directory = StringField("Directory", validators=[DataRequired()])
    FileName = StringField("ETL Name", validators=[DataRequired()])
    FileType = StringField("File Type", validators=[DataRequired()])
    Host = StringField("Database Host", validators=[DataRequired()])
    Port = StringField("Database Port", validators=[DataRequired()])
    DbName = StringField("Database Name", validators=[DataRequired()])
    UserName = StringField("User Name", validators=[(DataRequired())])
    Password = PasswordField("Password", validators=[(DataRequired())])
    Project = StringField("Project", validators=[DataRequired()])
    Server = StringField("Server", validators=[DataRequired()])
    ServiceAccount = StringField("Service Account", validators=[DataRequired()])
    ServiceKeyPath = StringField("Service Key Path", validators=[DataRequired()])
    Token = StringField("Token", validators=[DataRequired()])
    UserAccount = StringField("UserAccount", validators=[DataRequired()])
    UserKeyPath = StringField("UserKeyPath", validators=[(DataRequired())])
    platform = CustomSelectField("Platform",choices=[('Select Platform', 'Select Platform')]  ,id="platform")
    services = SelectField("Services", choices=[('Select Services', 'Select Services')], validators=[DataRequired()], id="services")
    target_platform = CustomSelectField("Platform", choices=[('Select Platform', 'Select Platform')], id="target_platform")
    target_services = SelectField("Services", choices=[('Select Services', 'Select Services')], validators=[DataRequired()], id="target_services")
    configure = SubmitField("Submit")


class ConfigureOrch(FlaskForm):
    form_name = HiddenField(default='orch')
    identifier = StringField()
    Host = StringField("Host", validators=[DataRequired()])
    UserName = StringField("UserName", validators=[(DataRequired())])
    Password = PasswordField("Password", validators=[(DataRequired())])
    RegionName = StringField("Region Name", validators=[(DataRequired())])
    ProfileName = StringField("Profile Name", validators=[(DataRequired())])
    test_objective_path = StringField("Test Objective Path", validators=[(DataRequired())])
    test_objective_sheet_name = StringField("Test Objective Sheet Name", validators=[(DataRequired())])
    pipeline_sheet_path = StringField("Pipeline Sheet Path", validators=[(DataRequired())])
    pipeline_sheet_name = StringField("Pipeline Sheet Name", validators=[(DataRequired())])

    #result = SelectField("Select Result Storage", validators=[InputRequired()], choices=[("", "Select result storage")])
    submit = SubmitField("Submit")


class ConfigureF2FSource(FlaskForm):
    form_name = HiddenField(default="src")
    platform = SelectField("Select Platform", validators=[InputRequired()], choices=[("", "Select platform")], id="f2f-src-platform")
    service = SelectField("Select service", validators=[InputRequired()], choices=[("", "Select service")], id="f2f-src-service")
    # filepath = StringField("Filepath", validators=[InputRequired()], id="f2f-src-filepath")
    save = SubmitField("Save", id="f2f-src-submit")


class ConfigureF2FTarget(FlaskForm):
    form_name = HiddenField(default="tgt")
    platform = SelectField("Select Platform", validators=[InputRequired()], choices=[("", "Select platform")], id="f2f-tgt-platform")
    service = SelectField("Select service", validators=[InputRequired()], choices=[("", "Select service")], id="f2f-tgt-service")
    # filepath = StringField("Filepath", validators=[InputRequired()], id="f2f-tgt-filepath")
    save = SubmitField("Save", id="f2f-tgt-submit")

class ConfigureX2X(FlaskForm):
    form_type = HiddenField(default='manual')
    identifier = HiddenField(default='configure-etl-endpoints')
    platform = SelectField("Select platform", validators=[InputRequired()], choices=[("", "Select platform")])
    service = SelectField("Select service", validators=[InputRequired()], choices=[("", "Select service")])
    mannualORapi = StringField(label='Source data to be fetched from API ?', validators=[validators.InputRequired()])
    url = StringField(label='URL-Endpoint:',validators=[validators.InputRequired()])
    ingestionType = StringField(label='Ingestion Type:',validators=[validators.InputRequired()])
    sourceName = StringField(label='Source Name:', validators=[validators.InputRequired()])
    configure = SubmitField("Save")
    submit = SubmitField("Submit")

class APIForm(FlaskForm):
    form_type = HiddenField(default='api')
    identifier = HiddenField(default='configure-etl-endpoints')
    url = StringField('URL', validators=[InputRequired()])
    ingestionType = SelectField('Ingestion Type:', validators=[InputRequired()], choices=[("", "Select Ingestion Type")])
    sourceName = SelectField('Source Name:', validators=[InputRequired()],choices=[("", "Select Source Name")])
    conn_db_name = SelectField('Database Names:', validators=[InputRequired()], choices=[("", "Select Database Type")])
    conn_url_type = SelectField("Connection Urls:", validators=[InputRequired()], choices=[("", "Select Connection Urls")])
    conn_type = StringField('Connection Type', validators=[InputRequired()])
    configure = SubmitField("Save")



class SingleFileUploadForm(FlaskForm):
    identifier = StringField()
    file = FileField("Upload File", validators=[FileRequired("File needs to be selected")])
    upload = SubmitField("Upload")

    
class TestForm(SingleFileUploadForm):
    t_file = FileField("Source-to-Column mapping sheet: ", validators=[FileRequired("File needs to be selected"),
                                                                       FileAllowed(['xlsx'],
                                                                                   "WRONG FILETYPE: Allowed file type= xlsx")])
    etl_name = StringField("ETL Name", validators=[(DataRequired())])
    upload = SubmitField("Upload")

class AutoTestForm(SingleFileUploadForm):
    pass

class ManualTestForm(SingleFileUploadForm):
    pass

class DbForm(FlaskForm):
    identifier = HiddenField()
    Bucket = StringField("Bucket Name", validators=[DataRequired()])
    Directory = StringField("Directory", validators=[DataRequired()])
    FileName = StringField("File Name", validators=[DataRequired()])
    Host = StringField("Database Host", validators=[DataRequired()])
    Port = StringField("Database Port", validators=[DataRequired()])
    DbName = StringField("Database Name", validators=[DataRequired()])
    UserName = StringField("User Name", validators=[(DataRequired())])
    Password = PasswordField("Password", validators=[(DataRequired())])
    Project = StringField("Project", validators=[DataRequired()])
    Server = StringField("Server", validators=[DataRequired()])
    ServiceAccount = StringField("Service Account", validators=[DataRequired()])
    ServiceKeyPath = StringField("Service Key Path", validators=[DataRequired()])
    Token = StringField("Token", validators=[DataRequired()])
    UserAccount = StringField("UserAccount", validators=[DataRequired()])
    UserKeyPath = StringField("UserKeyPath", validators=[(DataRequired())])
    platform = CustomSelectField("Platform",choices=[('Select Platform', 'Select Platform')]  ,id="platform")
    services = SelectField("Services", choices=[('Select Services', 'Select Services')], validators=[DataRequired()], id="services")
    target_platform = CustomSelectField("Platform", choices=[('Select Platform', 'Select Platform')], id="target_platform")
    target_services = SelectField("Services", choices=[('Select Services', 'Select Services')], validators=[DataRequired()], id="target_services")
    configure = SubmitField("Configure")


class Overview(FlaskForm):
    validate = SubmitField("Submit")
