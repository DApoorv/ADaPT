from flask import Blueprint
from globals.exporter import FileExporter
from .view import *
from .models import TestEnvironment, Stage
from .view.configurationcollectors.file2fileconfigcollector import F2FConfigCollector
from .view.configurationcollectors.file2dbconfigcollector import F2DBConfigCollector
from .view.configurationcollectors.getApiAll import GetAPIAll
from .view.configurationcollectors.getApiF2db import GetAPIF2DB
from .view.configurationcollectors.getApiSFDC2db import GetAPISFDC2DB
from .view.configurationcollectors.getApiDb2Db import GetAPIDB2DB
from .view.configurationcollectors.sfdc2dbconfigcollector import SFDC2DBConfigCollector

default = Blueprint('configuration', __name__)

# Home Page
default.add_url_rule('/index', view_func=index, methods=['GET'])

# Setup Page
default.add_url_rule('/setup', view_func=setup, methods=['GET', 'POST'])

# Configuration Applications
default.add_url_rule('/app_config', view_func=add_app_configuration, methods=['GET'])
default.add_url_rule('/app_config/page1', view_func=configureApp_page, methods=['GET'])
default.add_url_rule('/app_config', view_func=save_app_configuration, methods=['POST'])
# default.add_url_rule('/app_config', view_func=AppConfigCollector.as_view('appconfig'))
default.add_url_rule('/app_config/view', view_func=view_config, methods=['GET'])

# Configure Validators
default.add_url_rule('/val_config/page2', view_func=configureVal_page, methods=['GET'])
default.add_url_rule("/val_config/db2db", view_func=DB2DBConfigCollector.as_view('db_field'))
default.add_url_rule("/val_config/f2f", view_func=F2FConfigCollector.as_view('f2f_field'))
default.add_url_rule("/val_config/f2db", view_func=F2DBConfigCollector.as_view('f2db_field'))
default.add_url_rule("/val_config/sfdc2db", view_func=SFDC2DBConfigCollector.as_view('sfdc2db_field'))
default.add_url_rule('/val_config/view', view_func=view_endpt_conf, methods=['GET'])

# API Level Integration
default.add_url_rule("/adaptAPI/db2db", view_func=GetAPIDB2DB.as_view('apiResponse'))
default.add_url_rule("/adaptAPI/f2db", view_func=GetAPIF2DB.as_view('apiF2DB'))
default.add_url_rule("/adaptAPI/sfdc2db", view_func=GetAPISFDC2DB.as_view('apiSFDC2DB'))
# default.add_url_rule("/adaptAPI/get/all", view_func=GetAPIAll.as_view('apiAll'))


default.add_url_rule("/configure/orch_val", view_func=configure_orch, methods=["GET", "POST"])

# Test Doc Page
default.add_url_rule('/upload', view_func=FileCollector.as_view('filecollector'))
default.add_url_rule('/download/<path:filepath>', view_func=FileExporter.as_view('exporter'), methods=['GET'])


@default.app_context_processor                                                        
def inject_template_globals():                                                   
    envlist=TestEnvironment.list_environments()
    stagelist=Stage.list_stages()
    try:
        username = session['user']
    except:
        username = None
    return dict(envlist=envlist, stagelist=stagelist, username=username)