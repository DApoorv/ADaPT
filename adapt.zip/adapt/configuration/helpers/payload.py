from datetime import datetime

from wtforms.fields.simple import PasswordField
from execution.models import DbConfigModel
from utils.objectfactory import ob

class Payload:
    def __init__(self, etl):
        if etl:
            self.conf = {
                "etl_id": etl.etl_name,
                "etl_run_id": etl.etl_run_id,
                "etl_service": etl.etl_service,
                "trigger_perform": etl.trigger_perform,
                "trigger_orch": etl.trigger_orch,
                "trigger_val": etl.trigger_val, 
                "val_type": etl.val_type
            }
            self.orch = self.payload_orch()
            self.perf = self.payload_perf()
            self.val = self.payload_val()
        else:
            self.payload = {}
        

    def payload_orch(self):
        
        payload = {
            "dag_run_id": ob.create('dags', val_type='orch').dag + ''.join(str(datetime.now()).split()),
            "conf": {
                **self.conf,
                "pipeline_sheet_path": "",
                "pipeline_sheet_name": "",
                "test_script_path": "",
                "test_script_name": "",
                "orchestrator_tool": "",
                "db_config": {}
            }
        }
        
    def payload_val(self):
        pass

    def payload_perf(self):
        pass