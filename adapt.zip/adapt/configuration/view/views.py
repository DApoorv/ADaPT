# encoded in UTF-8
import ast
from email import message
from operator import and_, or_

from configuration.view.appconfigcollector import *
from utils.defaults import validate_request
# from boto3 import resource
from db import dbf_obj
from configuration.models import *
from datetime import datetime
from flask import request, render_template, session, redirect, url_for, flash, g
from werkzeug.security import generate_password_hash
from globals.constants import *
from utils.serviceprovider import sp
from pathlib import Path
from configuration.forms import *
import json
from itertools import chain
from werkzeug.utils import secure_filename
from sqlalchemy import desc
from execution.models import MasterConfig, APIresponse, APIF2DB
from utils.objectfactory import ob
from globals.constants import *
from utils.serviceprovider import sp
from pathlib import Path


def index():
    return render_template('home.html')


def setup():
    """:returns the index or the landing page with test environment and stages list
    sets session variables for platform and stage"""
    if not session.get('user'):
        return redirect(url_for('user.login_first'))
    if request.method == 'GET':
        # setting user session
        username = session["user"]
        # print("_"*10+"printing"+"_"*10, "\n", session['environment'], session['stage'])
        return render_template("configuration/setup.html",
                               # username=username,
                               envlist=TestEnvironment.list_environments(),
                               stagelist=Stage.list_stages())
    elif request.method == 'POST':
        # setting platform and stage in session
        session['environment'] = request.form['env']
        session['stage'] = request.form['stage']
        # print(url_for('configuration.get_app_configuration'))
        flash('Environment set to: ' + str(session['environment']) + ' and stage set to: ' + str(session['stage']))
        # return redirect(url_for('configuration.add_app_configuration'))
        return redirect(url_for('configuration.view_config'))


@validate_request
def add_app_configuration():
    """
    :return: renders the Application Configuration page for adding configuration
    """
    # redirecting to login page if username is not found in session
    if not session.get('user'):
        return redirect(url_for('user.login'))

    # getting the current user
    username = session['user']
    # handling GET requests
    if request.method == 'GET':
        # if environment and stage are not set and redirect to set them
        if not session.get('environment') or not session.get('stage'):
            flash('Please select environment and stage to proceed')
            return redirect(url_for('configuration.setup'))
        # loading the fresh app config page
        if not request.args:
            # fetching platforms those have listed services
            platforms = Platform.query.select_from(Platform).join(Services).where(
                Platform.platform_name != 'NA').with_entities(Platform.platform_name).all()
            # prep-step
            platform_list = [platform[0] for platform in platforms]
            return render_template('configuration/app_config.html',
                                   platforms=platform_list)
        # getting val and data attributes from the requests
        # the val attribute identifies the type of data coming in
        # the data attribute contains actual data
        val = request.args.get('val')
        data = request.args.get('data')

        # processing for etl configuration section of app config page
        if val == 'etl':
            etl = request.args.get('data')
            session['etl_service'] = etl
            conn_details = Services.query.where(Services.service_name == etl).with_entities(
                Services.connection_details).all()
            det = conn_details[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            print(type(conn_det_list))
            return json.dumps(conn_det_list)

        elif val == 'etl-platform':
            session['etl_platform'] = data
            services = Services.query.select_from(Services).join(Platform).where(
                Platform.platform_name == data
            )
            etl_services = services.where(Services.type_id == 5).with_entities(Services.service_name).all()
            # prep-step
            print(etl_services, type(etl_services))
            etl_service_list = [storage_service[0] for storage_service in etl_services]
            return json.dumps(etl_service_list)

        # processing for test doc section of app config page
        elif val == 'testdoc-platform':
            session['testdoc_platform'] = data
            services = ServiceType.query.select_from(ServiceType).join(Services).join(Platform).where(
                Platform.platform_name == data
            )
            service_types = services.where(ServiceType.type_id != 5).with_entities(
                ServiceType.service_type
            ).all()
            service_type_list = [service_type[0] for service_type in service_types]
            return json.dumps(service_type_list)

        elif val == 'testdoc-servtype':
            platform = session['testdoc_platform']
            services = Services.query.select_from(Services).join(Platform).where(
                Platform.platform_name == platform).join(ServiceType).where(
                ServiceType.service_type == data).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]
            return json.dumps(service_list)

        elif val == 'testdoc-service':
            session['testdoc_service'] = data
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = det.get('connection_details')
            # conn_det_list = list(chain(*conn_details_list))
            conn_det_list = list(conn_details_list)
            return json.dumps(conn_det_list)

        # processing for test result section of app config page
        elif val == 'testresult-platform':
            session['testresult_platform'] = data
            services = Services.query.join(Platform).where(
                and_(
                    or_(
                        Platform.platform_name == data,
                        Platform.platform_name == 'NA'
                    ),
                    Services.type_id.in_([2, 3, 4, 6])
                )
            ).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]

            return json.dumps(service_list)

        elif val == 'testresult-service':
            session['testresult_service'] = data
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = [val for key, val in det.items()]
            # quickfix
            conn_det_list = list(chain(*conn_details_list))
            if 'Table Name' in conn_det_list:
                conn_det_list.remove('Table Name')
                conn_det_list.extend(['Table Name (f2db )', 'Table Name (db2db)', 'Table Name (sfdc2db)'])
                # conn_det_list.extend(['Table Name (f2db)', 'Table Name (db2db)', 'Table Name (orch)'])
                # conn_det_list.extend(['Table Name (db2db)'])
            return json.dumps(conn_det_list)

        # Mismatch record app_config page
        elif val == 'mismatch-record-platform':
            session['mismatch-record-platform'] = data
            services = ServiceType.query.select_from(ServiceType).join(Services).join(Platform).where(
                Platform.platform_name == data)
            service_types = services.where(ServiceType.type_id != 5).with_entities(ServiceType.service_type).all()
            service_type_list = [service_type[0] for service_type in service_types]  # need to change here
            return json.dumps(service_type_list)

        elif val == 'mismatch-record-storage-type':
            platform = session['mismatch-record-platform']
            services = Services.query.select_from(Services).join(Platform).where(
                Platform.platform_name == platform).join(ServiceType).where(
                ServiceType.service_type == data).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]
            return json.dumps(service_list)

        elif val == 'mismatch-record-storage-service':
            session['mismatch-record-storage-service'] = data
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = det.get('connection_details')

            # conn_det_list = list(chain(*conn_details_list))
            conn_det_list = list(conn_details_list)
            return json.dumps(conn_det_list)

        # Metrics Storage app_config.html
        elif val == 'metrics-platform':
            session['metrics_platform'] = data
            services = Services.query.where(Services.type_id.in_([3, 4, 6])).join(Platform).where(or_(
                Platform.platform_name == data, Platform.platform_name == 'NA')
            ).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]
            if data == 'Amazon Web Services':
                service_list = ['Postgresql']
            return json.dumps(service_list)

        elif val == 'metrics-service':
            session['metrics_service'] = data
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            return json.dumps(conn_det_list)

        # Metadata Storage
        elif val == 'metadata-platform':
            session['metadata_platform'] = data
            services = Services.query.where(Services.type_id.in_([3, 4, 6])).join(Platform).where(or_(
                Platform.platform_name == data, Platform.platform_name == 'NA')
            ).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]
            if data == 'Amazon Web Services':
                service_list = ['Postgresql']
            return json.dumps(service_list)

        elif val == 'metadata-service':
            session['metadata_service'] = data
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            conn_det_list.remove('Table Name')
            return json.dumps(conn_det_list)


def save_app_configuration():
    """
        :return: save the Application Configuration
    """
    # handling post requests
    if request.method == 'POST':
        # store stage and env values
        if not session.get('user'):
            return redirect(url_for('/'))

        val = request.form.get('form-name')
        print("Value of val", val)
        # print(session.get('testdoc_service'), session.get('testresult_service'))

        if val.lower().startswith('etl'):
            platform = session.get('etl_platform')
            service = session.get('etl_service')
            session.pop('etl_platform')
            session.pop('etl_service')

        elif val.lower().startswith('testdoc'):
            platform = session.get('testdoc_platform')
            service = session.get('testdoc_service')
            session['testdoc_platform'] = None
            session['testdoc_service'] = None

        elif val.lower().startswith('testresult'):
            platform = session.get('testresult_platform')
            service = session.get('testresult_service')
            session.pop('testresult_platform')
            session.pop('testresult_service')

        elif val.lower().startswith('mismatch'):
            platform = session.get('mismatch-record-platform')
            service = session.get('mismatch-record-storage-service')
            session.pop('mismatch-record-platform')
            session.pop('mismatch-record-storage-service')

        elif val.lower().startswith('metrics'):
            platform = session.get('metrics_platform')
            service = session.get('metrics_service')
            session.pop('metrics_platform')
            session.pop('metrics_service')

        elif val.lower().startswith('metadata'):
            platform = session.get('metadata_platform')
            service = session.get('metadata_service')
            session.pop('metrics_platform')
            session.pop('metrics_service')

        username = session['user']
        env = session['environment']
        stage = session['stage']

        # prepping connection_details as identified by the validation engine
        con_det = request.form.to_dict()
        form_name = con_det.pop('form-name')

        # quickfix
        # Test Result Storage needs various tables to store test results. 
        # Accommodating tables for f2f and db2db in the same configuration here
        if form_name == 'TestResult Storage Configuration':
            keylist = [key for key in con_det.keys() if 'Table Name' in key]
            import re
            con_det['Table Name'] = {re.split('\(|\)', key)[1]: con_det.pop(key) for key in keylist}

        # listing service parameters
        param_list = Services.query.with_entities(Services.connection_details).filter_by(
            service_name=service).all()[0][0]
        connection_details = {}

        # forming the connection details dictionary to store in the table
        for key, value in param_list.items():
            connection_details[key] = {}
            for name in value:
                connection_details[key][name.lower()] = con_det.get(name)
        connection_name = val
        new_conn = UserConnections(
            connection_name=connection_name,
            emp_id=username,
            test_environment=env,
            stage=stage,
            platform=platform,
            service=service,
            connection_details=connection_details,
            created_on=datetime.now(),
            updated_on=datetime.now(),
            pipeline_name=None,
            conn_id=None
        )
        db = dbf_obj.get_dbase()
        db.session.add(new_conn)
        db.session.commit()

        flash('Successfully saved result')
        return redirect(url_for('configuration.add_app_configuration'))


@validate_request
def view_config():
    try:
        conf = []
        env = session['environment']
        stage = session['stage']
        filter_by = dict(
            test_environment=env,
            stage=stage
        )

        etl_conf = UserConnections.get_conf_details('ETL Configuration', filter_by)
        test_doc_conf = UserConnections.get_conf_details('TestDoc Storage Configuration', filter_by)
        test_res_conf = UserConnections.get_conf_details('TestResult Storage Configuration', filter_by)
        metrics_conf = UserConnections.get_conf_details('Metrics Storage Configuration', filter_by)
        mismatch_conf = UserConnections.get_conf_details('Mismatch Record', filter_by)
        metadata_conf = UserConnections.get_conf_details('Metadata Storage Configuration', filter_by)
        conf = [etl_conf, test_res_conf, test_doc_conf, metrics_conf, mismatch_conf, metadata_conf]

        for con in conf:
            try:
                if 'password' in con.connection_details['connection_details']:
                    con.connection_details['connection_details']['password'] = generate_password_hash(
                        json.dumps(con.connection_details['connection_details']['password'])
                    )
                if 'credentials' in con.connection_details['connection_details']:
                    con.connection_details['connection_details']['credentials'] = generate_password_hash(
                        json.dumps(con.connection_details['connection_details']['credentials'])
                    )
            except AttributeError:
                conf.remove(con)
                continue
        if etl_conf is None and test_doc_conf is None and test_res_conf is None and metrics_conf is None \
                and mismatch_conf is None and metadata_conf is None:
            flash("Configure the details first.")

            return redirect(url_for('configuration.appconfig'))

        else:
            flash("Details are already configured!")
    except Exception as e:
        flash(e)

    return render_template("configuration/view_config.html", conf=conf)


def configure_orch():
    if not request.args:
        orch_form = ConfigureOrch()
        services = Services.query.where(Services.type_id.in_([5])).with_entities(
            Services.service_name).all()
        orch_list = [orch[0] for orch in services]

        platforms = Platform.query.select_from(Platform).join(Services).where(
            Platform.platform_name != 'NA').with_entities(Platform.platform_name).all()
        # prep-step
        platform_list = [platform[0] for platform in platforms]

        return render_template('execution/configureorch.html', orch_val=orch_form, data=orch_list, data2=platform_list)
    val = request.args.get('val')
    data = request.args.get('data')

    if val == 'orch-select-tool':
        source_plat = request.args.get('data')
        session['orch-select-tool'] = source_plat
        conn_details = Services.query.where(Services.service_name == source_plat).with_entities(
            Services.connection_details).all()
        det = conn_details[0][0]
        conn_details_list = [val for key, val in det.items()]
        conn_det_list = list(chain(*conn_details_list))
        return json.dumps(conn_det_list)

    elif val == 'orch-platform-test-result':
        etl = request.args.get('data')
        session['orch-platform-test-result'] = etl
        conn_details = Services.query.where(Services.resource_key == "postgresql").with_entities(
            Services.service_name).all()
        conn_details_list = []
        for conn in conn_details:
            for t in conn:
                conn_details_list.append(t)

        print(conn_details_list)
        return json.dumps(conn_details_list)

    elif val == 'orch-test-result-storage-service':
        etl = request.args.get('data')
        session['orch-test-result-storage-service'] = etl
        conn_details = Services.query.where(Services.service_name == etl).with_entities(
            Services.connection_details).all()
        det = conn_details[0][0]
        conn_details_list = [val for key, val in det.items()]
        conn_det_list = list(chain(*conn_details_list))
        return json.dumps(conn_det_list)


@validate_request
def view_endpt_conf():
    conftypedb2db = [db2dbsrcconf, db2dbtgtconf]
    conftypef2f = [f2fsrcconf, f2ftgtconf]
    conftypef2db = [f2dbsrcconf, f2dbtgtconf]
    conftypesfdc2db = [sfdc2dbsrcconf, sfdc2dbtgtconf]
    conftype_manual_f2db = [f2dbsrcconf, f2dbtgtconf]
    conftype_manual_db2db = [db2dbsrcconf, db2dbtgtconf]
    conftype_manual_sfdc2db = [sfdc2dbsrcconf, sfdc2dbtgtconf]
    emp_name = "%{}%".format(g.current_user)

    try:
        all_conf = UserConnections.query.where(UserConnections.connection_name.in_(conftypedb2db)). \
            filter(UserConnections.emp_id.like(emp_name)). \
            filter_by(test_environment=g.current_env). \
            filter_by(stage=g.current_stage).order_by(
            desc(UserConnections.updated_on)).all()

        for counter in range(len(all_conf)):
            if 'password' in all_conf[counter].connection_details['connection_details']:
                all_conf[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf[counter].connection_details.get('connection_details').get('password'))
            if 'credentials' in all_conf[counter].connection_details['connection_details']:
                all_conf[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf[counter].connection_details.get('connection_details').get('password'))

        all_conf_manual_db2db = user_connection_db2db.query.where(user_connection_db2db.connection_name.in_(
            conftype_manual_db2db)). \
            filter(user_connection_db2db.emp_id.like(emp_name)). \
            filter_by(test_environment=g.current_env). \
            filter_by(stage=g.current_stage).order_by(
            desc(user_connection_db2db.updated_on)).all()

        for counter in range(len(all_conf_manual_db2db)):
            if 'password' in all_conf_manual_db2db[counter].connection_details['connection_details']:
                all_conf_manual_db2db[counter].connection_details['connection_details'][
                    'password'] = generate_password_hash(
                    all_conf_manual_db2db[counter].connection_details.get('connection_details').get('password'))
            if 'credentials' in all_conf_manual_db2db[counter].connection_details['connection_details']:
                all_conf_manual_db2db[counter].connection_details['connection_details'][
                    'password'] = generate_password_hash(
                    all_conf_manual_db2db[counter].connection_details.get('connection_details').get('password'))
    except Exception as e:
        flash(e)

    try:
        all_conf_f2db = user_connection_f2db.query.where(user_connection_f2db.connection_name.in_(conftypef2db)). \
            filter(user_connection_f2db.emp_id.like(emp_name)). \
            filter_by(test_environment=g.current_env). \
            filter_by(stage=g.current_stage).order_by(
            desc(user_connection_f2db.updated_on)).all()

        for counter in range(len(all_conf_f2db)):
            if 'password' in all_conf_f2db[counter].connection_details['connection_details']:
                all_conf_f2db[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf_f2db[counter].connection_details.get('connection_details').get('password'))
            if 'credentials' in all_conf_f2db[counter].connection_details['connection_details']:
                all_conf_f2db[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf_f2db[counter].connection_details.get('connection_details').get('password'))

        all_conf_manual_f2db = UserConnectionsManual.query.where(UserConnectionsManual.connection_name.in_(
            conftype_manual_f2db)). \
            filter(UserConnectionsManual.emp_id.like(emp_name)). \
            filter_by(test_environment=g.current_env). \
            filter_by(stage=g.current_stage).order_by(
            desc(UserConnectionsManual.updated_on)).all()

        for counter in range(len(all_conf_manual_f2db)):
            if 'password' in all_conf_manual_f2db[counter].connection_details['connection_details']:
                all_conf_manual_f2db[counter].connection_details['connection_details'][
                    'password'] = generate_password_hash(
                    all_conf_manual_f2db[counter].connection_details.get('connection_details').get('password'))
            if 'credentials' in all_conf_manual_f2db[counter].connection_details['connection_details']:
                all_conf_manual_f2db[counter].connection_details['connection_details'][
                    'password'] = generate_password_hash(
                    all_conf_manual_f2db[counter].connection_details.get('connection_details').get('password'))
    except Exception as e:
        flash(e)

    try:
        all_conf_sfdc2db = UserConnectionSFDC2DB.query.where(UserConnectionSFDC2DB.connection_name.in_(conftypesfdc2db)). \
            filter(UserConnectionSFDC2DB.emp_id.like(emp_name)). \
            filter_by(test_environment=g.current_env). \
            filter_by(stage=g.current_stage).order_by(
            desc(UserConnectionSFDC2DB.updated_on)).all()

        for counter in range(len(all_conf_sfdc2db)):
            if 'password' in all_conf_sfdc2db[counter].connection_details['connection_details']:
                all_conf_sfdc2db[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf_sfdc2db[counter].connection_details.get('connection_details').get('password'))
            if 'credentials' in all_conf_sfdc2db[counter].connection_details['connection_details']:
                all_conf_sfdc2db[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf_sfdc2db[counter].connection_details.get('connection_details').get('password'))

        all_conf_manual_sfdc2db = UserConnectionsManual.query.where(UserConnectionsManual.connection_name.in_(
            conftype_manual_sfdc2db)). \
            filter(UserConnectionSFDC2DB.emp_id.like(emp_name)). \
            filter_by(test_environment=g.current_env). \
            filter_by(stage=g.current_stage).order_by(
            desc(UserConnectionsManual.updated_on)).all()

        for counter in range(len(all_conf_manual_sfdc2db)):
            if 'password' in all_conf_manual_sfdc2db[counter].connection_details['connection_details']:
                all_conf_manual_sfdc2db[counter].connection_details['connection_details'][
                    'password'] = generate_password_hash(
                    all_conf_manual_sfdc2db[counter].connection_details.get('connection_details').get('password'))
            if 'credentials' in all_conf_manual_sfdc2db[counter].connection_details['connection_details']:
                all_conf_manual_sfdc2db[counter].connection_details['connection_details'][
                    'password'] = generate_password_hash(
                    all_conf_manual_sfdc2db[counter].connection_details.get('connection_details').get('password'))
    except Exception as e:
        flash(e)

    try:
        all_conf_f2f = user_connection_f2f.query.where(user_connection_f2f.connection_name.in_(conftypef2f)). \
            filter(user_connection_f2f.emp_id.like(emp_name)). \
            filter_by(test_environment=g.current_env). \
            filter_by(stage=g.current_stage).order_by(
            desc(user_connection_f2f.updated_on)).all()

        for counter in range(len(all_conf_f2f)):
            if 'password' in all_conf_f2f[counter].connection_details['connection_details']:
                all_conf_f2f[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf_f2f[counter].connection_details.get('connection_details').get('password'))
            if 'credentials' in all_conf_f2f[counter].connection_details['connection_details']:
                all_conf_f2f[counter].connection_details['connection_details']['password'] = generate_password_hash(
                    all_conf_f2f[counter].connection_details.get('connection_details').get('password'))
    except Exception as e:
        flash(e)

    return render_template(
        "execution/view_config.html",
        conf=all_conf + all_conf_manual_db2db,
        all_conf_f2db=all_conf_f2db + all_conf_manual_f2db,
        all_conf_sfdc2db=all_conf_sfdc2db + all_conf_manual_sfdc2db,
        all_conf_f2f=all_conf_f2f
    )


def script_filetransfer(u_file, mes, per_filename, etl_name):
    ext = per_filename.split(".")[-1]
    key = session['environment'] + "/" + session['stage'] + "/" + mes + "/" + mes.lower().replace(' ', '_') + "." + ext
    data = UserConnections.query.filter_by(stage=session['stage']).filter_by(
        test_environment=session['environment']).filter_by(connection_name="TestDoc Storage Configuration").order_by(
        desc('updated_on')).first()
    service = Services.query.filter_by(service_name=data.service).with_entities(Services.resource_key).first()[0]
    fo = ob.create(data.platform, service=service).service()
    buck = data.connection_details
    bucke = buck.get('connection_details')['bucket']
    res = fo.upload_object(u_file, mes, per_filename, bucke)
    addtest = MasterConfig(environment=session['environment'], stage=session['stage'], time_stamp=datetime.now(),
                           loc_of_test_script=res, application_name=etl_name, pipeline_identifier=etl_name,
                           test_script_path='s3://' + bucke + '/' + key)
    db = dbf_obj.get_dbase()
    db.session.add(addtest)
    db.session.commit()


def opt_file_check(form_list):
    for o_lis, mess in form_list:
        if o_lis.indentifier.data == mess:
            print(o_lis)
            per_filename = secure_filename(o_lis.t_file.data.filename)
            filetransfer(o_lis.t_file.data, mess, per_filename)
            flash(f"File {mess} Uploaded Successfully")
            return redirect(url_for("configuration.testfield"))


def filetransfer(u_file, mes, per_filename):
    ext = per_filename.split(".")[-1]
    key = session['environment'] + "/" + session['stage'] + "/" + mes + "/" + mes.lower().replace(' ', '_') + "." + ext
    data = UserConnections.query.filter_by(stage=session['stage']).filter_by(
        test_environment=session['environment']).filter_by(connection_name="TestDoc Storage Configuration").order_by(
        desc('updated_on')).first()
    service = Services.query.filter_by(service_name=data.service).with_entities(Services.resource_key).first()[0]
    fo = ob.create(data.platform, service=service).service()
    buck = data.connection_details
    bucke = buck.get('connection_details')['bucket']
    res = fo.upload_object(u_file, mes, per_filename, bucke)
    addtest = TestLog(username=session['user'], environment=session['environment'], stage=session['stage'],
                      time_stamp=datetime.now(), document_type="Test Doc", document_link=res, document_name=key,
                      document_path='s3://' + bucke + '/' + key)
    db = dbf_obj.get_dbase()
    db.session.add(addtest)
    db.session.commit()


@validate_request
def testfield():
    if request.method == 'GET':
        t_form = TestForm()
        p_form = TestForm()
        b_form = TestForm()
        s_form = TestForm()
        per_form = TestForm()
        c_form = TestForm()
        d_form = TestForm()
        form_lis = [[t_form, "Source-To-Target Column Mapping Sheet"],
                    [p_form, "Pipeline Dependency Sheet"],
                    # [b_form, "Benchmark Sheet"],
                    [s_form, "Source Schema"],
                    # [per_form, "Performance Metric Info Location"],
                    [c_form, "Test-Script Config File"],
                    # [d_form, "Synthetic Data Configuration File"]
                    ]
    # if received files from the frontend
    elif request.method == 'POST':
        form = TestForm()
        con = UserConnections.query.filter_by(
            stage=session['stage'],
            test_environment=session['environment'],
            connection_name='TestDoc Storage Configuration'
        ).first()
        resource_key = Services.query.filter_by(service_name=con.service).first().resource_key
        service = ob.create(con.platform, service=resource_key).service()
        service.upload()
        print(con.platform, con.service)
        form_lis = []
        opt_file_check(form_lis)
    data = TestLog.query.filter_by(stage=session['stage']).filter_by(environment=session['environment']).filter_by(
        document_type="Test Doc").all()
    # return render_template("execution/testform.html", form_lis= form_lis, test_data=data)
    return render_template("upload/prereq_doc.html", form_lis=form_lis, test_data=data)


@validate_request
def configureApp_page():
    return render_template('configuration/configureApp_page.html')


@validate_request
def configureVal_page():
    return render_template('configuration/configureVal_page.html')
