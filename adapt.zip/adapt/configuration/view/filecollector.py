from globals.fileloader import SingleFileLoader
from flask import url_for, g
from flask.views import MethodView
from flask import redirect, session, render_template
from configuration.models import *
from configuration.forms import *
from utils.defaults import validate_request



class FileCollector(MethodView, SingleFileLoader):
    decorators = [validate_request]

    def get(self):
        try:
            form_list = []
            sheets = [
                "Source-To-Target Column Mapping Sheet",
                "Pipeline Dependency Sheet",
                "Source Schema",
                # "Test-Script Config File",
            ]
            for sheet in sheets:
                form = SingleFileUploadForm()
                form_list.append([form, sheet])

            data = TestLog.query.filter_by(
                stage=session['stage'],
                environment=session['environment'],
                document_type="Test Doc"
            ).all()
        except Exception as e:
            flash("Something went wrong! Unable to fetch test doc data: \"" + str(e) + "\"")

        return render_template("upload/prereq_doc.html",
                               form_lis=form_list,
                               test_data=data)

    def post(self):
        """
        Method to handle post requests for FileCollector
        currently responds to requests from path = /upload
        """
        self.connection_name = 'TestDoc Storage Configuration'
        location = UserConnections.get_connection(self.connection_name, filter_by=dict(
            test_environment=g.current_env,
            stage=g.current_stage
        ))

        if location:
            self.con = self.parse_connection_details(location)
            response = self.save()
        else:
            response = 'Please configure Pre-requisites Storage in Configure Application'
        flash(response)        
        return redirect(url_for('configuration.filecollector'))

    
    # def save(self):
    #     form_obj = SingleFileUploadForm()
    #     if form_obj.validate_on_submit():
    #         file = form_obj.file.data
    #         file.id = form_obj.identifier.data
    #         file.filename = secure_filename(file.filename)
    #         service = sp(self.connection_name)
    #         try:
    #             res = service.upload(file, self.con)
    #             self.metadata_save(res)
    #         except OSError as e:
    #             message = str(e)
    #         except Exception as e:
    #             message = "Oops, something went wrong!"
    #             message = str(e)
    #         else:
    #             message = "File saved successfully"
    #         finally:
    #             return message
    
    # def parse_connection_details(self):
    #     """parse connection details for linux File Store"""
    #     from globals.conninfo import ConnectionDetails
    #     connection_info = self.con.connection_details
    #     con = {
    #         **connection_info.get('connection_details'), 
    #         **connection_info.get('additional_details')
    #     }
    #     con = ConnectionDetails(self.con.service, con)
    #     return con
    
    # def metadata_save(self, res: FileUploadResponse):
        
    #     document_type = 'Test Doc'
    #     metadata = TestLog(
    #         username=session['user'],
    #         environment=session['environment'],
    #         stage=session['stage'],
    #         document_type=document_type,
    #         document_link=res.document_link,
    #         document_path=res.document_path,
    #         document_name=res.document_name,
    #         time_stamp=datetime.now()
    #     )
    #     metadata.save()
    #     return 'OK'

    # @staticmethod
    # def filetransfer(u_file, mes, per_filename):
    #     ext= per_filename.split(".")[-1]
    #     key= session['environment']+"/"+session['stage']+"/"+mes+"/"+mes.lower().replace(' ', '_')+"."+ext
    #     data= UserConnections.query.filter_by(stage= session['stage']).filter_by(test_environment= session['environment']).filter_by(connection_name= "TestDoc Storage Configuration").order_by(desc('updated_on')).first()
    #     service = Services.query.filter_by(service_name=data.service).with_entities(Services.resource_key).first()[0]
    #     fo= ob.create(data.platform, service=service).service()
    #     buck= data.connection_details
    #     bucke= buck.get('connection_details')['bucket']
    #     res= fo.upload_object(u_file, mes, per_filename, bucke)
    #     addtest= TestLog(username= session['user'], 
    #     environment= session['environment'], 
    #     stage= session['stage'], time_stamp= datetime.now(), document_type= "Test Doc",document_link= res, document_name=key, document_path='s3://'+bucke+'/'+key)
    #     db = dbf_obj.get_dbase()
    #     db.session.add(addtest)
    #     db.session.commit()
    
    # @staticmethod
    # def opt_file_check(form_list):
    #     for o_lis, mess in form_list:
    #         if  o_lis.indentifier.data==mess:
    #             print(o_lis)
    #             per_filename= secure_filename(o_lis.t_file.data.filename)
    #             filetransfer(o_lis.t_file.data, mess, per_filename)
    #             flash(f"File {mess} Uploaded Successfully")
    #             return redirect(url_for("configuration.testfield"))