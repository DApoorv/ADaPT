import re

import requests
from sqlalchemy import desc, and_

from utils.defaults import validate_request
from pathlib import Path
from globals.constants import *
from flask.views import MethodView
from configuration.forms import *
from configuration.models import Services, Platform, TestLog, UserConnections, ApiConfig, user_connection_f2db
from execution.models import MasterConfig, APIresponse, APIF2DB
from utils.pass_decrypt import decrypt_password
from utils.serviceprovider import sp
from flask import render_template, redirect, url_for, flash, session, request, g, jsonify
from datetime import datetime
import json
from itertools import chain
from configuration.view.appconfigcollector import *

"""
Created by Apoorv Dubey 
Last updated on 06 April 2022
"""

"""
Get API response from Marlin and dividing the details in two subclass :
    1. getResMaster -> It handles the below info:
                  1. Pipeline Identifier --> Ingestion ID
                  2. Pipeline Name --> (ingestion_id + sourceName+ingestion Type+tableName)
                  3. Source System
                  4. Start Time
                  5. End time
                  7. Status

    2. getResUserConn -> All source and target db details needs to handled here.
        6. Connection details [DB to DB connection details]
"""


def getResUserConn(pipe_det):

    password = decrypt_password(pipe_det[0][0])
    user_name = pipe_det[0][1]
    ingestion_type = pipe_det[0][2]
    connection_url = pipe_det[0][3]
    conn_id = pipe_det[0][4]
    pipeline_name = pipe_det[0][5]
    created_by = pipe_det[0][6]

    conn_details_val = {}
    conn_details_val["password"] = password
    conn_details_val["username"] = user_name
    conn_details_val["host"] = connection_url

    conn_details_additional = {}
    conn_details_additional["table name"] = ""

    conn_details = {}
    conn_details["connection_details"] = conn_details_val
    conn_details["additional_details"] = conn_details_additional
    srctype = f2dbsrcconf

    adduser = user_connection_f2db(
        emp_id=created_by,
        test_environment="Unit Testing",
        stage="Marlin",
        platform="OnPremises",
        service=ingestion_type,
        connection_name=srctype,
        connection_details=conn_details,
        created_on=datetime.now(),
        updated_on=datetime.now(),
        pipeline_name=pipeline_name,
        conn_id=conn_id
    )
    adduser.save()


class GetAPIF2DB(MethodView):

    def post(self):
        content_type = request.headers.get('Content-Type')
        if content_type == 'application/json':
            var = request.get_json()
            pipeline_id = var.get("pipeline_id")
            pipeline_name = var.get("pipeline_name")
            ingestion_type = var.get("ingestion_type")
            status = var.get("status")
            source = var.get("source")
            connection_id = var.get("connection_id")
            connection_name = var.get("connection_name")
            connection_url = var.get("connection_url")
            user_name = var.get("user_name")
            password = var.get("password")
            file_path = var.get("file_path")
            file_format = var.get("file_format")
            start_time = var.get("start_time")
            end_time = var.get("end_time")
            created_by = var.get("created_by")

            vari = None
            counter = 0
            try:
                compare_res_str = pipeline_id + pipeline_name + source + status + connection_url + ingestion_type + file_path + file_format
                vari = APIF2DB.query.filter(
                    APIF2DB.pipeline_id == pipeline_id).with_entities(
                    APIF2DB.pipeline_id, APIF2DB.pipeline_name, APIF2DB.source,
                    APIF2DB.status, APIF2DB.connection_url, APIF2DB.ingestion_type,
                    APIF2DB.file_path, APIF2DB.file_format).all()

                vari2 = [[str(x) for x in tup] for tup in vari]
                conn_details_list = [''.join(tups) for tups in vari2]
                for var in conn_details_list:
                    if compare_res_str == var:
                        counter+=1
                if counter == 0 or vari is None:
                    api_new = APIF2DB(pipeline_id=pipeline_id,
                                      pipeline_name=pipeline_name,
                                      source=source,
                                      start_time=start_time,
                                      end_time=end_time,
                                      user_name=user_name,
                                      password=password,
                                      file_path=file_path,
                                      connection_url=connection_url,
                                      status=status,
                                      updatedon=datetime.now(),
                                      ingestion_type=ingestion_type,
                                      connection_id=connection_id,
                                      connection_name=connection_name,
                                      file_format=file_format,
                                      created_by=created_by,
                                      stage="Marlin",
                                      environment="Unit Testing"
                                      )
                    api_new.save()
                    status_code = "message"
                    message = "Pipeline fetched and saved to database for validation!!"
                    try:
                        pipe_det = APIF2DB.query.with_entities(
                            APIF2DB.password, APIF2DB.user_name, APIF2DB.ingestion_type, APIF2DB.connection_url,
                            APIF2DB.connection_id, APIF2DB.pipeline_name, APIF2DB.created_by).order_by(
                            desc(APIF2DB.updatedon)).limit(1).all()
                        getResUserConn(pipe_det)
                    except Exception as e:
                        message = "Sorry! pipeline not got configured correctly."+str(e)
                else:
                    status_code = "message"
                    message = "Pipeline ID already exists!!"
            except Exception as e:
                status_code = "message"
                message = str(e)
        else:
            status_code = "message"
            message = "Bad Request"

        mes = {status_code: message}
        return jsonify(mes)


