from utils.defaults import validate_request
from pathlib import Path
from globals.constants import *
from flask.views import MethodView
from configuration.forms import *
from configuration.models import Services, Platform, TestLog, UserConnections, ApiConfig, \
    UserConnectionsManual, UserConnectionSFDC2DB
from execution.models import MasterConfig, APIresponse, ApiSFDC2DB
from utils.serviceprovider import sp
from flask import render_template, redirect, url_for, flash, session, request, g
from datetime import datetime
import json
from itertools import chain
from configuration.view.appconfigcollector import *


class SFDC2DBConfigCollector(MethodView):
    decorators = [validate_request]

    def get(self):
        if request.args:
            return self.process_args()
        db_form = ConfigureX2X()

        platforms = Platform.query.select_from(Platform).join(Services).where(
            Platform.platform_name != 'NA').with_entities(Platform.platform_name).all()
        platform_list = [platform[0] for platform in platforms]

        return render_template(
            'execution/configuresfdc2db.html',
            platform_list=platform_list,
            db_form=db_form,
            db_form2=db_form
        )

    def process_args(self):
        val = request.args.get('val')
        data = request.args.get('data')

        if val == 'sfdc2db-source-platform':
            session['sfdc2db-source-platform'] = data
            conn_details = Services.query.where(Services.type_id.in_([8])).with_entities(
                Services.service_name).all()
            conn_details_list = []
            for conn in conn_details:
                for t in conn:
                    conn_details_list.append(t)
            return json.dumps(conn_details_list)

        elif val == 'sfdc2db-source-services':
            session['sfdc2db-source-services'] = data
            conn_details = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_details[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            conn_det_list.remove('Table Name')
            return json.dumps(conn_det_list)

        elif val == 'sfdc2db-target-platform':
            session['sfdc2db-target-platform'] = data
            conn_details = Services.query.where(Services.type_id.in_([4])).with_entities(
                Services.service_name).all()
            conn_details_list = []
            for conn in conn_details:
                for t in conn:
                    conn_details_list.append(t)
            return json.dumps(conn_details_list)

        elif val == 'sfdc2db-target-services':
            session['sfdc2db-target-services'] = data
            conn_details = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_details[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            conn_det_list.remove('Table Name')
            return json.dumps(conn_det_list)

    def post(self):
        data = request.form.to_dict()
        form_name = data['identifier']
        if data:
            if form_name == 'form1':
                platform = session.get('sfdc2db-source-platform')
                service = session.get('sfdc2db-source-services')
                conn_name = sfdc2dbsrcconf
                keylist = [key for key in data.keys() if 'Table Name' in key]
                import re
                data['Table Name'] = {re.split('\(|\)', key)[1]: data.pop(key) for key in keylist}
                param_list = \
                    Services.query.with_entities(Services.connection_details).filter_by(service_name=service).all()[
                        0][0]
                connection_details = {}
                for key, value in param_list.items():
                    connection_details[key] = {}
                    for name in value:
                        connection_details[key][name.lower()] = data.get(name)
                conn = connection_details

                message = f"For {platform} and {service} data got configured"

                adduser = UserConnectionsManual(
                    emp_id=session['user'],
                    test_environment=session['environment'],
                    stage=session['stage'],
                    platform=platform,
                    service=service,
                    connection_name=conn_name,
                    connection_details=conn,
                    pipeline_name=data['source-pipeline'] + " " + "manual",
                    created_on=datetime.now(),
                    updated_on=datetime.now()
                )
                adduser.save()

                api_new = ApiSFDC2DB(
                    pipeline_id=0,
                    pipeline_name=data['source-pipeline']+" "+"manual",
                    ingestion_type=None,
                    status=None,
                    source_system=conn.get("connection_details").get("source_name"),
                    connection_id=None,
                    connection_name=conn_name,
                    connection_url=conn.get("connection_details").get("connection url"),
                    user_name=conn.get("connection_details").get("username"),
                    password_encrypted=conn.get("connection_details").get("password"),
                    security_token=conn.get("connection_details").get("security token"),
                    start_time=None,
                    end_time=None,
                    file_format=None,
                    created_by=None,
                    updatedon=datetime.now(),
                    sandbox=conn.get("connection_details").get("sandbox"),
                    stage=session['stage'],
                    environment=session['environment']
                    )
                api_new.save()
            else:
                platform = session.get('sfdc2db-target-platform')
                service = session.get('sfdc2db-target-services')
                conn_name = sfdc2dbtgtconf

                keylist = [key for key in data.keys() if 'Table Name' in key]
                import re
                data['Table Name'] = {re.split('\(|\)', key)[1]: data.pop(key) for key in keylist}
                param_list = \
                    Services.query.with_entities(Services.connection_details).filter_by(service_name=service).all()[
                        0][0]
                connection_details = {}
                for key, value in param_list.items():
                    connection_details[key] = {}
                    for name in value:
                        connection_details[key][name.lower()] = data.get(name)
                conn = connection_details
                # conn = self.conn_details(db_form)
                message = f"For {platform} and {service} data got configured"
                adduser = UserConnectionsManual(
                    emp_id=session['user'],
                    test_environment=session['environment'],
                    stage=session['stage'],
                    platform=platform,
                    service=service,
                    connection_name=conn_name,
                    connection_details=conn,
                    pipeline_name=data['target-pipeline'] + " " + "manual",
                    created_on=datetime.now(),
                    updated_on=datetime.now()
                )
                adduser.save()
        flash(message)
        return redirect(url_for("configuration.sfdc2db_field"))
