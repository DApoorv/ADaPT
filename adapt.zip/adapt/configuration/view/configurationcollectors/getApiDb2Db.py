import re

import requests
from sqlalchemy import desc, and_

from utils.defaults import validate_request
from pathlib import Path
from globals.constants import *
from flask.views import MethodView
from configuration.forms import *
from configuration.models import Services, Platform, TestLog, UserConnections, ApiConfig, user_connection_db2db
from execution.models import MasterConfig, APIresponse
from utils.pass_decrypt import decrypt_password
from utils.serviceprovider import sp
from flask import render_template, redirect, url_for, flash, session, request, g, jsonify
from datetime import datetime
import json
from itertools import chain
from configuration.view.appconfigcollector import *

"""
Created by Apoorv Dubey 
Last updated on 06 April 2022
"""

"""
Get API response from Marlin and dividing the details in two subclass :
    1. getResMaster -> It handles the below info:
                  1. Pipeline Identifier --> Ingestion ID
                  2. Pipeline Name --> (ingestion_id + sourceName+ingestion Type+tableName)
                  3. Source System
                  4. Start Time
                  5. End time
                  7. Status
    
    2. getResUserConn -> All source and target db details needs to handled here.
        6. Connection details [DB to DB connection details]
"""


class GetAPIDB2DB(MethodView):

    def post(self):
        content_type = request.headers.get('Content-Type')
        if content_type == 'application/json':
            var = request.get_json()
            pipeline_id = var.get("pipeline_id")
            pipeline_name = var.get("pipeline_name")
            ingestion_type = var.get("ingestion_type")
            status = var.get("status")
            source_system = var.get("source_system")
            connection_id = var.get("connection_id")
            connection_name = var.get("connection_name")
            connection_url = var.get("connection_url")
            user_name = var.get("user_name")
            password_encrypted = var.get("password_encrypted")
            driver = var.get("driver")
            file_format = var.get("file_format")
            start_time = var.get("start_time")
            end_time = var.get("end_time")
            created_by = var.get("created_by")

            password_decrypted = decrypt_password(password_encrypted)
            host = None
            port = None
            serv_name = None
            database_name = None
            database_service_name = None
            try:
                if ingestion_type == "SQOOP" and (
                        source_system == "CSP_JIRA" or source_system == "AA" or source_system == "CMS" or source_system == "DNB" or
                        source_system == "DRM" or source_system == "EBS" or source_system == "EBS_TEST35" or source_system == "EPP" or source_system == "ESO" or
                        source_system == "GEM" or source_system == "GSSFDC" or source_system == "JIRA_RND" or source_system == "MODELN" or
                        source_system == "MYL" or source_system == "SDP" or source_system == "SRDB" or source_system == "HAWQ" or
                        source_system == "WAVEFRONT" or source_system == "MARITZCX"):
                    host = re.search(r"\(HOST.*?\)", connection_url).group().strip("(").strip(")").split("=")[1]
                    port = re.search(r"\(PORT.*?\)", connection_url).group().strip("(").strip(")").split("=")[1]
                    serv_name = \
                    re.search(r"\((SID|SERVICE_NAME).*?\)", connection_url).group().strip("(").strip(")").split("=")[1]

                elif ingestion_type == "SQOOP" and (
                        source_system == "ACPQ" or source_system == "CFP" or source_system == "EVALLIC" or source_system == "HYDRA" or
                        source_system == "JIRA" or source_system == "LAMP" or source_system == "MDB" or source_system == "SEG" or
                        source_system == "VRCS"):
                    host_port = connection_url.split("/")
                    host = host_port[2].split(":")[0]
                    port = host_port[2].split(":")[1]
                    db = re.split('([;?])', host_port[3])
                    serv_name = db[0]

                elif ingestion_type == "SQOOP" and (
                        source_system == "BRIM" or source_system == "MDG" or source_system == "EDWHANA"):
                    host_port = connection_url.split("/")
                    host = host_port[2].split(":")[0]
                    port = host_port[2].split(":")[1]

                elif ingestion_type == "SQOOP" and (
                        source_system == "CP" or source_system == "JIVE" or source_system == "MYLEARN" or
                        source_system == "SBUSQL" or source_system == "CDM"):
                    host_port = connection_url.split("/")
                    host = host_port[2].split(";")[0]
                    serv_name = host_port[2].split(";")[1].split("=")[1]
                elif ingestion_type == "SQOOP" and (source_system == "VAC"):
                    host_port = connection_url.split("/")
                    host = host_port[2].split(":")[0]
                    port = host_port[2].split(":")[1]
                    db = re.split('([;?])', host_port[3])
                    database_name = db[0]

                elif ingestion_type == "JDBC" and (
                        source_system == "RS_EUC" or source_system == "PLATFORM" or source_system == "EUC" or
                        source_system == "VAC" or source_system == "SGMNT" or source_system == "SEG"):
                    host_port = connection_url.split("/")
                    host = host_port[2].split(":")[0]
                    port = host_port[2].split(":")[1]
                    db = re.split('([;?])', host_port[3])
                    database_name = db[0]
            except:
                pass

            if not database_service_name:
                try:
                    database_service_name = \
                        ApiConfig.query.filter(ApiConfig.driver_name == driver).with_entities(
                            ApiConfig.db_service).first()[
                            0]
                except Exception as e:
                    return str(e)

            conn_details_val = {}
            conn_details_val["password"] = password_decrypted
            conn_details_val["username"] = user_name
            conn_details_val["port"] = port
            conn_details_val["host"] = host
            conn_details_val["service_name"] = serv_name
            conn_details_val["drivername"] = driver
            conn_details_val["database"] = database_name

            conn_details_additional = {}
            conn_details_additional["table name"] = ""

            conn_details = {}
            conn_details["connection_details"] = conn_details_val
            conn_details["additional_details"] = conn_details_additional

            compare_res_str = pipeline_id + pipeline_name + source_system + status

            vari = APIresponse.query.filter(
                APIresponse.pipeline_id == pipeline_id).with_entities(
                APIresponse.pipeline_id, APIresponse.pipeline_name, APIresponse.source_system,
                APIresponse.status).all()
            print("vari", vari)
            try:
                vari2 = [[str(x) for x in tup] for tup in vari]
                conn_details_list = [''.join(tups) for tups in vari2]
            except:
                pass

            if vari:
                for var in conn_details_list:
                    if compare_res_str == var:
                        status_code = "message"
                        message = "Pipeline ID already exists!!"
                    else:
                        api_new = APIresponse(pipeline_id=pipeline_id,
                                              pipeline_name=pipeline_name,
                                              source_system=source_system,
                                              start_time=start_time,
                                              end_time=end_time,
                                              conn_details=conn_details,
                                              status=status,
                                              updatedon=datetime.now(),
                                              ingestion_type=ingestion_type,
                                              connection_id=connection_id,
                                              connection_name=connection_name,
                                              file_format=file_format,
                                              created_by=created_by,
                                              stage="Marlin",
                                              environment="Unit Testing"
                                              )
                        api_new.save()
                        status_code = "message"
                        message = "Pipeline fetched and saved to database for validation!!"
            else:
                api_new = APIresponse(pipeline_id=pipeline_id,
                                      pipeline_name=pipeline_name,
                                      source_system=source_system,
                                      start_time=start_time,
                                      end_time=end_time,
                                      conn_details=conn_details,
                                      status=status,
                                      updatedon=datetime.now(),
                                      ingestion_type=ingestion_type,
                                      connection_id=connection_id,
                                      connection_name=connection_name,
                                      file_format=file_format,
                                      created_by=created_by,
                                      stage="Marlin",
                                      environment="Unit Testing"
                                      )
                api_new.save()
                status_code = "message"
                message = "Pipeline fetched and saved to database for validation!!"
            try:
                pipelineId_connDetails = APIresponse.query.with_entities(
                    APIresponse.pipeline_name, APIresponse.conn_details, APIresponse.connection_id).order_by(
                    desc(APIresponse.updatedon)).first()
                getResUserConn(pipelineId_connDetails, database_service_name, created_by)
            except Exception as e:
                print(e)


        else:
            status_code = "message"
            message = "Bad Request"

        mes = {status_code: message}
        return jsonify(mes)


def getResUserConn(ppidconnd, database_service_name, created_by):
    srctype = db2dbsrcconf
    try:
        adduser = user_connection_db2db(
            emp_id=created_by,
            test_environment="Unit Testing",
            stage="Marlin",
            platform="OnPremises",
            service=database_service_name,
            connection_name=srctype,
            connection_details=ppidconnd[1],
            pipeline_name=ppidconnd[0],
            created_on=datetime.now(),
            updated_on=datetime.now(),
            conn_id=ppidconnd[2]
        )
        adduser.save()
        message = "Source Configuration saved!!"
    except Exception as e:
        print("Exception", e)
