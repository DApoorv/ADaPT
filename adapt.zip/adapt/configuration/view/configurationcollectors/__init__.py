from .db2dbconfigcollector import *
