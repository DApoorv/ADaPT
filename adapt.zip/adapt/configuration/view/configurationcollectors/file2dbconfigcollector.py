from utils.defaults import validate_request
from pathlib import Path
from globals.constants import *
from flask.views import MethodView
from configuration.forms import *
from configuration.models import Services, Platform, TestLog, UserConnections, ApiConfig, \
    UserConnectionsManual, user_connection_f2db
from execution.models import MasterConfig, APIresponse, APIF2DB
from utils.serviceprovider import sp
from flask import render_template, redirect, url_for, flash, session, request, g
from datetime import datetime
import json
from itertools import chain
from configuration.view.appconfigcollector import *


class F2DBConfigCollector(MethodView):
    decorators = [validate_request]

    def get(self):
        if request.args:
            return self.process_args()
        db_form2 = ConfigureF2DB()

        # fetching platforms those have listed services
        platforms = Platform.query.select_from(Platform).join(Services).where(
            Platform.platform_name != 'NA').with_entities(Platform.platform_name).all()
        platform_list = [platform[0] for platform in platforms]

        return render_template(
            'execution/configuref2db.html',
            db_form4=platform_list,
            db_form2=db_form2
        )

    def process_args(self):
        val = request.args.get('val')
        data = request.args.get('data')
        print(val, data)

        if val == 'f2db-target-platform':
            source_plat = request.args.get('data')
            session['f2db-target-platform'] = source_plat
            conn_details = Services.query.where(Services.type_id.in_([4])).with_entities(
                Services.service_name).all()
            conn_details_list = []
            for conn in conn_details:
                for t in conn:
                    conn_details_list.append(t)
            return json.dumps(conn_details_list)

        elif val == 'f2db-target-services':
            etl = request.args.get('data')
            session['f2db-target-services'] = etl
            conn_details = Services.query.where(Services.service_name == etl).with_entities(
                Services.connection_details).all()
            det = conn_details[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            conn_det_list.remove('Table Name')
            return json.dumps(conn_det_list)
        elif val == 'f2db-platform-test-doc':
            session['f2db-platform-test-doc'] = data
            services = ServiceType.query.select_from(ServiceType).join(Services).join(Platform).where(
                Platform.platform_name == data)
            service_types = services.where(ServiceType.type_id != 5).with_entities(
                ServiceType.service_type).all()
            service_type_list = [service_type[0] for service_type in service_types]  # need to change here
            print("service_type_list", service_type_list)
            return json.dumps(service_type_list)

        elif val == 'f2db-test-doc-storage-type':
            platform = session['f2db-platform-test-doc']
            services = Services.query.select_from(Services).join(Platform).where(
                Platform.platform_name == platform).join(ServiceType).where(
                ServiceType.service_type == data).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]
            return json.dumps(service_list)

        elif val == 'f2db-test-doc-storage-service':
            session['f2db-test-doc-storage-service'] = data
            conn_det = Services.query.where(Services.resource_key == data.lower()).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            conn_det_list.remove('Table Name')
            return json.dumps(conn_det_list)

    def post(self):
        data = request.form.to_dict()
        form_name = data['identifier']
        if form_name == 'form1':
            platform = session.get('f2db-platform-test-doc')
            service = session.get('f2db-test-doc-storage-service')
            conn_name = f2dbsrcconf
            keylist = [key for key in data.keys() if 'Table Name' in key]
            import re
            data['Table Name'] = {re.split('\(|\)', key)[1]: data.pop(key) for key in keylist}
            param_list = \
                Services.query.with_entities(Services.connection_details).filter_by(service_name=service).all()[0][
                    0]
            connection_details = {}
            for key, value in param_list.items():
                connection_details[key] = {}
                for name in value:
                    connection_details[key][name.lower()] = data.get(name)
            conn = connection_details
            # conn= self.conn_details(db_form)
            message = f"For {platform} and {service} data got configured"
            adduser = user_connection_f2db(
                emp_id=session['user'],
                test_environment=session['environment'],
                stage=session['stage'],
                platform=platform,
                service=service,
                connection_name=conn_name,
                connection_details=conn,
                pipeline_name=data['source-pipeline'],
                created_on=datetime.now(),
                updated_on=datetime.now(),
                mode=data['mode_f2db_source']
            )
            adduser.save()

            api_new = APIF2DB(pipeline_id=0,
                              pipeline_name=data['source-pipeline'],
                              source=service,
                              start_time=None,
                              end_time=None,
                              user_name=None,
                              password=None,
                              file_path=None,
                              connection_url=None,
                              status=None,
                              updatedon=datetime.now(),
                              ingestion_type=None,
                              connection_id=None,
                              connection_name=conn_name,
                              file_format=None,
                              created_by=session['user'],
                              stage=session['stage'],
                              environment=session['environment'],
                              mode=data['mode_f2db_source']
                              )
            api_new.save()
        else:
            platform = session.get('f2db-target-platform')
            service = session.get('f2db-target-services')
            conn_name = f2dbtgtconf

            keylist = [key for key in data.keys() if 'Table Name' in key]
            import re
            data['Table Name'] = {re.split('\(|\)', key)[1]: data.pop(key) for key in keylist}
            param_list = \
                Services.query.with_entities(Services.connection_details).filter_by(service_name=service).all()[0][
                    0]
            connection_details = {}
            for key, value in param_list.items():
                connection_details[key] = {}
                for name in value:
                    connection_details[key][name.lower()] = data.get(name)
            conn = connection_details
            # conn = self.conn_details(db_form)
            message = f"For {platform} and {service} data got configured"

            adduser = user_connection_f2db(
                emp_id=session['user'],
                test_environment=session['environment'],
                stage=session['stage'],
                platform=platform,
                service=service,
                connection_name=conn_name,
                connection_details=conn,
                pipeline_name=data['target-pipeline'],
                created_on=datetime.now(),
                updated_on=datetime.now(),
                mode=data['mode_f2db_target']
            )
            adduser.save()

        flash(message)
        return redirect(url_for('configuration.f2db_field'))