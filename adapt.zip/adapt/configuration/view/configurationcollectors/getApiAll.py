import re

import requests
from sqlalchemy import desc, and_

from utils.defaults import validate_request
from pathlib import Path
from globals.constants import *
from flask.views import MethodView
from configuration.forms import *
from configuration.models import Services, Platform, TestLog, UserConnections, ApiConfig, user_connection_db2db
from execution.models import MasterConfig, APIresponse, APIJSONALL
from utils.pass_decrypt import decrypt_password
from utils.serviceprovider import sp
from flask import render_template, redirect, url_for, flash, session, request, g, jsonify
from datetime import datetime
import json
from itertools import chain
from configuration.view.appconfigcollector import *


class GetAPIAll(MethodView):

    def post(self):
        content_type = request.headers.get('Content-Type')
        if content_type == 'application/json':
            var = request.get_json()
            # api_data = APIJSONALL(data=var)
            # api_data.save()
            mes = "Data got saved!!"

        return jsonify(mes)
