from utils.defaults import validate_request
from pathlib import Path
from globals.constants import *
from flask.views import MethodView
from configuration.forms import *
from configuration.models import Services, Platform, TestLog, UserConnections, ApiConfig, UserConnectionsManual, \
    user_connection_db2db
from execution.models import MasterConfig, APIresponse
from utils.serviceprovider import sp
from flask import render_template, redirect, url_for, flash, session, request, g
from datetime import datetime
import json
from itertools import chain
from configuration.view.appconfigcollector import *


class DB2DBConfigCollector(MethodView):
    decorators = [validate_request]

    def get(self):
        if request.args:
            return self.process_args()
        db_form = ConfigureX2X()

        platforms = Platform.query.select_from(Platform).join(Services).where(
            Platform.platform_name != 'NA').with_entities(Platform.platform_name).all()
        platform_list = [platform[0] for platform in platforms]

        return render_template(
            'execution/configuredb2db.html',
            platform_list=platform_list,
            db_form=db_form,
            db_form2=db_form
        )

    def process_args(self):
        val = request.args.get('val')
        data = request.args.get('data')

        if val == 'db2db-source-platform':
            session['db2db-source-platform'] = data
            conn_details = Services.query.where(Services.type_id.in_([4])).with_entities(
                Services.service_name).all()
            conn_details_list = []
            for conn in conn_details:
                for t in conn:
                    conn_details_list.append(t)
            return json.dumps(conn_details_list)

        elif val == 'db2db-source-services':
            session['db2db-source-services'] = data
            conn_details = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_details[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            conn_det_list.remove('Table Name')
            return json.dumps(conn_det_list)

        elif val == 'db2db-target-platform':
            session['db2db-target-platform'] = data
            conn_details = Services.query.where(Services.type_id.in_([4])).with_entities(
                Services.service_name).all()
            conn_details_list = []
            for conn in conn_details:
                for t in conn:
                    conn_details_list.append(t)
            return json.dumps(conn_details_list)

        elif val == 'db2db-target-services':
            session['db2db-target-services'] = data
            conn_details = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_details[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            conn_det_list.remove('Table Name')
            return json.dumps(conn_det_list)

    def post(self):
        data = request.form.to_dict()
        form_name = data['identifier']
        if data:
            if form_name == 'form1':
                platform = session.get('db2db-source-platform')
                service = session.get('db2db-source-services')
                conn_name = db2dbsrcconf
                keylist = [key for key in data.keys() if 'Table Name' in key]
                import re
                data['Table Name'] = {re.split('\(|\)', key)[1]: data.pop(key) for key in keylist}
                param_list = \
                    Services.query.with_entities(Services.connection_details).filter_by(service_name=service).all()[
                        0][0]
                connection_details = {}
                for key, value in param_list.items():
                    connection_details[key] = {}
                    for name in value:
                        connection_details[key][name.lower()] = data.get(name)
                conn = connection_details
                # conn= self.conn_details(db_form)
                message = f"For {platform} and {service} data got configured"
                adduser = user_connection_db2db(
                    emp_id=session['user'],
                    test_environment=session['environment'],
                    stage=session['stage'],
                    platform=platform,
                    service=service,
                    connection_name=conn_name,
                    connection_details=conn,
                    pipeline_name=data['source-pipeline'],
                    created_on=datetime.now(),
                    updated_on=datetime.now(),
                    mode=data['mode_db2db_source']
                )
                adduser.save()

                api_new = APIresponse(
                    pipeline_id=0,
                    pipeline_name=data['source-pipeline'],
                    source_system=None,
                    start_time=None,
                    end_time=None,
                    conn_details=conn,
                    status=None,
                    updatedon=datetime.now(),
                    ingestion_type=None,
                    connection_id=None,
                    connection_name=conn_name,
                    file_format=None,
                    created_by=session['user'],
                    stage=session['stage'],
                    environment=session['environment'],
                    mode=data['mode_db2db_source']
                    )
                api_new.save()
            else:
                platform = session.get('db2db-target-platform')
                service = session.get('db2db-target-services')
                conn_name = db2dbtgtconf

                keylist = [key for key in data.keys() if 'Table Name' in key]
                import re
                data['Table Name'] = {re.split('\(|\)', key)[1]: data.pop(key) for key in keylist}
                param_list = Services.query.with_entities(
                    Services.connection_details).filter_by(
                    service_name=service).all()[0][0]
                connection_details = {}
                for key, value in param_list.items():
                    connection_details[key] = {}
                    for name in value:
                        connection_details[key][name.lower()] = data.get(name)
                conn = connection_details
                # conn = self.conn_details(db_form)
                message = f"For {platform} and {service} data got configured"
                adduser = user_connection_db2db(
                    emp_id=session['user'],
                    test_environment=session['environment'],
                    stage=session['stage'],
                    platform=platform,
                    service=service,
                    connection_name=conn_name,
                    connection_details=conn,
                    pipeline_name=data['target-pipeline'],
                    created_on=datetime.now(),
                    updated_on=datetime.now(),
                    mode=data['mode_db2db_target']
                )
                adduser.save()
        flash(message)
        return redirect(url_for("configuration.db_field"))