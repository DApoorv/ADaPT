import re

import requests
from sqlalchemy import desc, and_

from utils.defaults import validate_request
from pathlib import Path
from globals.constants import *
from flask.views import MethodView
from configuration.forms import *
from configuration.models import Services, Platform, TestLog, UserConnections, ApiConfig, \
    user_connection_f2db, UserConnectionSFDC2DB
from execution.models import MasterConfig, APIresponse, APIF2DB, ApiSFDC2DB
from utils.pass_decrypt import decrypt_password
from utils.serviceprovider import sp
from flask import render_template, redirect, url_for, flash, session, request, g, jsonify
from datetime import datetime
import json
from itertools import chain
from configuration.view.appconfigcollector import *

"""
Created by Apoorv Dubey 
Last updated on 017 June 2022
"""

def getResUserConn(pipe_det):

    password = decrypt_password(pipe_det[0][0])
    user_name = pipe_det[0][1]
    ingestion_type = pipe_det[0][2]
    connection_url = pipe_det[0][3]
    conn_id = pipe_det[0][4]
    pipeline_name = pipe_det[0][5]
    created_by = pipe_det[0][6]
    security_token = pipe_det[0][7]
    sandbox = pipe_det[0][8]

    conn_details_val = {}
    conn_details_val["password"] = password
    conn_details_val["username"] = user_name
    conn_details_val["host"] = connection_url
    conn_details_val["security_token"] = security_token
    conn_details_val["sandbox"] = sandbox

    conn_details_additional = {}
    conn_details_additional["table name"] = ""

    conn_details = {}
    conn_details["connection_details"] = conn_details_val
    conn_details["additional_details"] = conn_details_additional

    adduser = UserConnectionSFDC2DB(
        emp_id=created_by,
        test_environment="Unit Testing",
        stage="Marlin",
        platform="OnPremises",
        service=ingestion_type,
        connection_name=sfdc2dbsrcconf,
        connection_details=conn_details,
        created_on=datetime.now(),
        updated_on=datetime.now(),
        pipeline_name=pipeline_name,
        conn_id=conn_id
    )
    adduser.save()


class GetAPISFDC2DB(MethodView):

    def post(self):
        false = False
        true = True
        null = None
        content_type = request.headers.get('Content-Type')
        if content_type == 'application/json':
            var = request.get_json()
            pipeline_id = var.get("pipeline_id")
            pipeline_name = var.get("pipeline_name")
            ingestion_type = var.get("ingestion_type")
            status = var.get("status")
            source_system = var.get("source_system")
            connection_id = var.get("connection_id")
            connection_name = var.get("connection_name")
            connection_url = var.get("connection_url")
            user_name = var.get("user_name")
            password_encrypted = var.get("password_encrypted")
            security_token = var.get("security_token")
            start_time = var.get("start_time")
            end_time = var.get("end_time")
            file_format = var.get("file_format")
            created_by = var.get("created_by")
            sandbox = var.get("sandbox")

            vari = None
            counter = 0

            try:
                compare_res_str = pipeline_id + pipeline_name + source_system + status \
                                  + connection_url + ingestion_type
                vari = ApiSFDC2DB.query.filter(
                    ApiSFDC2DB.pipeline_id == pipeline_id).with_entities(
                    ApiSFDC2DB.pipeline_id, ApiSFDC2DB.pipeline_name, ApiSFDC2DB.source_system,
                    ApiSFDC2DB.status, ApiSFDC2DB.connection_url, ApiSFDC2DB.ingestion_type).all()

                vari2 = [[str(x) for x in tup] for tup in vari]
                conn_details_list = [''.join(tups) for tups in vari2]
                for var in conn_details_list:
                    if compare_res_str == var:
                        counter+=1
                if counter == 0 or vari is None:
                    api_new = ApiSFDC2DB(
                        pipeline_id=pipeline_id,
                        pipeline_name=pipeline_name,
                        ingestion_type=ingestion_type,
                        status=status,
                        source_system=source_system,
                        connection_id=connection_id,
                        connection_name=connection_name,
                        connection_url=connection_url,
                        user_name=user_name,
                        password_encrypted=password_encrypted,
                        security_token=security_token,
                        start_time=start_time,
                        end_time=end_time,
                        file_format=file_format,
                        created_by=created_by,
                        updatedon=datetime.now(),
                        sandbox=sandbox,
                        stage="Marlin",
                        environment="Unit Testing"
                      )
                    api_new.save()

                    status_code = "message"
                    message = "Pipeline fetched and saved to database for validation!!"
                    try:
                        pipe_det = ApiSFDC2DB.query.with_entities(
                            ApiSFDC2DB.password_encrypted, ApiSFDC2DB.user_name, ApiSFDC2DB.ingestion_type,
                            ApiSFDC2DB.connection_url, ApiSFDC2DB.connection_id, ApiSFDC2DB.pipeline_name,
                            ApiSFDC2DB.created_by, ApiSFDC2DB.security_token, ApiSFDC2DB.sandbox).order_by(
                            desc(ApiSFDC2DB.updatedon)).limit(1).all()
                        getResUserConn(pipe_det)
                    except Exception as e:
                        message = "Sorry! pipeline not got configured correctly."+str(e)
                else:
                    status_code = "message"
                    message = "Pipeline ID already exists!!"
            except Exception as e:
                status_code = "message"
                message = str(e)
        else:
            status_code = "message"
            message = "Bad Request"

        mes = {status_code: message}
        return jsonify(mes)


