from utils.defaults import validate_request
from flask import request, render_template
from configuration.models import Platform, Services, ServiceType, UserConnections
from sqlalchemy import or_
from itertools import chain
import json
from flask import session, redirect, render_template, url_for, flash
from flask.views import MethodView
from db import dbf_obj


class AppConfigCollector(MethodView):
    decorators = [validate_request]

    def get(self):
        if not request.args:
            # fetching platforms those have listed services
            platform_list = Platform.list_platforms_with_active_services
            return render_template('configuration/app_config.html', platforms=platform_list)
        # getting val and data attributes from the requests
        # the val attribute identifies the type of data coming in
        # the data attribute contains actual data
        val = request.args.get('val')
        data = request.args.get('data')
        # processing for etl configuration section of app config page
        
        if val == 'etl':
            session['etl_service'] = data
            conn_details = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_details[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            return json.dumps(conn_det_list)

        elif val == 'etl-platform':
            session['etl_platform'] = data
            services = Services.query.select_from(Services).join(Platform).where(Platform.platform_name == data)
            etl_services = services.where(Services.type_id == 5).with_entities(Services.service_name).all()
            # prep-step
            print(etl_services, type(etl_services))
            etl_service_list = [storage_service[0] for storage_service in etl_services]
            return json.dumps(etl_service_list)

        # processing for test doc section of app config page
        elif val == 'testdoc-platform':
            session['testdoc_platform'] = data
            services = ServiceType.query.select_from(ServiceType).join(Services).join(Platform).where(Platform.platform_name == data)
            service_types = services.where(ServiceType.type_id != 5).with_entities(ServiceType.service_type).all()
            service_type_list = [service_type[0] for service_type in service_types]
            return json.dumps(service_type_list)

        elif val == 'testdoc-servtype':
            print(data)
            platform = session['testdoc_platform']
            services = Services.query.select_from(Services).join(Platform).where(
                Platform.platform_name == platform).join(ServiceType).where(
                ServiceType.service_type == data).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]
            return json.dumps(service_list)

        elif val == 'testdoc-service':
            print(data)
            session['testdoc_service'] = data
            print(session['testdoc_service'])
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = det.get('connection_details')
            # conn_det_list = list(chain(*conn_details_list))
            conn_det_list = list(conn_details_list)
            return json.dumps(conn_det_list)

        # processing for test result section of app config page
        elif val == 'testresult-platform':
            print(data)
            session['testresult_platform'] = data
            services = Services.query.where(Services.type_id.in_([3,4,6,7])).join(Platform).where(
                or_(
                Platform.platform_name == data, Platform.platform_name == 'NA')).with_entities(Services.service_name).all()

            service_list = [service[0] for service in services]
            return json.dumps(service_list)

        elif val == 'testresult-service':
            print(data)
            session['testresult_service'] = data
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = [val for key, val in det.items()]
            # quickfix
            conn_det_list = list(chain(*conn_details_list))
            if 'Table Name' in conn_det_list:
                conn_det_list.remove('Table Name')
                conn_det_list.extend(['Table Name (f2f)', 'Table Name (db2db)', 'Table Name (orch)'])
            return json.dumps(conn_det_list)

        elif val == 'metrics-platform':
            session['metrics_platform'] = data
            services = Services.query.where(Services.type_id.in_([3, 4, 6])).join(Platform).where(or_(
                Platform.platform_name == data, Platform.platform_name == 'NA')
                ).with_entities(Services.service_name).all()
            service_list = [service[0] for service in services]
            print(data)
            if data == 'Amazon Web Services':
                service_list = ['Postgresql']
            return json.dumps(service_list)

        elif val == 'metrics-service':
            session['metrics_service'] = data
            conn_det = Services.query.where(Services.service_name == data).with_entities(
                Services.connection_details).all()
            det = conn_det[0][0]
            conn_details_list = [val for key, val in det.items()]
            conn_det_list = list(chain(*conn_details_list))
            return json.dumps(conn_det_list)

        else:
            request.query_string

    def etl(self):
        pass

    def post(self):
        """
        :return: save the Application Configuration
        """
        # handling post requests
        if request.method == 'POST':
            # store stage and env values
            if not session.get('user'):
                return redirect(url_for('/'))
            
            val = request.form.get('form-name')
            print(session.get('testdoc_service'), session.get('testresult_service'))

            if val.lower().startswith('etl'):
                platform = session.get('etl_platform')
                service = session.get('etl_service')
                session.pop('etl_platform')
                session.pop('etl_service')

            elif val.lower().startswith('testdoc'):
                platform = session.get('testdoc_platform')
                service = session.get('testdoc_service')
                session['testdoc_platform'] = None
                session['testdoc_service'] = None

            elif val.lower().startswith('testresult'):
                platform = session.get('testresult_platform')
                service = session.get('testresult_service')
                session.pop('testresult_platform')
                session.pop('testresult_service')

            elif val.lower().startswith('metrics'):
                platform = session.get('metrics_platform')
                service = session.get('metrics_service')
                session.pop('metrics_platform')
                session.pop('metrics_service')

            username = session['user']
            env = session['environment']
            stage = session['stage']

            # prepping connection_details as identified by the validation engine
            con_det = request.form.to_dict()
            form_name = con_det.pop('form-name')
            
            # quickfix
            # Test Result Storage needs various tables to store test results. 
            # Accommodating tables for f2f and db2db in the same configuration here
            if form_name == 'TestResult Storage Configuration':
                keylist = [key for key in con_det.keys() if 'Table Name' in key]
                import re
                con_det['Table Name'] = {re.split('\(|\)', key)[1]: con_det.pop(key) for key in keylist}

            # listing service parameters
            param_list = Services.query.with_entities(Services.connection_details).filter_by(service_name=service).all()[0][0]
            connection_details = {}
            # forming the connection details dictionary to store in the table
            for key, value in param_list.items():
                connection_details[key] = {}
                for name in value:
                    connection_details[key][name.lower()] = con_det.get(name)
            connection_name = val
            new_conn = UserConnections(
                connection_name=connection_name,
                emp_id=username,
                test_environment=env,
                stage=stage,
                platform=platform,
                service=service,
                connection_details=connection_details
            )
            db = dbf_obj.get_dbase()
            db.session.add(new_conn)
            db.session.commit()

        flash('Successfully saved result')
        return redirect(url_for('configuration.add_app_configuration'))
