# encoded in UTF-8
from typing import Dict, List
from flask.helpers import flash
from sqlalchemy.sql.expression import desc
from db import dbf_obj

db = dbf_obj.get_dbase()


class Platform(db.Model):
    platform_id = db.Column(db.Integer, primary_key=True)
    platform_name = db.Column(db.String(80), nullable=False, unique=True)

    def __repr__(self):
        return '<Platform %r>' % self.platform_name

    @staticmethod
    def list_platforms():
        platforms = [plt[0] for plt in Platform.query.where(
            Platform.platform_name != 'NA').with_entities(Platform.platform_name).all()]
        return dict(platforms=platforms)

    @property
    def list_platforms_with_active_services():
        platforms = [plt[0] for plt in Platform.query.select_from(Platform).join(Services).where(
            Platform.platform_name != 'NA').with_entities(Platform.platform_name).all()]
        return dict(platforms=platforms)


class ServiceType(db.Model):
    type_id = db.Column(db.Integer, primary_key=True)
    service_type = db.Column(db.String(80), unique=True, nullable=False)

    def __repr__(self):
        return '<ServiceType %r>' % self.service_type

    @staticmethod
    def list_service_types():
        service_types = [serv_type[0] for serv_type in ServiceType.query.with_entities(ServiceType.service_type).all()]
        return dict(service_types=service_types)


class Services(db.Model):
    service_id = db.Column(db.Integer, primary_key=True)
    type_id = db.Column(db.Integer, db.ForeignKey('service_type.type_id', ondelete='CASCADE'), nullable=False)
    service_type = db.relationship('ServiceType', backref='services', lazy=True)
    platform_id = db.Column(db.Integer, db.ForeignKey('platform.platform_id', ondelete='CASCADE'), nullable=False)
    platform = db.relationship('Platform', backref='services', lazy=True)
    service_name = db.Column(db.String(80), unique=True, nullable=False)
    resource_key = db.Column(db.String(30), unique=True, nullable=False)
    connection_details = db.Column(db.JSON, nullable=False)

    def __repr__(self):
        return '<Services %r>' % self.service_name

    @staticmethod
    def list_services(platform=None, service_type=None):
        """function list services based on provided service type and platform;
        Else lists all the available services"""
        if service_type and platform:
            services = Services.query.join(Platform).where(
                Platform.platform_name.in_([platform, 'NA'])
            ).join(ServiceType).filter_by(service_type=service_type).all()
        elif service_type:
            services = Services.query.join(ServiceType).filter_by(service_type=service_type).all()
        elif platform:
            services = Services.query.join(Platform).where(Platform.platform_name.in_([platform, 'NA'])).all()
        else:
            services = Services.query.all()
        # services = [serv.service_name for serv in services]
        return dict(services=services)

    def get_config_options(arg):
        serv = Services.query.filter_by(service_name=arg).first()
        if not serv:
            serv = Services.query.filter_by(resource_key=arg).first()
        try:
            return serv.connection_details
        except AttributeError:
            flash("Ensure that the parameter sent is a service_name or a resource_key")
            return 404

    def get_platform(arg):
        serv = Services.query.filter_by(service_name=arg).first()
        if not serv:
            serv = Services.query.filter_by(resource_key=arg).first()
        try:
            return serv.platform.platform_name
        except AttributeError:
            flash("Ensure that the parameter sent is a service_name or a resource_key")
            return 404

    @classmethod
    def get_service_by_type_by_platform(cls, platform, service_type: List):
        """
        params: list of service_types
        returns a list of services based on their service type
        Services are classified as:
        1. ObjectStore e.g. AWS S3
        2. FileStore e.g. Filesystem
        3. NoSqlDBMS e.g. MongoDB
        4. SqlDBMS e.g. Postgresql
        5. ETLServices e.g. AWS Glue
        6. Datawarehouse e.g. GCP Bigquery
        7. QueryService e.g. AWS Athena
        8. Orchestration Tool e.g. Airflow
        """
        pass

    @classmethod
    def get_resource_key(cls, service):
        return Services.query.where(Services.service_name == service).first().resource_key

    @classmethod
    def get_service(cls, filter_by: Dict):
        return Services.query.filter_by(**filter_by).first()


class UserConnections(db.Model):
    __tablename__ = "user_connection_new"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String(80), nullable=False)
    test_environment = db.Column(db.String(80), nullable=False)
    stage = db.Column(db.String(80), nullable=False)
    platform = db.Column(db.String(80), nullable=False)
    service = db.Column(db.String(80), nullable=False)
    connection_name = db.Column(db.String(80), nullable=False)
    connection_details = db.Column(db.JSON, nullable=False)
    created_on = db.Column(db.DateTime, server_default=db.func.now())
    updated_on = db.Column(db.DateTime, server_default=db.func.now(), server_onupdate=db.func.now())
    pipeline_name = db.Column(db.String)
    conn_id = db.Column(db.Integer)

    def __init__(self, emp_id, test_environment, stage, platform, service, connection_name,
                 connection_details, pipeline_name, created_on, updated_on, conn_id):
        self.connection_name = connection_name
        self.emp_id = emp_id
        self.test_environment = test_environment
        self.stage = stage
        self.platform = platform
        self.service = service
        self.connection_details = connection_details
        self.pipeline_name = pipeline_name
        self.created_on = created_on
        self.updated_on = updated_on
        self.conn_id = conn_id

    def __repr__(self):
        return '<UserConnections %r>' % self.connection_name

    def save(self):
        db.session.add(self)
        db.session.commit()

    @staticmethod
    def get_connection(connection_name: str, filter_by: Dict = None):
        """fetches the latest connection saved by the given connection name"""
        intm_query = UserConnections.query.filter_by(connection_name=connection_name)
        if filter_by:
            intm_query = intm_query.filter_by(**filter_by)

        return intm_query.order_by(desc(UserConnections.updated_on)).first()

    @staticmethod
    def get_connectionbypipe(connection_name: str, filter_by: Dict = None):
        """fetches the latest connection saved by the given connection name"""
        intm_query = UserConnections.query.filter_by(connection_name=connection_name)
        if filter_by:
            intm_query = intm_query.filter_by(**filter_by)
        return intm_query.order_by(desc(UserConnections.updated_on)).first()

    @staticmethod
    def get_conf_details(connection_name: str, filter_by: Dict = None):
        """fetches the latest connection saved by the given connection name"""
        intm_query = UserConnections.query.filter_by(connection_name=connection_name)
        if filter_by:
            intm_query = intm_query.filter_by(**filter_by)
        return intm_query.order_by(desc(UserConnections.updated_on)).first()


class user_connection_db2db(db.Model):
    __tablename__ = "user_connection_db2db"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String(80), nullable=False)
    test_environment = db.Column(db.String(80), nullable=False)
    stage = db.Column(db.String(80), nullable=False)
    platform = db.Column(db.String(80), nullable=False)
    service = db.Column(db.String(80), nullable=False)
    connection_name = db.Column(db.String(80), nullable=False)
    connection_details = db.Column(db.JSON, nullable=False)
    created_on = db.Column(db.DateTime, server_default=db.func.now())
    updated_on = db.Column(db.DateTime, server_default=db.func.now(), server_onupdate=db.func.now())
    pipeline_name = db.Column(db.String)
    mode = db.Column(db.String)

    def __init__(self, emp_id, test_environment, stage, platform, service, connection_name,
                 connection_details, pipeline_name, created_on, updated_on, mode):
        self.connection_name = connection_name
        self.emp_id = emp_id
        self.test_environment = test_environment
        self.stage = stage
        self.platform = platform
        self.service = service
        self.connection_details = connection_details
        self.pipeline_name = pipeline_name
        self.created_on = created_on
        self.updated_on = updated_on
        self.mode = mode

    def __repr__(self):
        return '<UserConnections %r>' % self.connection_name

    def save(self):
        db.session.add(self)
        db.session.commit()


class user_connection_f2db(db.Model):
    __tablename__ = "user_connection_f2db"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String)
    test_environment = db.Column(db.String)
    stage = db.Column(db.String)
    platform = db.Column(db.String)
    service = db.Column(db.String)
    connection_name = db.Column(db.String)
    connection_details = db.Column(db.JSON)
    created_on = db.Column(db.DateTime)
    updated_on = db.Column(db.DateTime)
    pipeline_name = db.Column(db.String)
    mode = db.Column(db.String)

    def __init__(self, emp_id, test_environment, stage, platform, service, connection_name,
                 connection_details, pipeline_name, created_on, updated_on, mode):
        self.connection_name = connection_name
        self.emp_id = emp_id
        self.test_environment = test_environment
        self.stage = stage
        self.platform = platform
        self.service = service
        self.connection_details = connection_details
        self.pipeline_name = pipeline_name
        self.created_on = created_on
        self.updated_on = updated_on
        self.mode = mode

    def __repr__(self):
        return '<UserConnections %r>' % self.connection_name

    def save(self):
        db.session.add(self)
        db.session.commit()


class user_connection_f2f(db.Model):
    __tablename__ = "user_connection_f2f"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String)
    test_environment = db.Column(db.String)
    stage = db.Column(db.String)
    platform = db.Column(db.String)
    service = db.Column(db.String)
    connection_name = db.Column(db.String)
    connection_details = db.Column(db.JSON)
    created_on = db.Column(db.DateTime)
    updated_on = db.Column(db.DateTime)
    pipeline_name = db.Column(db.String)
    mode = db.Column(db.String)

    def __init__(self, emp_id, test_environment, stage, platform, service, connection_name,
                 connection_details, pipeline_name, created_on, updated_on, mode):
        self.connection_name = connection_name
        self.emp_id = emp_id
        self.test_environment = test_environment
        self.stage = stage
        self.platform = platform
        self.service = service
        self.connection_details = connection_details
        self.pipeline_name = pipeline_name
        self.created_on = created_on
        self.updated_on = updated_on
        self.mode = mode

    def __repr__(self):
        return '<UserConnections %r>' % self.connection_name

    def save(self):
        db.session.add(self)
        db.session.commit()


class UserConnectionsManual(db.Model):
    __tablename__ = "user_connection_manual"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String(80), nullable=False)
    test_environment = db.Column(db.String(80), nullable=False)
    stage = db.Column(db.String(80), nullable=False)
    platform = db.Column(db.String(80), nullable=False)
    service = db.Column(db.String(80), nullable=False)
    connection_name = db.Column(db.String(80), nullable=False)
    connection_details = db.Column(db.JSON, nullable=False)
    created_on = db.Column(db.DateTime, server_default=db.func.now())
    updated_on = db.Column(db.DateTime, server_default=db.func.now(), server_onupdate=db.func.now())
    pipeline_name = db.Column(db.String)

    def __init__(self, emp_id, test_environment, stage, platform, service, connection_name,
                 connection_details, pipeline_name, created_on, updated_on):
        self.connection_name = connection_name
        self.emp_id = emp_id
        self.test_environment = test_environment
        self.stage = stage
        self.platform = platform
        self.service = service
        self.connection_details = connection_details
        self.pipeline_name = pipeline_name
        self.created_on = created_on
        self.updated_on = updated_on

    def __repr__(self):
        return '<UserConnections %r>' % self.connection_name

    def save(self):
        db.session.add(self)
        db.session.commit()


class UserConnectionSFDC2DB(db.Model):
    __tablename__ = "user_connection_sfdc2db"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String)
    test_environment = db.Column(db.String)
    stage = db.Column(db.String)
    platform = db.Column(db.String)
    service = db.Column(db.String)
    connection_name = db.Column(db.String)
    connection_details = db.Column(db.JSON)
    created_on = db.Column(db.DateTime)
    updated_on = db.Column(db.DateTime)
    pipeline_name = db.Column(db.String)
    conn_id = db.Column(db.Integer)

    def __init__(self, emp_id, test_environment, stage, platform, service, connection_name,
                 connection_details, pipeline_name, created_on, updated_on, conn_id):
        self.connection_name = connection_name
        self.emp_id = emp_id
        self.test_environment = test_environment
        self.stage = stage
        self.platform = platform
        self.service = service
        self.connection_details = connection_details
        self.pipeline_name = pipeline_name
        self.created_on = created_on
        self.updated_on = updated_on
        self.conn_id = conn_id

    def __repr__(self):
        return '<UserConnections %r>' % self.connection_name

    def save(self):
        db.session.add(self)
        db.session.commit()


class Stage(db.Model):
    stage_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    stage_name = db.Column(db.String(80), nullable=False)

    def __repr__(self):
        return '<Stage %r>' % self.stage_name

    @staticmethod
    def list_stages():
        stage_list = [stage[0] for stage in Stage.query.with_entities(Stage.stage_name).all()]
        return stage_list


class TestEnvironment(db.Model):
    test_env_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    test_env_name = db.Column(db.String(80), nullable=False)

    def __repr__(self):
        return '<TestEnvironment %r>' % self.test_env_name

    @staticmethod
    def list_environments():
        env_list = [env[0] for env in TestEnvironment.query.with_entities(TestEnvironment.test_env_name).all()]
        return env_list


class TestLog(db.Model):
    __tablename__ = "user_test_log_new"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.Text)
    environment = db.Column(db.Text)
    stage = db.Column(db.Text)
    document_type = db.Column(db.Text)
    document_name = db.Column(db.Text)
    document_path = db.Column(db.Text)
    document_link = db.Column(db.Text)
    time_stamp = db.Column(db.DateTime)

    def __init__(self, username, time_stamp, environment, stage, document_type, document_link, document_path,
                 document_name):
        self.username = username
        self.time_stamp = time_stamp
        self.document_type = document_type
        self.document_link = document_link
        self.document_path = document_path
        self.document_name = document_name
        self.environment = environment
        self.stage = stage

    def __str__(self) -> str:
        return self.document_name

    def __repr__(self):
        return '<TestLog %r>' % self.document_name

    @staticmethod
    def get_log(filter_by: Dict):
        res = None
        if filter_by:
            res = TestLog.query.filter_by(**filter_by).order_by(desc(TestLog.time_stamp)).all()
        return res

    def save(self):
        db.session.add(self)
        db.session.commit()


class ApiConfig(db.Model):
    __tablename__ = 'apiconfig'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    driver_name = db.Column(db.String(300), unique=True, nullable=False)
    db_service = db.Column(db.String(300), nullable=False)
    db_type_id = db.Column(db.Integer, nullable=False)

    def __init__(self, driver_name, db_service, db_type_id) -> None:
        self.driver_name = driver_name
        self.db_service = db_service
        self.db_type_id = db_type_id

    def __repr__(self) -> str:
        return '<ApiConfig %r>' % self.driver_name

    @classmethod
    def get_dataneeded(cls, driver_name):
        return cls.query.filter_by(driver_name=driver_name).first().db_service


class BucketConfig(db.Model):
    __tablename__ = 'bucketconfig'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    test_case = db.Column(db.String(300), unique=True, nullable=False)
    bucket_rule = db.Column(db.String(300), nullable=False)
    data_needed = db.Column(db.String(100), nullable=False)

    def __init__(self, test_case, bucket_rule, data_needed) -> None:
        self.test_case = test_case
        self.bucket_rule = bucket_rule
        self.data_needed = data_needed

    def __repr__(self) -> str:
        return '<BucketConfig %r>' % self.test_case

    @classmethod
    def get_dataneeded(cls, bucket_rule):
        return cls.query.filter_by(bucket_rule=bucket_rule).first().data_needed

    @classmethod
    def get_bucketrules(cls):
        return [row.bucket_rule for row in cls.query.distinct(cls.bucket_rule).all()]

    @classmethod
    def get_testcasesbyBucketRule(cls, bucket_rule=None):
        if bucket_rule:
            return [row.test_case for row in cls.query.filter_by(bucket_rule=bucket_rule).all()]
        test_cases = cls.query.with_entities(cls.bucket_rule, cls.test_case).all()
        testcasesbyBucketRule = {}
        for row in test_cases:
            if row[0] not in testcasesbyBucketRule:
                testcasesbyBucketRule[row[0]] = []
            testcasesbyBucketRule[row[0]].append(row[1])
        return testcasesbyBucketRule

    def save(self):
        db.session.add(self)
        db.session.commit()

    @classmethod
    def update_testcasename(cls, new_val, filter_by):
        row = cls.query.filter_by(**filter_by).one()
        row.test_case = new_val
        db.session.commit()
