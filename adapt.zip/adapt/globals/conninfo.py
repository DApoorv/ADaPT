from typing import Dict
from pathlib import Path
from flask import g


class ConnectionDetails:
    """class to ensure connection details are specific the service that will be called"""
    def __init__(self, service, con:Dict) -> None:
        if service == 'Linux':
            self.host = con.get('host')
            self.path = Path(con.get('path')).joinpath(g.current_env+'/'+g.current_stage)
            self.port = con.get('port')
        elif service == 'Minio':
            self.bucket = con.get("bucket name")
            self.access_key = con.get("access key")
            self.secret_key = con.get("secret key")
            self.path = '/' + str(g.current_env) + '/' + str(g.current_stage)
        elif service == 'S3':
            self.bucket = con.get("bucket name")
            self.access_key = con.get("access key")
            self.secret_key = con.get("secret access key")
            self.path = '/' + str(g.current_env) + '/' + str(g.current_stage)

        