from flask import request

class FileUploadResponse:
    def __init__(self, filename, filepath, downloadable_link) -> None:
        self.document_path = filepath
        self.document_name = filename
        self.document_link = downloadable_link
        if request.path == '/upload':
            self.document_type = 'Test Doc'
        elif request.path == '/accelerators/test-script-gen':
            self.document_type = request.form.get('identifier')


