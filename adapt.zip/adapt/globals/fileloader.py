from configuration.forms import SingleFileUploadForm
from configuration.models import UserConnections, TestLog
from werkzeug.utils import secure_filename
from utils.serviceprovider import sp
from globals.response import FileUploadResponse
from datetime import datetime
from flask import g


class SingleFileLoader:
    def save(self):
        form = SingleFileUploadForm()
        if form.validate_on_submit():
            file = form.file.data
            file.id = form.identifier.data
            file.filename = secure_filename(file.filename)
            #1st: file's content. 2nd: naming the file in s3. 3rd: actual filename. 4th: folder where file's to be stored
            # self.save(file)

            service = sp(self.connection_name)
            print(service)
            try:
                res = service.upload(file, self.con)
                self.metadata_save(res)
            except OSError as e:
                message = str(e)
            except Exception as e:
                message = str(e)
            else:
                message = "File saved successfully"
            finally:
                return message
            
    def parse_connection_details(self, con: UserConnections):
        """parse connection details for linux File Store"""
        from globals.conninfo import ConnectionDetails
        connection_info = con.connection_details

        try:
            connection_info = {
                **connection_info.get('connection_details'), 
                **connection_info.get('additional_details')
            }
        except TypeError as e:
            connection_info = {
                **connection_info.get('connection_details')
            }

        con = ConnectionDetails(con.service, connection_info)
        return con
    
    def metadata_save(self, res: FileUploadResponse):
        metadata = TestLog(
            username=g.current_user,
            environment=g.current_env,
            stage=g.current_stage,
            document_type=res.document_type,
            document_link=res.document_link,
            document_path=res.document_path,
            document_name=res.document_name,
            time_stamp=datetime.now()
        )
        metadata.save()
        return 'OK'