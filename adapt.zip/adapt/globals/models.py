from db import dbf_obj

db = dbf_obj.get_dbase()

class ModifiableModel:
    def save(self):
        db.session.add(self)
        db.session.commit()


class AdminModifiableModel:
    def save(self):
        message = """Can't save. Only Admin functionality.
        Admin-modifiable methods are yet to be created."""
        return message
