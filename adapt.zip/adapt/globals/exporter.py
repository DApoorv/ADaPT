from flask.views import MethodView
from utils.serviceprovider import sp
from globals.constants import *
from pathlib import Path


class FileExporter(MethodView):

    def get(self, filepath):
        self.connection_name = testdocstorage
        #service = sp(self.connection_name)
        #service.download(filepath)
        from flask import send_file
        path = Path(filepath)
        return send_file(path, as_attachment=True)


