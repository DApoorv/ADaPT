# file to define constants,

# connection name identifiers
testdocstorage = 'TestDoc Storage Configuration'
testresstorage = 'TestResult Storage Configuration'
mismatchrecord = 'Mismatch Record'
etlconf = 'ETL Configuration'
metadatastorage = 'Metadata Storage Configuration'
db2dbsrcconf = 'Db2Db Source Configuration'
db2dbtgtconf = 'Db2Db Target Configuration'
f2fsrcconf = 'F2F Source Configuration'
f2ftgtconf = 'F2F Target Configuration'
f2dbsrcconf = 'F2Db Source Configuration'
f2dbtgtconf = 'F2Db Target Configuration'
metricstorageconf = 'Metrics Storage Configuration'
orchconf = 'Orchestration Configuration'
apiConf = 'Db2Db API Configuration'
sfdc2dbsrcconf = 'SFDC2Db Source Configuration'
sfdc2dbtgtconf = 'SFDC2Db Target Configuration'


