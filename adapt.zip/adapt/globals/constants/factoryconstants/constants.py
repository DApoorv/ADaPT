# factory constants

# airflow factory
airflowconf = 'airflowconn'
airflowclient = 'airflowapiclient'

# Orchestrate factory = Dag factory
dags = 'dags'

# Platform factory
# These names of platforms should match their counter part in the Platform Table
gcp = 'Google Cloud Platform'
aws = 'Amazon Web Services'
onprem = 'OnPremises'