from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField, IntegerField
from wtforms.validators import InputRequired, Email, EqualTo, Regexp
from wtforms.widgets.core import ListWidget, TableWidget


class RegistrationForm(FlaskForm):
    emp_id = IntegerField(label='Employee Id', validators=[InputRequired()],
                          description='Employee SAP id', render_kw={'placeholder': 'Enter your SAP ID'})
    name = StringField(label='Name', validators=[InputRequired()], description='Employee\'s name',
                       render_kw={'placeholder': 'Enter your full name'})
    email = StringField(label='Email Id', validators=[InputRequired(), Email()],
                        render_kw={'placeholder': 'Enter your email id'})
    password = PasswordField(validators=[InputRequired(), EqualTo('confirm_password')],
                             render_kw={'placeholder': 'Set your password'})
    confirm_password = PasswordField(validators=[InputRequired()],
                                     render_kw={'placeholder': 're-enter password'})
    submit = SubmitField()
