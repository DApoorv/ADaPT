from db import dbf_obj
from user.helpers.login_manager import login_manager
db = dbf_obj.get_dbase()


class User(db.Model):
    __tablename__ = "user_entry"
    sno = db.Column(db.Integer, autoincrement=True)
    emp_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(500), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

    @staticmethod
    def is_active():
        """True, as all users are active."""
        return True

    def get_id(self):
        """Return the email address to satisfy Flask-Login's requirements."""
        return self.emp_id

    def is_authenticated(self):
        """Return True if the user is authenticated."""
        return self.authenticated

    @staticmethod
    def is_anonymous():
        """False, as anonymous users aren't supported."""
        return False

    @classmethod
    @login_manager.user_loader
    def user_loader(cls, user_id):
        """Given *user_id*, return the associated User object.

        :param unicode user_id: user_id (emp_id) user to retrieve

        """
        return User.query.get(user_id)




