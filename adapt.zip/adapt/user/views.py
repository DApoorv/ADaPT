import functools
import json
from functools import wraps

import jwt
import requests
from sqlalchemy.exc import IntegrityError
from flask import request, render_template, redirect, url_for, session, flash, jsonify, make_response

from config import *
from user.models import *
from db import dbf_obj
from werkzeug.security import generate_password_hash, check_password_hash
from user.forms import RegistrationForm
from datetime import datetime, timedelta


def redirect_view():
    return redirect(url_for('user.login_first'))


def trial_view():
    if request.method == 'GET':
        print("_" * 10, True)
        print(request)
    db = dbf_obj.get_db()
    new_user = User(
        emp_id=3,
        username='user3',
        password=generate_password_hash("password"),
        email='user3@user.com'
    )
    print(db.session)
    db.session.add(new_user)
    db.session.commit()
    x = User.query.filter_by(username='admin').first()
    print(x)
    dbf_obj.close_db()
    return 'Hello, World!'


def register_user():
    if request.method == 'GET':
        form = RegistrationForm()
        return render_template('user/register.html', form=form)
    elif request.method == 'POST':
        form = RegistrationForm(request.form)
        print(form.validate_on_submit())
        if form.validate_on_submit():
            print(request.form.to_dict())
            db = dbf_obj.get_dbase()
            emp_id = request.form['emp_id']
            username = request.form['name']
            password = request.form['password']
            email = request.form['email']
            _hashed_password = generate_password_hash(password)
            try:
                new_user = User(emp_id=emp_id, username=username, password=_hashed_password, email=email)
                db.session.add(new_user)
                db.session.commit()
                message = 'User registered successfully. Proceed to login.'
            except IntegrityError as e:
                message = 'User data exists in records. Please ensure correctness of data provided or try logging in.'
            flash(message)
            return redirect(url_for('user.login_first'))
        else:
            message = 'User Data Validation failed. Please try again'
        flash(message)
        return render_template('user/register.html', form=form)

def redirect_URL(func):
    @wraps(func)
    def decorated(*args, **kwargs):
        try:
            if request.url:
                url = 'https://myvmware-stg.workspaceair.com/SAAS/auth/oauth2/authorize?response_type=code&client_id' \
                      '='+CLIENT_ID+'&redirect_uri='+REDIRECT_URL+'&state' \
                      '='+SECRET_KEY+'&scope=openid+user+email+profile'
                return redirect(url, 302)
        except:
            return jsonify({'Message': 'Invalid'}), 403
        return func(*args, **kwargs)
    return decorated

# @redirect_URL
def login_first():
    """method renders the login page"""
    if request.method == 'GET':
        print(session)
        print('hello..Login\n returning template')
        return render_template('user/login.html')
    if request.method == 'POST':
        """cred = request.form.to_dict()
        user = User.query.filter_by(username=cred['username']).all()[0]
        login_checkpoint(user)"""
        user_frm_form = request.form.get('username')
        print(user_frm_form)
        token = request.args.get('code')
        if not token:
            # return "INVALID TOKEN!!"
            session['user'] = user_frm_form
            user = User.query.with_entities(User.username).all()
            all_admin_users = []
            for i in user:
                for j in i:
                    all_admin_users.append(j)
            session['all_admin_users'] = all_admin_users
            if session['user'] in all_admin_users:
                return redirect(url_for('configuration.index'))
            else:
                flash("Contact admin team to register!")
                return redirect(url_for('user.login_first'))

        else:
            import base64
            url = "https://myvmware-stg.workspaceair.com/SAAS/auth/oauthtoken?grant_type=authorization_code&code=" \
                  + token + "&redirect_uri="+REDIRECT_URL

            auth_code = CLIENT_ID + ":" + SECRET_KEY
            sample_string_bytes = auth_code.encode("ascii")
            auth_code_encoded = base64.b64encode(sample_string_bytes)
            base64_string = auth_code_encoded.decode("ascii")
            headers = {
                "Authorization": "Basic " + base64_string,
                "Content-Type": "application/x-www-form-urlencoded"
            }
            res = requests.post(url=url, headers=headers)
            json_data = json.loads(res.text)
            try:
                scope = json_data.get('scope')
                access_token = json_data.get('access_token')
                token_type = json_data.get('token_type')
                expires_in = json_data.get('expires_in')
                refresh_token = json_data.get('refresh_token')
                id_token = json_data.get('id_token')

                true = True
                false = False

                access_token_all = jwt.decode(access_token, algorithms=['RS256'], options={"verify_signature": False})
                refresh_token_all = jwt.decode(id_token, algorithms=['RS256'], options={"verify_signature": False})
                print("Hey..1", refresh_token_all)

                user = User.query.with_entities(User.username).all()
                all_admin_users = []
                for i in user:
                    for j in i:
                        all_admin_users.append(j)
                session['all_admin_users'] = all_admin_users

                if refresh_token_all['email_verified'] == True:
                    username = refresh_token_all['email'].split("@")[0]
                    if user_frm_form == username:
                        exp_time = refresh_token_all['exp']
                        session["user"] = username
                        session["exp_time"] = username
                        return redirect(url_for('configuration.index'))
                    else:
                        return "User Not veified!!"
                else:
                    return "User Not veified!!"
            except Exception as e:
                print(e)




def login_checkpoint():
    """method acts as a checkpoint for details user has logged in with
    and redirects to the index page"""

    token = request.args.get('code')
    if not token:
        return "INVALID TOKEN!!"
    else:
        import base64
        url = "https://myvmware-stg.workspaceair.com/SAAS/auth/oauthtoken?grant_type=authorization_code&code=" \
                  + token + "&redirect_uri="+REDIRECT_URL

        auth_code = CLIENT_ID + ":" + SECRET_KEY
        sample_string_bytes = auth_code.encode("ascii")
        auth_code_encoded = base64.b64encode(sample_string_bytes)
        base64_string = auth_code_encoded.decode("ascii")
        headers = {
            "Authorization": "Basic " + base64_string,
            "Content-Type": "application/x-www-form-urlencoded"
        }
        res = requests.post(url=url, headers=headers)
        json_data = json.loads(res.text)
        try:
            scope = json_data.get('scope')
            access_token = json_data.get('access_token')
            token_type = json_data.get('token_type')
            expires_in = json_data.get('expires_in')
            refresh_token = json_data.get('refresh_token')
            id_token = json_data.get('id_token')

            true = True
            false = False

            access_token_all = jwt.decode(access_token, algorithms=['RS256'], options={"verify_signature": False})
            refresh_token_all = jwt.decode(id_token, algorithms=['RS256'], options={"verify_signature": False})
            print("Hey..2",refresh_token_all)

            user = User.query.with_entities(User.username).all()
            all_admin_users = []
            for i in user:
                for j in i:
                    all_admin_users.append(j)
            session['all_admin_users'] = all_admin_users

            if refresh_token_all['email_verified'] == True:
                username = refresh_token_all['email'].split("@")[0]
                exp_time = refresh_token_all['exp']
                session["user"] = username
                session["exp_time"] = username
                return redirect(url_for('configuration.index'))
            else:
                return "User-Token Not veified!!"
        except Exception as e:
            print(e)


def logout():
    """logs out user"""
    if not session.get("user"):
        return redirect(url_for('user.login_first'))
    session.clear()
    return redirect("/")
