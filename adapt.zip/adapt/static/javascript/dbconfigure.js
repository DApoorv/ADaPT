function open_section(evt, table){
    tabcontent = document.getElementsByClassName("output-block-table");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("output-toggle-bar");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    evt.currentTarget.className += " active";
    document.getElementById(table).style.display = "block";
    console.log(evt.currentTarget.className)
    console.log(table);
    console.log(evt);
}
