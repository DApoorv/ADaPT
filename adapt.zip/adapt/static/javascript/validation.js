	// Disable form submissions if there are invalid fields
	(function() {
	  window.addEventListener('load', function() {
		// Get the forms we want to add validation styles to
		var forms = document.getElementsByClassName('needs-validation');
		// Loop over them and prevent submission
		var validation = Array.prototype.filter.call(forms, function(form) {
		  form.addEventListener('submit', function(event) {
			if (form.checkValidity() === false) {
			  event.preventDefault();
			  event.stopPropagation();
			}
			form.classList.add('was-validated');
            		
            if (form.submit.id == 'bucket-validation-submit'){
                var id = this.value;
                var identifier = 'bucket';
                var endpoint = '/accelerators/bucketconfig';
                event.preventDefault();
			    event.stopPropagation();
                var res = bucket_POST(id,identifier, endpoint);
                console.log(res);
            }
		  }, false);
		});
		$('#platform-etl').on("change", function(){
		    var platform = this.value;
		    var identifier = 'etl-platform';
		    var targetId = '#etl-platform';
            var endpoint = '/app_config';
		    get_service(platform, identifier, targetId, endpoint);
		});
		$('#etl-platform').on("change", function(){
		    var etl_platform = this.value;
		    var identifier = 'etl';
		    var target = '#etl-config-end';
		    var disable_list = ['#etl-platform', '#platform-etl'];
		    var enable_list = ['#etl-form-submit'];
            var endpoint = '/app_config';
		    get_conn_details(etl_platform, identifier, target, disable_list, enable_list, endpoint);
		});
		$('#platform-test-doc').on("change", function(){
		    var platform = this.value;
            var targetId = '#test-doc-storage-type';
            var targetIdStorageService = '#test-doc-storage-service';
		    get_service_type(platform, 'testdoc-platform', targetId, targetIdStorageService);
		});
		$('#test-doc-storage-type').on("change", function(){
		    var service_type = this.value;
		    var identifier = 'testdoc-servtype';
            var endpoint = '/app_config';
		    get_service(service_type, identifier, '#test-doc-storage-service', endpoint);
		});
		$('#test-doc-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'testdoc-service';
		    var target = '#testdoc-form-end';
		    var disable_list = ['#test-doc-storage-service', '#test-doc-storage-type', '#platform-test-doc'];
		    var enable_list = ['#testdoc-form-submit'];
            var endpoint = '/app_config';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});
		$('#platform-test-result').on("change", function(){
		    var platform = this.value;
		    var identifier = 'testresult-platform';
		    var targetId = '#test-result-storage-service';
            var endpoint = '/app_config';
		    get_service(platform, identifier, targetId, endpoint);
		});


		$('#datefilterto').on("change", function(){
		    var st_date = document.getElementById('datefilterfrom').value;
		    var end_date = document.getElementById('datefilterto').value;
		    var platform = document.getElementById('db_name').value;
		    var identifier = 'db_name';
		    var targetId = '#etl_name';
            var endpoint = '/execute/workflow-mgmt';
		    get_service_val(st_date, end_date, platform, identifier, targetId, endpoint);
		});

		$('#datefilterto-f2db').on("change", function(){
		    var st_date = document.getElementById('datefilterfrom-f2db').value;
		    var end_date = document.getElementById('datefilterto-f2db').value;
		    var platform = document.getElementById('src_name').value;
		    var identifier = 'src_name';
		    var targetId = '#f2db_etl_name';
            var endpoint = '/execute/workflow-mgmt';
		    get_service_val(st_date, end_date, platform, identifier, targetId, endpoint);
		});

		$('#datefilterto-sfdc').on("change", function(){
		    var st_date = document.getElementById('datefilterfrom-sfdc').value;
		    var end_date = document.getElementById('datefilterto-sfdc').value;
		    var platform = document.getElementById('sfdc_src_name').value;
		    var identifier = 'sfdc_src_name';
		    var targetId = '#sfdc_etl_name';
            var endpoint = '/execute/workflow-mgmt';
		    get_service_val(st_date, end_date, platform, identifier, targetId, endpoint);
		});

        $('#datefilterfrom').on("change", filterRows);
        $('#datefilterto').on("change", filterRows);

		$('#test-result-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'testresult-service';
		    var target = '#testresult-form-end';
		    var disable_list = ['#test-result-storage-service', '#platform-test-result'];
		    var enable_list = ['#testresult-form-submit'];
            var endpoint = '/app_config';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});
		$('#etl-configuration-form').submit(function(e){
		    if (this.checkValidity() === true) {
			  //event.preventDefault();
			  var id = '#'+this.id
			  //post_data(id);
			  }
		});

        $('#mismatch-record-platform').on("change", function(){
		    var platform = this.value;
			var identifier = 'mismatch-record-platform';
            var targetId = '#mismatch-record-storage-type';
            var targetIdStorageService = '#mismatch-record-storage-service';
		    get_service_type(platform, identifier,targetId ,targetIdStorageService);
		});
		$('#mismatch-record-storage-type').on("change", function(){
		    var service_type = this.value;
		    var identifier = 'mismatch-record-storage-type';
			var targetId = '#mismatch-record-storage-service';
            var endpoint = '/app_config';
		    get_service(service_type, identifier, targetId, endpoint);
		});
		$('#mismatch-record-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'mismatch-record-storage-service';
		    var target = '#mismatch-record-form-end';
		    var disable_list = ['#mismatch-record-storage-service', '#mismatch-record-storage-type', '#mismatch-record-platform'];
		    var enable_list = ['#mismatch-record-form-submit'];
            var endpoint = '/app_config';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});

        $('#platform-metrics').on("change", function(){
		    var platform = this.value;
		    var identifier = 'metrics-platform';
		    var targetId = '#metrics-storage-service';
            var endpoint = '/app_config'
		    get_service(platform, identifier, targetId, endpoint);
		});
		$('#metrics-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'metrics-service';
		    var target = '#metrics-form-end';
		    var disable_list = ['#metrics-storage-service', '#platform-metrics'];
		    var enable_list = ['#metrics-form-submit'];
            var endpoint = '/app_config';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});

		$('#platform-metadata').on("change", function(){
		    var platform = this.value;
		    var identifier = 'metadata-platform';
		    var targetId = '#metadata-storage-service';
            var endpoint = '/app_config'
		    get_service(platform, identifier, targetId, endpoint);
		});
		$('#metadata-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'metadata-service';
		    var target = '#metadata-form-end';
		    var disable_list = ['#metadata-storage-service', '#platform-metadata'];
		    var enable_list = ['#metadata-form-submit'];
            var endpoint = '/app_config';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});

        $('#f2f-src-platform').on("change", function(){
		    var platform = this.value;
		    var identifier = 'f2f_src_platform';
		    var targetId = '#f2f-src-service';
            var endpoint = '/configure/f2f'
		    get_service(platform, identifier, targetId, endpoint);
		});
        $('#f2f-tgt-platform').on("change", function(){
		    var platform = this.value;
		    var identifier = 'f2f_tgt_platform';
		    var targetId = '#f2f-tgt-service';
            var endpoint = '/configure/f2f'
		    get_service(platform, identifier, targetId, endpoint);
		});

//		FILE 2 FILE

        $('#f2f-platform-test-doc').on("change", function(){
		    var platform = this.value;
            var targetId = '#f2f-test-doc-storage-type';
            var targetIdStorageService = '#f2f-test-doc-storage-service';
		    get_service_type_f2f(platform, 'f2f-platform-test-doc', targetId, targetIdStorageService);
		});
		$('#f2f-test-doc-storage-type').on("change", function(){
		    var service_type = this.value;
		    var identifier = 'f2f-test-doc-storage-type';
            var endpoint = '/val_config/f2f';
		    get_service(service_type, identifier, '#f2f-test-doc-storage-service', endpoint);
		});
		$('#f2f-test-doc-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'f2f-test-doc-storage-service';
		    var target = '#f2f-testdoc-form-end';
		    var disable_list = ['#f2f-test-doc-storage-service', '#f2f-test-doc-storage-type', '#f2f-platform-test-doc'];
		    var enable_list = ['#f2f-testdoc-form-submit'];
            var endpoint = '/val_config/f2f';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});

        $('#f2f-platform-test-doc-tgt').on("change", function(){
		    var platform = this.value;
            var targetId = '#f2f-test-doc-storage-type-tgt';
            var targetIdStorageService = '#f2f-test-doc-storage-service-tgt';
		    get_service_type_f2f(platform, 'f2f-platform-test-doc-tgt', targetId, targetIdStorageService);
		});
		$('#f2f-test-doc-storage-type-tgt').on("change", function(){
		    var service_type = this.value;
		    var identifier = 'f2f-test-doc-storage-type-tgt';
            var endpoint = '/val_config/f2f';
		    get_service(service_type, identifier, '#f2f-test-doc-storage-service-tgt', endpoint);
		});
		$('#f2f-test-doc-storage-service-tgt').on("change", function(){
		    var service = this.value;
		    var identifier = 'f2f-test-doc-storage-service-tgt';
		    var target = '#f2f-testdoc-form-end-tgt';
		    var disable_list = ['#f2f-test-doc-storage-service-tgt', '#f2f-test-doc-storage-type-tgt', '#f2f-platform-test-doc-tgt'];
		    var enable_list = ['#f2f-testdoc-form-submit-tgt'];
            var endpoint = '/val_config/f2f';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});

//		DB 2DB
        $('#db2db-source-platform').on("change", function(){
		    var platform = this.value;
		    var identifier = 'db2db-source-platform';
		    var targetId = '#db2db-source-services';
            var endpoint = '/val_config/db2db'
		    get_service(platform, identifier, targetId, endpoint);
		});
        $('#db2db-source-services').on("change", function(){
		    var service = this.value;
		    var identifier = 'db2db-source-services';
		    var targetId = '#db2db-services-source';
            var disable_list = ['#db2db-source-platform', '#db2db-source-services'];
            var enable_list = ['#source-config-manual-submit'];
            var endpoint = '/val_config/db2db'
		    get_conn_details(service, identifier, targetId, disable_list, enable_list, endpoint);
		});
        $('#db2db-target-platform').on("change", function(){
		    var platform = this.value;
		    var identifier = 'db2db-target-platform';
		    var targetId = '#db2db-target-services';
            var endpoint = '/val_config/db2db'
		    get_service(platform, identifier, targetId, endpoint);
		});
        $('#db2db-target-services').on("change", function(){
		    var service = this.value;
		    var identifier = 'db2db-target-services';
		    var targetId = '#db2db-target-source';
            var disable_list = ['#db2db-target-services', '#db2db-target-platform'];
            var enable_list = ['#target-config-submit'];
            var endpoint = '/val_config/db2db'
		    get_conn_details(service, identifier, targetId, disable_list, enable_list, endpoint);
        });

//        SFDC to DB
        $('#sfdc2db-source-platform').on("change", function(){
		    var platform = this.value;
		    var identifier = 'sfdc2db-source-platform';
		    var targetId = '#sfdc2db-source-services';
            var endpoint = '/val_config/sfdc2db'
		    get_service(platform, identifier, targetId, endpoint);
		});
        $('#sfdc2db-source-services').on("change", function(){
		    var service = this.value;
		    var identifier = 'sfdc2db-source-services';
		    var targetId = '#sfdc2db-services-source';
            var disable_list = ['#sfdc2db-source-platform', '#sfdc2db-source-services'];
            var enable_list = ['#source-config-manual-submit'];
            var endpoint = '/val_config/sfdc2db'
		    get_conn_details(service, identifier, targetId, disable_list, enable_list, endpoint);
		});
        $('#sfdc2db-target-platform').on("change", function(){
		    var platform = this.value;
		    var identifier = 'sfdc2db-target-platform';
		    var targetId = '#sfdc2db-target-services';
            var endpoint = '/val_config/sfdc2db'
		    get_service(platform, identifier, targetId, endpoint);
		});
        $('#sfdc2db-target-services').on("change", function(){
		    var service = this.value;
		    var identifier = 'sfdc2db-target-services';
		    var targetId = '#sfdc2db-target-source';
            var disable_list = ['#sfdc2db-target-services', '#sfdc2db-target-platform'];
            var enable_list = ['#target-config-submit'];
            var endpoint = '/val_config/sfdc2db'
		    get_conn_details(service, identifier, targetId, disable_list, enable_list, endpoint);
        });

//      SFDC to DB end....

        $('#f2db-platform-test-doc').on("change", function(){
		    var platform = this.value;
            var targetId = '#f2db-test-doc-storage-type';
            var targetIdStorageService = '#f2db-test-doc-storage-service';
		    get_service_type_f2db(platform, 'f2db-platform-test-doc', targetId, targetIdStorageService);
		});
		$('#f2db-test-doc-storage-type').on("change", function(){
		    var service_type = this.value;
		    var identifier = 'f2db-test-doc-storage-type';
            var endpoint = '/val_config/f2db';
		    get_service(service_type, identifier, '#f2db-test-doc-storage-service', endpoint);
		});
		$('#f2db-test-doc-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'f2db-test-doc-storage-service';
		    var target = '#f2db-testdoc-form-end';
		    var disable_list = ['#f2db-test-doc-storage-service', '#f2db-test-doc-storage-type', '#f2db-platform-test-doc'];
		    var enable_list = ['#f2db-testdoc-form-submit'];
            var endpoint = '/val_config/f2db';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});
        $('#f2db-target-platform').on("change", function(){
		    var platform = this.value;
		    var identifier = 'f2db-target-platform';
		    var targetId = '#f2db-target-services';
            var endpoint = '/val_config/f2db'
		    get_service(platform, identifier, targetId, endpoint);
		});
        $('#f2db-target-services').on("change", function(){
		    var service = this.value;
		    var identifier = 'f2db-target-services';
		    var targetId = '#f2db-target-source';
            var disable_list = ['#f2db-target-services', '#f2db-target-platform'];
            var enable_list = ['#configure'];
            var endpoint = '/val_config/f2db'
		    get_conn_details(service, identifier, targetId, disable_list, enable_list, endpoint);
        });
        $('#orch-platform-test-result').on("change", function(){
		    var platform = this.value;
		    var identifier = 'orch-platform-test-result';
		    var targetId = '#orch-test-result-storage-service';
            var endpoint = '/configure/orch_val';
		    get_service(platform, identifier, targetId, endpoint);
		});
		$('#orch-test-result-storage-service').on("change", function(){
		    var service = this.value;
		    var identifier = 'orch-test-result-storage-service';
		    var target = '#orch-testresult-form-end';
		    var disable_list = ['#orch-test-result-storage-service', '#orch-platform-test-result'];
		    var enable_list = ['#orch-testresult-form-submit'];
            var endpoint = '/configure/orch_val';
		    get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
		});

		$('#bucket_list').on("change", function(){
		    var test_case_list = this.value;
		    var identifier = 'bucket_list';
		    var target = '#test-case-div';
		    var disable_list = ['#bucket_list'];
		    var enable_list = ['#bucket-validation-submit'];
            var endpoint = '/accelerators/bucketconfig';
		    // get_test_cases(test_case_list, identifier, target, disable_list, enable_list, endpoint);
		});

        $('#minio_buckets').on("change", function(){
		    var bucket_name = this.value;
		    var identifier = 'minio_buckets';
		    var target = '#bucket_objects';
            var endpoint = '/accelerators/test-script-gen';
		    MinIO_bucket_lists(bucket_name, identifier, target, endpoint);
		});

        $('#bucket_objects').on("change", function(){
		    var bucket_object = this.value;
		    var target = '#bucket_objects';
            var endpoint = '/accelerators/test-script-gen';
		    MinIO_bucket_lists_iterative(bucket_object, target, endpoint);
		});

		$('#chart_types').on("change", function(){
		    var chart_types = this.value;
            var endpoint = '/execution/dashboard';
		    dashboard_charts(chart_types, endpoint);
		});

		$('#myBtn').click(function(){
		    var edit_button = this.value;
		    var target = '#edit'
		    edit_test_cases(edit_button, target)
		});

        $('#orch-select-tool').on("change", function(){
            var service = this.value;
		    var identifier = 'orch-select-tool';
		    var target = '#orch-tool-form-end';
            var endpoint = '/configure/orch_val';
            var disable_list = ['#orch-select-tool'];
		    var enable_list = ['#orch-form-submit'];
            get_conn_details(service, identifier, target, disable_list, enable_list, endpoint);
        })
	  }, false);
	})();

function bucket_POST(id, identifier, endpoint){
    $.ajax({
        url:endpoint,
        type: 'POST',
        dataType: 'json',
        data: { 
            'val': identifier, 
            'data': id, 
            'new-test-case': document.getElementById('new-test-case').value, 
            'bucket_list': document.getElementById('bucket_list').value,
            'csrf': document.getElementById('csrf_token').value
        },
        success: function(json){
            window.alert(json);
//            location.reload();
            window.location.assign(endpoint);
        },
    })
}
function get_test_cases(service, identifier, target, disable_list, enable_list, endpoint){
    console.log("inside get_conn_details", service, identifier, target, disable_list, enable_list);
    $.ajax({
        url: endpoint,
        type: 'GET',
        dataType: 'json',
        data: {'val': identifier, 'data': service},
        success: function(json){
            inputFields = json;

            
            console.log(disable_list);
            console.log("calling add_fields with target", target);
            // add_test_fields(inputFields, service, target);
            for(i=0;i<enable_list.length;i++){
                $(enable_list[i]).prop('disabled', false);
            }
            console.log('success');
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close' aria-label='Close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })

}


function add_test_fields(inputFields, prefix, endId){
    console.log('inside add fields');
    var type = 'button';
    for ( x in inputFields){
         var con_element = x;
         if(x == document.getElementById("bucket_list").value){
                for (i=0;i<inputFields[x].length;i++){
               var newInput = $(`<div id="test-case-form-end">
               <table  style="width:60%; font-family: Arial, Helvetica, sans-serif; ">
               <tr>
                   <td style="width:60%;"><label id="edit"  style=" font-size: 12px; margin-left:30px  ">${inputFields[x][i] }</label></td>
                   <td style="width:8%;"><button id="myBtn" class="btn btn-success btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Edit">Edit</button></i></td>
                   <td><button id="end-editing" class="btn btn-success btn-sm rounded-0" type="button" data-toggle="tooltip" data-placement="top" title="Save">Save</button></i> </td>
               </tr>
               </table></div>`);
                $(endId).after(newInput);
                //console.log($.type(newInput));
                }
         }

    }
}

function edit_test_cases(edit_button, target){
    console.log(edit_button)
    console.log(target)

}


function get_service_val(st_date, end_date, getServFor, identifier, actionOnId, endpoint){
    $.ajax({
        url: endpoint, // the endpoint
        type: "GET", // http method,
        data: {'val': identifier, 'data': getServFor},
        dataType: "json",
        success: function(json){
            $(actionOnId).empty().append(`<option value="">Select Pipelines</option>`);
            var dateSTART = new Date(st_date);
            var dateEND = new Date(end_date);
            s = formatDate(dateSTART);
            e = formatDate(dateEND);
            function formatDate(date) {
                var day = date.getDate();
                if (day < 10) {
                    day = "0" + day;
                }
                var month = date.getMonth() + 1;
                if (month < 10) {
                    month = "0" + month;
                }
                var year = date.getFullYear();
                return month + "/" + day + "/" + year;
            }
            console.log("Start Date",s);
            console.log("End Date",e);
            for([key, val] of Object.entries(json)) {
                var value = new Date(val)
                var val1 = formatDate(value);
                if(val1 >= s && val1<=e){
                console.log("In between Dates",val1);
                   $(actionOnId).append(`<option value="${key}">
                                       ${key}
                                  </option>`);
                }
            }
            console.log("success");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert alert-warning alert-dismissible fade show' role='alert'>"+
                        "<button type='button' class='close' data-dismiss='alert' aria-label='Close' class='fade close'>"+
              "<span aria-hidden='true'>&times;</span>"+
            "</button>Oops! We have encountered an error: "+errmsg+"</div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })
    //console.log($('#platform-validate').value);
}

function get_service(getServFor, identifier, actionOnId, endpoint){
    console.log(getServFor)
    $.ajax({
        url: endpoint, // the endpoint
        type: "GET", // http method,
        data: {'val': identifier, 'data': getServFor},
        dataType: "json",
        success: function(json){
            console.log(json)
            $(actionOnId).empty().append(`<option value="">Select Service</option>`);
            for (i=0;i<json.length;i++){
                var optionVal = json[i];
                var optionText = json[i];
                $(actionOnId).append(`<option value="${optionVal}">
                                       ${optionText}
                                  </option>`);
            }
            //console.log(obj.length)
            //console.log(obj); // log the returned json to the console
            console.log("success");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert alert-warning alert-dismissible fade show' role='alert'>"+
                        "<button type='button' class='close' data-dismiss='alert' aria-label='Close' class='fade close'>"+ 
              "<span aria-hidden='true'>&times;</span>"+
            "</button>Oops! We have encountered an error: "+errmsg+"</div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })
    //console.log($('#platform-validate').value);
}

function get_service_Conn(getServFor, identifier, actionOnId, endpoint){
    console.log(getServFor)
    $.ajax({
        url: endpoint, // the endpoint
        type: "GET", // http method,
        data: {'val': identifier, 'data': getServFor},
        dataType: "json",
        success: function(json){
            console.log(json)
            $(actionOnId).empty().append(`<option value="">Select Connection Urls</option>`);
            for (i=0;i<json.length;i++){
                var optionVal = json[i];
                var optionText = json[i];
                $(actionOnId).append(`<option value="${optionVal}">
                                       ${optionText}
                                  </option>`);
            }
            //console.log(obj.length)
            //console.log(obj); // log the returned json to the console
            console.log("success");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert alert-warning alert-dismissible fade show' role='alert'>"+
                        "<button type='button' class='close' data-dismiss='alert' aria-label='Close' class='fade close'>"+
              "<span aria-hidden='true'>&times;</span>"+
            "</button>Oops! We have encountered an error: "+errmsg+"</div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })
    //console.log($('#platform-validate').value);
}

function get_conn_details(service, identifier, target, disable_list, enable_list, endpoint){
    console.log("inside get_conn_details", service, identifier, target, disable_list, enable_list);
    $.ajax({
        url: endpoint,
        type: 'GET',
        dataType: 'json',
        data: {'val': identifier, 'data': service},
        success: function(json){
            inputFields = json;
            console.log('get conn details');
            console.log("orch-input-fields", inputFields);

            for(i=0;i<disable_list.length;i++){
                $(disable_list[i]).prop('disabled', 'disabled');
            }
            console.log(disable_list);
            console.log("calling add_fields with target", target);
            add_fields(inputFields, service, target);
            for(i=0;i<enable_list.length;i++){
                $(enable_list[i]).prop('disabled', false);
            }
            console.log('success');
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close' aria-label='Close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })
}

function add_fields(inputFields, prefix, endId){
    console.log('inside add fields');
    for (i=0;i<inputFields.length;i++){
                //console.log(inputFields[i]);
                console.log("inside add_field");
                var con_element = inputFields[i];
                var type = '';
                if (con_element.toLowerCase() == 'password'){
                    type = 'password';
                }else if (con_element.toLowerCase() == 'port'){
                    type = 'number';
                }else{
                    type = 'text';
                }
                var newInput = $(`<div class="col-6">
                        <label for="${prefix}${con_element}" class="form-label required">${con_element}</label>
                        <input id="${prefix}${con_element}" class="form-control required-input" type="${type}" name="${con_element}" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>`);
                $(endId).after(newInput);
                //console.log($.type(newInput));
            }
}

function get_service_type_f2f(platform, identifier, targetId, targetIdStorageService){
    $.ajax({
        url: '/val_config/f2f',
        dataType: 'json',
        data: {'val': identifier, 'data': platform},
        success: function(json){
            $(targetId).empty().append(`<option value="">Select Storage type</option>`);
            $(targetIdStorageService).empty().append(`<option value="">Select Storage Service</option>`);
            for (i=0;i<json.length;i++){
                if (json[i]=='File Store' || json[i]=='Object Store'){
                    var optionVal = json[i];
                    var optionText = json[i];
                    $(targetId).append(`<option value="${optionVal}">
                                       ${optionText}
                                  </option>`);

                }
            }
            // console.log(obj.length)
            //console.log(obj); // log the returned json to the console
            console.log("success");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })

}

function get_service_type_f2db(platform, identifier, targetId, targetIdStorageService){
    $.ajax({
        url: '/val_config/f2db',
        dataType: 'json',
        data: {'val': identifier, 'data': platform},
        success: function(json){
            $(targetId).empty().append(`<option value="">Select Storage type</option>`);
            $(targetIdStorageService).empty().append(`<option value="">Select Storage Service</option>`);
            for (i=0;i<json.length;i++){
                if (json[i]=='File Store' || json[i]=='Object Store'){
                    var optionVal = json[i];
                    var optionText = json[i];
                    $(targetId).append(`<option value="${optionVal}">
                                       ${optionText}
                                  </option>`);

                }
            }
            // console.log(obj.length)
            //console.log(obj); // log the returned json to the console
            console.log("success");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })

}


function get_service_type(platform, identifier, targetId, targetIdStorageService){
    $.ajax({
        url: '/app_config',
        dataType: 'json',
        data: {'val': identifier, 'data': platform},
        success: function(json){
            $(targetId).empty().append(`<option value="">Select Storage type</option>`);
            $(targetIdStorageService).empty().append(`<option value="">Select Storage Service</option>`);
            for (i=0;i<json.length;i++){
                var optionVal = json[i];
                var optionText = json[i];
                $(targetId).append(`<option value="${optionVal}">
                                       ${optionText}
                                  </option>`);
            }
            // console.log(obj.length)
            //console.log(obj); // log the returned json to the console
            console.log("success");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })

}






function post_data(id){
    $.ajax({
        url: $(id).attr('action'),
        type: "POST",
        dataType: 'json',
        data: {val: id, data: $(id).serializeArray()},
        success: function(json){
            //alert('success')
            console.log('#'+id)
            console.log($(id).serializeArray())
            console.log('post');
            $(id).hide();
            $('#results').html("<div class='alert-box alert radius' data-alert>"+json+"<button class='close' data-dismiss='alert' aria-label='Close'>&times;</button></div>");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close' data-dismiss='alert' aria-label='Close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText);
        }
    })
}


function filterRows() {
  var from = $('#datefilterfrom').val();
  var to = $('#datefilterto').val();

  if (!from && !to) { // no value for from and to
    return;
  }

  from = from || '1970-01-01'; // default from to a old date if it is not set
  to = to || '2999-12-31';

  var dateFrom = moment(from);
  var dateTo = moment(to);

  $('#testTable tr').each(function(i, tr) {
    var val = $(tr).find("td:nth-child(2)").text();
    var dateVal = moment(val, "YYYY-DD-MM");
    var visible = (dateVal.isBetween(dateFrom, dateTo, null, [])) ? "" : "none"; // [] for inclusive
    $(tr).css('display', visible);
  });
}


function MinIO_bucket_lists(bucket_name, identifier, target, endpoint){
    $.ajax({
        url: endpoint,
        dataType: 'json',
        data: {'val': identifier, 'data': bucket_name},
        success: function(json){
            console.log(identifier);
            $(target).empty().append(`<option value="">Select Objects</option>`);
            for (i=0;i<json.length;i++){
                var optionVal = json[i];
                var optionText = json[i];
                $(target).append(`<option value="${optionVal}">
                                       ${optionText}
                                  </option>`);
            }
            // console.log(obj.length)
            //console.log(obj); // log the returned json to the console
            console.log("success");
        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }
    })

}


function MinIO_bucket_lists_iterative(bucket_object, target, endpoint){
    $.ajax({
        url: endpoint,
        dataType: 'json',
        data: {'val': bucket_object, 'data': bucket_object},
        success: function(json){
            console.log(bucket_object);
            for (i=0;i<json.length;i++){
                var optionVal = json[i];
                var optionText = json[i];
                var dot_str = optionText.indexOf('.') !== -1;
//                $(target).empty().append(`<option value="">Select Objects</option>`);
                if (json.length === 1 && dot_str === true){
                    append_file_name(target, optionVal, optionText);
                    break;
                }
                else{

                    $(target).append(`<option value="${optionVal}">${optionText}</option>`);
                }
            }
            console.log("success");

        },
        error: function(xhr,errmsg,err) {
            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
                " <a href='#' class='close'>&times;</a></div>"); // add the error to the dom
            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
        }

    })

}

function append_file_name(target, optionVal, optionText){
        $(target).append(`<option value="${optionVal}">${optionText}</option>`);


}



//function dashboard_charts(chart_types, endpoint){
//    $.ajax({
//        url: endpoint,
//        dataType: 'json',
//        data: {'val': chart_types},
//        success: function(json){
//            console.log(json);
////            console.log( json["graph1JSON"]);
////            console.log( json["graph2JSON"]);
////            var graph1 = json["graph1JSON"];
////            var graph2 = json["graph2JSON"];
////            Plotly.plot("chart1", graph1, {}, {responsive: true})
//            Plotly.plot("chart2", json, {})
//            console.log("success");
//
//        },
//        error: function(xhr,errmsg,err) {
//            $('#results').html("<div class='alert-box alert radius' data-alert>Oops! We have encountered an error: "+errmsg+
//                " <a href='#' class='close'>&times;</a></div>"); // add the error to the dom
//            console.log(xhr.status + ": " + xhr.responseText); // provide a bit more info about the error to the console
//        }
//
//    })
//
//}

//function submitFormPP() {
//    var http = new XMLHttpRequest();
//    http.open("POST", "<<whereverTheFormIsGoing>>", true);
//    http.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//    var params = "search=" + $('#submit').val();; // probably use document.getElementById(...).value
//    http.send(params);
//    http.onload = function() {
//        alert(http.responseText);
//    }
//}