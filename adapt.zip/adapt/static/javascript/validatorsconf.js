//element.style.display = 'none';           // Hide
//element.style.display = 'block';          // Show
//element.style.display = 'inline';         // Show
//element.style.display = 'inline-block';   // Show

function apiOrManual(divId, formDivId, dbConnId){
    var form = document.getElementById(formDivId);
    var obj = document.getElementById(divId);
    //console.log(formDivId);
    //console.log(obj);
//    console.log(divId);
    obj.style.display = "none";
    form.style.display = "block";
}

function unhideDBconn(id1, id2, id3b){
    var form = document.getElementById(id1);
    var obj = document.getElementById(id2);
    var but = document.getElementById(id3b);
    console.log(id3b);
    obj.style.display = "block";
    form.style.display = "none";
    but.style.display = "none";
}

$(document).ready(function() {
    $("input[name$='val_type']").click(function() {
        var test = $(this).val();

        $("div.desc").hide();
        $("#DIV" + test).show();
    });
});




$(document).ready(function(){
	$('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
		localStorage.setItem('activeTab', $(e.target).attr('href'));
	});
	var activeTab = localStorage.getItem('activeTab');
	if(activeTab){
		$('#myTab a[href="' + activeTab + '"]').tab('show');
	}
});

function myFunction() {
  var x = document.getElementById("myDIV");
  if (x.style.display == "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

