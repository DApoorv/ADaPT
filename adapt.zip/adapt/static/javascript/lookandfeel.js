function static_sidebtn_activate(a){
    items = document.querySelectorAll('.text-decoration-none.appcon-side-menu.active');
    if(items.length) 
    {
        items[0].className = '.text-decoration-none.appcon-side-menu';
    }
    a.className = 'text-decoration-none appcon-side-menu active';
}
function static_upload_sidebtn_activate(a){
    upload_items = document.querySelectorAll('.upload-sidebar.active');
    if(upload_items.length) 
    {
        items[0].className = '.upload-sidebar';
    }
    a.className = 'upload-sidebar active'
}