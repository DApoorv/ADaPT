from utils.objectfactory import ObjectFactory
from utils.orchestrator.orchestrate import Orchestrator


class OrchestrateFactory(ObjectFactory):
    pass


orchf = OrchestrateFactory()
orchf.register('dags', Orchestrator())