from flask import flash
from pytz import timezone
from utils.objectfactory import ob
from datetime import datetime
import json
from utils.orchestrator.payload import Payload


class Orchestrator:
    _dags = {
        'f2f': 'File-to-File-Validation',
        # 'db2db1': 'pg-to-rs-validation-engine',
        # 'db2db2': 'db-to-db-validation-engine',
        'db2db': 'db-to-db-validation-engine',
        'f2db': 'file-to-db-valdation-engine',
        'orch': '',
        'perf': '',
        'gen-script': 'Test-Script-Gen',
        'sfdc2db': 'sfdc-to-db-valdation-engine'
    }

    def __call__(self, val_type=None, conf=None) -> None:
        self.air_client = ob.create('airflowapiclient')
        self.dag = self.conf = None
        if val_type:
            self.dag = self.get_dag(val_type)

        if conf:
            self.conf = json.dumps(dict(
                dag_run_id=self.dag + ''.join(str(datetime.now()).split()),
                conf=conf
            ))
        return self

    def get_dag(self, val_type):
        return self._dags.get(val_type)

    def run_dag(self):
        if self.conf == None:
            self.conf = self.prep_payload()
        try:
            res = self.air_client.trigger(dag_id="Test-Script-Gen", data=self.conf)
            res = json.loads(res.content)
            status = "running"
            while status != "completed":
                respo = self.air_client.dag_task_status(dag_id=res['dag_id'], dag_run_id=res['dag_run_id'])
                if json.loads(respo[0].content)['state'] == "success":
                    status = "completed"
                    message = "DAG ran successfully"
                elif json.loads(respo[0].content)['state'] == "failed":
                    status = "completed"
                    message = "DAG run failed"
        except Exception as e:
            message = "Dag triggered\n" + str(e)
        return message

    def prep_payload(self):
        try:
            payload = Payload(self.dag)
            if self.val_type == 'gen-script':
                payload.prep_payload_gen()
            else:
                payload.prep_payload_val(self.dag_run_id)
        except Exception as e:
            print(e)


def test_script_auto_run_dag(input_format, resource_key, output_format, output_path, mapping_sheet,
                             output_template_file,
                             source_db_name, target_db_name):
    try:
        dag_run_id = "Test-Script-Gen" + ''.join(str(datetime.now()).split())
        conf = {
            "input_format": input_format,
            "resource_key": resource_key,
            "output_format": output_format,
            "output_path": output_path,
            "mapping_sheet": mapping_sheet,
            "output_template_file": output_template_file,
            "source_db_name": source_db_name,
            "target_db_name": target_db_name
        }
        dict_conf = {
            "dag_run_id": dag_run_id,
            "conf": conf
        }
        air_client = ob.create('airflowapiclient')
        res = air_client.trigger(dag_id="Test-Script-Gen", data=json.dumps(dict(dict_conf)))
        res = json.loads(res.content)
        status = "running"
        while status != "completed":
            respo = air_client.dag_task_status(dag_id=res['dag_id'], dag_run_id=res['dag_run_id'])
            if json.loads(respo[0].content)['state'] == "success":
                status = "completed"
                message = "Test Script generated successfully!!"
            elif json.loads(respo[0].content)['state'] == "failed":
                status = "completed"
                message = "Test Script generation got failed!! Please review all the details."

    except Exception as e:
        message = str(e)
    return message


def test_script_standard_dag(pipeline_type, pipeline_name, output_path, mapping_sheet,
                             source_conn_details, target_conn_details, metadata_conn_details):
    try:
        dag_run_id = "Test-Script-Gen" + ''.join(str(datetime.now()).split())
        conf = {
            "pipeline_type": pipeline_type,
            "pipeline_name": pipeline_name,
            "output_path": output_path,
            "mapping_sheet": mapping_sheet,
            "source_conn_details": source_conn_details,
            "target_conn_details": target_conn_details,
            "metadata_conn_details": metadata_conn_details
        }
        dict_conf = {
            "dag_run_id": dag_run_id,
            "conf": conf
        }

        air_client = ob.create('airflowapiclient')
        res = air_client.trigger(dag_id="Test-Script-Gen", data=json.dumps(dict(dict_conf)))
        res = json.loads(res.content)
        status = "running"
        while status != "completed":
            respo = air_client.dag_task_status(dag_id=res['dag_id'], dag_run_id=res['dag_run_id'])
            if json.loads(respo[0].content)['state'] == "success":
                status = "completed"
                message = "Test Script generated successfully!!"
            elif json.loads(respo[0].content)['state'] == "failed":
                status = "completed"
                message = "Test Script generation got failed!! Please review all the details."

    except Exception as e:
        message = str(e)
    return message
