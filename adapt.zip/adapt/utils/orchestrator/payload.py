from abc import ABC
from datetime import datetime


class Payload(ABC):
    pass


class AirflowDAGPayload(Payload):
    def __init__(self, dag) -> None:
        super().__init__()
        self.dag = dag
        self.dag_run_id =self.dag + ''.join(str(datetime.now()).split())
    
    def prep_payload_gen(self, conf):
        return dict(dag_run_id=self.dag_run_id, conf=conf)

    def prep_payload_val(self):
        pass
