from importlib import import_module
from flask import session, request, jsonify
from functools import wraps
from flask import flash, url_for, g
from werkzeug.utils import redirect


def validate_request(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Do something with your request here
        # data = request.get_json()
        print("INSIDE decorated function")
        if not session.get('user'):
            # flash("Please login")
            return redirect(url_for('user.login_first'))
        if not session.get('environment'):
            flash("Please select Test environment and stage to proceed.")
            return redirect(url_for('configuration.setup'))
        else:
            g.current_env = session['environment']
            g.current_stage = session['stage']
            g.current_user = session['user']
            return f()

    return decorated_function


def env_var_check(func):
    print("inside ENV_VAR_CHECK")
    if session.get('environment'):
        return redirect(url_for('configuration.setup'))
    else:
        return func()


def before_first_request_func():
    print("This function will run once")
