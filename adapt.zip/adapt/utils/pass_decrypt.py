from Crypto.Cipher import DES3

import base64

# encryptedString = 'aVuRbTLufU6TFivVmmCMFKentG0EUtmZ9PpLooztzVQ='
# originalString = 'FCtRwtuA3UrQHzqpQsFXe3zS'

def decrypt_password(encrypted_string):
    key = [104, 98, 100, 98, 100, 115, 103, 94, 112, 97, 115, 118, 110, 115, 100, 94, 100, 110, 98, 115, 121, 112, 117,
           104]
    encryptedString = encrypted_string
    key = DES3.adjust_key_parity(key)

    cipher = DES3.new(key, DES3.MODE_ECB)

    encryptedText = base64.b64decode(encryptedString)

    decrypted_bytes = cipher.decrypt(encryptedText)

    decrypted_bytes = bytes([i for i in list(decrypted_bytes) if i not in range(16)])

    decryptedText = decrypted_bytes.decode('utf-8', 'ignore')

    return decryptedText