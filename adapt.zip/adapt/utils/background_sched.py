# encoded in UTF-8
from apscheduler.schedulers.background import BackgroundScheduler as _BaseBackgroundScheduler


class BackgroundScheduler(_BaseBackgroundScheduler):
    def start(self, app):
        app.app_context().push()
        super().start()
