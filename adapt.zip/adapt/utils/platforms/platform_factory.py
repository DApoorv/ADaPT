from utils.objectfactory import ObjectFactory
from utils.platforms.gcp import GoogleCloudPlatform
from ..platforms.aws import AmazonWebServices
from ..platforms.onprem import OnPremises


class PlatformFactory(ObjectFactory):
    def get_platform(self, key, **kwargs):
        """param key: platform name that identifies the class; It is by convention same as what is 
        stored as platform name in the platform table
        param service: name of service to be used to instantiate service 
        eg: s3, glue, etc.        
        returns : Platform class
        """
        return self.create(key, **kwargs)


pf = PlatformFactory()
pf.register('Google Cloud Platform', GoogleCloudPlatform)
pf.register('Amazon Web Services', AmazonWebServices)
pf.register('OnPremises', OnPremises)
