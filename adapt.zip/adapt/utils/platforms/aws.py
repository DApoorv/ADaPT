import boto3
import botocore
from botocore.exceptions import ClientError
import json
from flask import session, flash
from configuration.models import *
import pandas as pd


class AmazonWebServices:
    """AWS Platform class
    Used to by aws-services subclasses as their parent class
    Initialisation of this class also works as a object factory creation for 
    its subclasses.
    Please note that while AWS-services subclass this class their names can only be
    camelcase of boto3 client names, i.e., 
    if to create an `apigateway` client one has to do the following:
        client = boto3.client('apigateway')
    then the `apigateway` class can be named APIGateway.
    """
    _services = {}

    def __init__(self, **kwargs):
        self._services = {cls.__name__.lower(): cls for cls in AmazonWebServices.__subclasses__()}
        if kwargs.get('service'):
            service = kwargs.pop('service')
            self.service = self.get_service(service)

    def __call__(self, **kwargs):
        if kwargs.get('service'):
            service = kwargs.pop('service')
            self.service = self.get_service(service)

    def get_service(self, name):
        """returns the service class.
        All service classes are named by their resource key value in
        the services Table"""
        try:
            return self._services.get(name)
        except:
            raise NameError('class is not defined')

    def get_client(self, name=None, **kwargs):
        # kwargs['region_name'] = "us-east-2"
        # kwargs['aws_access_key_id'] = "AKIA3NFQOCHGHNB22UM3"
        # kwargs['aws_secret_access_key'] = "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"

        env = session['environment']
        stage = session['stage']
        filter_by = dict(
            test_environment=env,
            stage=stage
        )
        etl_conf = UserConnections.get_conf_details('ETL Configuration', filter_by)
        kwargs['region_name'] = etl_conf.connection_details['connection_details']['region name']
        kwargs['aws_access_key_id'] = etl_conf.connection_details['connection_details']['access key']
        kwargs['aws_secret_access_key'] = etl_conf.connection_details['connection_details']['secret access key']
        if not name:
            name = self.__class__.__name__
        return boto3.client(name.lower(), verify=False, **kwargs)


class S3(AmazonWebServices):
    def __init__(self, **kwargs):
        self.client = self.get_client(**kwargs)

    def upload_object(self, u_file, mes, per_filename, bucke):
        ext = per_filename.split(".")[-1]
        key = session['environment'] + "/" + session['stage'] + "/" + mes + "/" + mes.lower().replace(' ',
                                                                                                      '_') + "." + ext
        s3 = self.client
        put_response = s3.put_bucket_versioning(Bucket=bucke,
                                                VersioningConfiguration={'Status': 'Enabled'}
                                                )
        put_res = s3.put_object(Body=u_file, Bucket=bucke, Key=key)
        config = s3._client_config
        config.signature_version = botocore.UNSIGNED
        res = boto3.client('s3', config=config).generate_presigned_url('get_object', Params={
            'Bucket': 'test-doc-file-storage-temp-bucket', 'Key': key, 'VersionId': put_res['VersionId']}, ExpiresIn=0)
        return res

    def upload(self, file, con, **kwargs):
        """function to upload the s3"""
        try:
            # per_filename = kwargs['per_filename']
            mes = "Testing Folder"
            # bucke = kwargs['bucke']
            s3 = self.client
            # u_file = kwargs['u_file']
            # ext = per_filename.split(".")[-1]
            key = session['environment'] + "/" + session['stage'] + "/" + mes + "/" + file.filename
            put_response = s3.put_bucket_versioning(Bucket=con.bucket,
                                                    VersioningConfiguration={'Status': 'Enabled'}
                                                    )
            put_res = s3.put_object(Body=file, Bucket=con.bucket, Key=key)
            # config = s3._client_config
            # config.signature_version = botocore.UNSIGNED
            # res = boto3.client('s3', config=config, verify=False).generate_presigned_url('get_object', Params={
            #     'Bucket': 'test-doc-file-storage-temp-bucket', 'Key': key, 'VersionId': put_res['VersionId']},
            #                                                                              ExpiresIn=0)
            # print("uploading to s3")
            return put_res
        except Exception as e:
            print(e)

    def gen_links(self, bucke, key):
        """function to generate links"""
        try:
            ldata = [[]]
            s3 = self.client
            response = s3.get_object(Bucket=bucke, Key=key)
            tar = json.loads(response['Body'].read().decode('utf-8'))
            st_bucke = tar['out_path'].split("/", 3)
            resp = s3.list_objects(Bucket=st_bucke[2], Prefix=st_bucke[3])
            for l in resp['Contents']:
                tlist = []
                res = s3.generate_presigned_url('get_object', Params={'Bucket': st_bucke[2], 'Key': l['Key']})
                tlist.append(l['Key'])
                tlist.append(l['LastModified'])
                tlist.append(res)
                ldata.append(tlist)
        except Exception as e:
            ldata = []
            flash(e)
            print(e)
        return ldata

    def list_test_scripts(self, bucke, key):
        try:
            s3 = self.client
            response = s3.get_object(Bucket=bucke, Key=key)
            tar = json.loads(response['Body'].read().decode('utf-8'))
            st_bucke = tar['out_path'].split("/", 3)
            resp = s3.list_objects(Bucket=st_bucke[2], Prefix=st_bucke[3])
            tlist = [(tar['out_path'] + l['Key'].split('/')[1], l['Key']) for l in resp['Contents']]
        except ClientError as e:
            tlist = []
            flash(e)
        except TypeError as e:
            flash(e)
        return tlist


class Glue(AmazonWebServices):
    def __init__(self, **kwargs):
        self.client = self.get_client(**kwargs)

    def trigger_job(self, job_name):
        glue = self.client
        response = glue.start_job_run(JobName=job_name)
        print("Job triggered successfully")
        return response['JobRunId']

    def trigger_status(self, job_name, run_id):
        glue = self.client
        response = glue.get_job_run(
            JobName=job_name,
            RunId=run_id)
        return response['JobRun']['JobRunState']

    def list_jobs(self):
        """
        Lists the names of job definitions in your account.

        :return: The list of job definition names.
        """
        try:
            response = self.client.list_jobs(MaxResults=10)
        except ClientError as err:
            # logger.error(
            #     "Couldn't list jobs. Here's why: %s: %s",
            #     err.response['Error']['Code'], err.response['Error']['Message'])
            # raise
            print(err)
        else:
            return response['JobNames']

    def perf_cal(self, JobName):
        """
        Calculate performance of glue jobs
        """
        # client = boto3.client('glue', region_name='us-east-2')
        paginator = self.client.get_paginator("get_job_runs")
        job_time_list = []
        for response in paginator.paginate(JobName=JobName):
            for each_response in response["JobRuns"]:
                job_time_list.append(each_response["LastModifiedOn"])
        job_time_list.sort(reverse=True)
        recent_jobId_time = job_time_list[0]
        for response in paginator.paginate(JobName=JobName):
            for each_response in response["JobRuns"]:
                if each_response['LastModifiedOn'] == recent_jobId_time:
                    jobId = each_response['Id']
                    print("Latest Executed JobId ", jobId)
        status = self.client.get_job_run(RunId=jobId, JobName=JobName)
        job_df = pd.DataFrame(status)
        job_df.drop(['ResponseMetadata'], axis=1)
        return job_df