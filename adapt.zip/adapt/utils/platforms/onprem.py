from fileinput import filename
import os
from pathlib import Path
from flask import url_for, session
from minio import Minio
from sqlalchemy import desc
from werkzeug.datastructures import FileStorage

from config import *
from configuration.models import TestLog
from globals import ConnectionDetails, FileUploadResponse
from .servicetypes import *


class OnPremises:
    _services = {}

    def __init__(self, **kwargs):
        self._services = {cls.__name__.lower(): cls for cls in OnPremises.__subclasses__()}
        if kwargs.get('service'):
            service = kwargs.pop('service')
            self.service = self.get_service(service)

    def __call__(self, **kwargs):
        if kwargs.get('service'):
            service = kwargs.pop('service')
            self.service = self.get_service(service)

    def get_service(self, name):
        """returns the service class.
        All service classes are named by their resource key value in
        the services Table"""
        try:
            return self._services.get(name)
        except:
            raise NameError('class is not defined')


class FileSystem(OnPremises, FileStore):

    def __init__(self, **kwargs):
        pass

    def upload(self, file: FileStorage, con: ConnectionDetails) -> FileUploadResponse:
        path = con.path.joinpath(file.id)
        os.makedirs(path, exist_ok=True)
        file.save(path.joinpath(file.filename))
        return FileUploadResponse(
            filename=file.filename,
            filepath=path.__str__(),
            downloadable_link=path.joinpath(file.filename).__str__()
        )

    def download():
        pass

    def listdir(self, path: Path):
        super().listdir()
        return os.listdir(path)

    def list_test_scripts(self, **kwargs):
        return self.listdir

    def gen_links(self):
        ldata = []
        test_script_rows = TestLog.query.filter(
            TestLog.document_type.like('%Test%Script%')
        ).order_by(desc(TestLog.time_stamp)).limit(10).all()
        for row in test_script_rows:
            try:
                link = url_for('configuration.exporter', filepath=row.document_link)
                ldata.append([
                    row.document_name,
                    link
                ])
            except:
                continue
        return ldata


class Marlin(OnPremises):
    type_ = 'etl'

    def trigger_job():
        pass

    def trigger_status():
        pass


class MinIO(OnPremises):


    def upload(self, file: FileStorage, con: ConnectionDetails) -> FileUploadResponse:
        path = con.path + '/' + str(file.id) + '/' + str(file.filename)
        client = Minio(ip_address,
                       access_key=con.access_key,
                       secret_key=con.secret_key,
                       secure=False)
        client.put_object(
            con.bucket,
            path,
            file,
            length=-1,
            part_size=10 * 1024 * 1024,
            content_type='application/csv'
        )
        return FileUploadResponse(
            filename=file.filename,
            filepath=path.__str__(),
            downloadable_link=client.presigned_get_object(con.bucket, path)
        )

    def download(self):
        automated_test_script_path = session['environment'] + "/" + session['stage'] + "/Automated Test Script"
        path = automated_test_script_path
        client = Minio(ip_address,
                       access_key=access_key,
                       secret_key=secret_key,
                       secure=False)
        lists = []
        auto_test_script_names = client.list_objects(bucket_name, prefix=automated_test_script_path + "/")
        filename = [obj.object_name for obj in auto_test_script_names]
        for script_lists in filename:
            file_names = script_lists.split("/")[-1]
            auto_test_script_urls = client.presigned_get_object(bucket_name, path + "/" + file_names)
            lists.append([script_lists, auto_test_script_urls])
        return lists

    def listdir(self, path: Path):
        automated_test_script_path = session['environment'] + "/" + session['stage'] + "/Automated Test Script"
        client = Minio(ip_address,
                       access_key=access_key,
                       secret_key=secret_key,
                       secure=False)
        objects = client.list_objects(bucket_name, prefix=automated_test_script_path + "/")
        return [obj.object_name for obj in objects]

    def manual_listedfiles(self, path: Path):
        manual_test_script_path = session['environment'] + "/" + session['stage'] + "/Manual Test Script"
        client = Minio(ip_address,
                       access_key=access_key,
                       secret_key=secret_key,
                       secure=False)
        objects = client.list_objects(bucket_name, prefix=manual_test_script_path + "/")
        return [obj.object_name for obj in objects]

    def mapping_listedfiles(self, path: Path):
        client = Minio(ip_address,
                       access_key=access_key,
                       secret_key=secret_key,
                       secure=False)
        objects = client.list_objects(bucket_name, prefix=mapping_sheet_path)
        return [obj.object_name for obj in objects]

    def all_buckets():
        client = Minio(ip_address,
                       access_key=access_key,
                       secret_key=secret_key,
                       secure=False)
        objects = client.list_buckets()
        return [obj.name for obj in objects]

    def all_objects(bn):
        client = Minio(ip_address,
                       access_key=access_key,
                       secret_key=secret_key,
                       secure=False)
        objects = client.list_objects(bucket_name=bn)
        return [obj.object_name for obj in objects]

    def all_objects_prefix(bn, prefix):
        client = Minio(ip_address,
                       access_key=access_key,
                       secret_key=secret_key,
                       secure=False)
        objects = client.list_objects(bucket_name=bn, prefix=prefix)
        return [obj.object_name for obj in objects]
