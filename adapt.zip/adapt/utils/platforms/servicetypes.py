from abc import ABC, ABCMeta, abstractmethod
from werkzeug.datastructures import FileStorage

from globals.conninfo import ConnectionDetails
from globals.response import FileUploadResponse


class FileStore(ABC):

    @abstractmethod
    def upload(self, file: FileStorage, con: ConnectionDetails) -> FileUploadResponse:
        pass

    @abstractmethod
    def download(self, filename, **kwargs):
        pass
    
    @abstractmethod
    def listdir(path):
        pass
    

class ObjectStore(FileStore):
    pass
