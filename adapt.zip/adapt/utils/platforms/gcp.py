class GoogleCloudPlatform:
    def __init__(self, **kwargs):
        self._services = {cls.__name__.lower() : cls for cls in GoogleCloudPlatform.__subclasses__()}
        if kwargs.get('service'):
            service = kwargs.pop('service')
            self.service = self.get_service(service)
    
    def __call__(self, **kwargs):
        if kwargs.get('service'):
            service = kwargs.pop('service')
            self.service = self.get_service(service)

    def get_service(self, name):
        """returns the service class.
        All service classes are named by their resource key value in
        the services Table"""
        try:
            return self._services.get(name)
        except:
            raise NameError('class is not defined')

    def get_client(self, name=None, **kwargs):
        pass