# encoded in UTF-8
from db import dbf_obj
from execution.models import DbConfigModel, ValidationLog
from utils.objectfactory import ob
from execution.views import prep_payload, run_parent_dag
from datetime import datetime
import json

count = 0


def status_check(app):
    """Function runs in the background.
    Function continuously polls the ETL status for the etls whose status is 'In Progress' 
    in the etl_trigger_log table. And on getting a successful completion response from the etl
    it triggers the dag for the etl and logs to table validation log."""
    global count
    count += 1
    print("________________________________"+str(count)+"___________________________________")
    app.app_context().push()
    db = dbf_obj.get_dbase()
    data = DbConfigModel.query.filter_by(etl_status="In Progress").all()
    for dat in data:
        etl = ob.create('Amazon Web Services', service='glue').service()
        status_response = etl.trigger_status(dat.etl_name, dat.etl_run_id)
        # status = etl_factory_status(dat.etl_service)
        # status_response = status.trigger_status(dat.etl_name, dat.etl_run_id)
        if status_response == "SUCCEEDED":
            dat.validation_status = "In Progress"
            dat.etl_status = status_response
            db.session.commit()
            print("payload prep")
            payload = prep_payload(dat.etl_run_id)
            print(payload[0])
            if payload[0] == 'OK':
                print("Payload prep successful. DAG trigger start for etl:", dat.etl_run_id)
                run_parent_dag(payload[1], dat.etl_run_id)
        elif status_response == "FAILED":
            dat.etl_status = status_response
            db.session.commit()
            dat.validation_status = "FAILED"
            db.session.commit()


def val_status_check(app):
    """Function runs in the background.
    Function polls the dags status for the dags that are have a status other success or failed logged
    in the validation_log table. On getting a success or failed response it updates the log entry for the
    dag in the table"""
    global count
    print("________________________________validation num" + str(count) + "___________________________________")
    app.app_context().push()
    db = dbf_obj.get_dbase()
    # conn = AirflowConn()
    air_client = ob.create('airflowapiclient')
    data = ValidationLog.query.filter(ValidationLog.validation_status.not_in(['success', 'failed'])).all()
    print(data)
    for dat in data:
        res_task = air_client.dag_task_status(dag_id=dat.dag_id, dag_run_id=dat.dag_run_id)
        print(res_task, res_task[0].json())
        try:
            task_stat = json.loads(res_task[0].content)['state']
            if task_stat == 'success' or task_stat == 'failed':
                dat.validation_status = task_stat
                dat.end_time = datetime.now()
                db.session.commit()
        except Exception as e:
            print(e)
        print(count, "val_status_check finished execution")

