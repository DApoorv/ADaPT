# encoded in UTF-8
from execution.models import AirflowConf


class AirflowConn:
    def __init__(self):
        conf = AirflowConf.get_conn()
        self.host = conf.air_host
        self.port = str(conf.air_port)
        self.user = conf.air_user
        self.password = conf.air_pass
