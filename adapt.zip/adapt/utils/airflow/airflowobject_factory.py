from utils.objectfactory import ObjectFactory
from ..airflow.airflow_api_client import AirflowAPIClient
from ..airflow.airflow_conn import AirflowConn


class AirflowObjectFactory(ObjectFactory):
    pass


aof = AirflowObjectFactory()
aof.register('airflowconn', AirflowConn)
aof.register('airflowapiclient', AirflowAPIClient)