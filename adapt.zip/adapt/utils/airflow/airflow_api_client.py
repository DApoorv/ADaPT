# encoded in UTF-8
import requests
from urllib.parse import urlunparse
import json
from utils.airflow.airflow_conn import AirflowConn


class AirflowAPIClient:
    def __init__(self):
        conn = AirflowConn()
        self.conn = conn
        self.netloc = conn.host+":"+conn.port
        self.scheme = "http"
        self.path = "/api/v1/"
    

    def trigger(self, **kwargs):
        """provides python interface for /dagRuns endpoint
        :param:
            dag_id: the id of the dag that's to be triggered
        :returns:
            the response object from airflow dagRuns endpoint
        """
        dag_id = str(kwargs['dag_id'])
        data = kwargs['data']
        path = self.path+'dags/'+dag_id+'/dagRuns'
        params = ""
        query = ""
        fragment = ""
        headers = {'Content-Type': 'application/json'}
        url = urlunparse((
                self.scheme,
                self.netloc,
                path,
                params,
                query,
                fragment
            )
        )
        try:
            res = requests.post(url=url, auth=(self.conn.user, self.conn.password), headers=headers, data=data)
            return res
        except Exception as e:
            print("Exception thrown by trigger_dag. Exception message is: \"", str(e)+"\"")

    def get_dags(self, **kwargs):
        """provides interface for /dags endpoint
        :param:
            - dag_id: id of the dag
        :returns:
            - res: response object of the airflow endpoint
        """
        path = self.path+"dags" if not kwargs.get('dag_id') else self.path+"dags/"+kwargs['dag_id']
        params = ""
        query = ""
        fragment = ""
        if 'dag_id' not in kwargs.keys():
            li = []
            for key, val in kwargs.items():
                if key not in ['limit', 'offset', 'order_by']:
                    continue
                else:
                    li.append(key+'='+str(val))
            query = '&'.join(li)
        url = urlunparse((
                self.scheme,
                self.netloc,
                path,
                params,
                query,
                fragment
            )
        )
        try:
            res = requests.get(url=url, auth=(self.conn.user, self.conn.password))
            return res
        except Exception as e:
            print("Exception thrown by trigger_dag. Exception message is: \"", str(e) + "\"")

    def dag_status(self, **kwargs):
        """provides python interface for /dagRuns/<dag_id> endpoint
        :param:
            dag_id: the id of the dag that's to be triggered
            dag_run_id: the run_id of the dag for which status is to be known
        :returns:
            the response object from airflow giving the status of the dag
            identified by the dag_id for the provided dag_run_id
        """
        dag_id = kwargs.get('dag_id')
        dag_run_id = kwargs.get('dag_run_id')
        path = self.path + "dags/" + dag_id + "/dagRuns/" + dag_run_id
        params = ""
        query = ""
        fragment = ""
        url = urlunparse((
                self.scheme,
                self.netloc,
                path,
                params,
                query,
                fragment
            )
        )
        try:
            res = requests.get(url=url, auth=(self.conn.user, self.conn.password))
            return res
        except Exception as e:
            print("Exception thrown by trigger_dag. Exception message is: \"", str(e)+"\"")

    def dag_tasks(self, **kwargs):
        """provides python interface for /tasks endpoint
        :param:
            dag_id: the id of the dag that's to be triggered
        :returns:
            the response object from airflow providing details of the tasks assigned to the dag
            which can be identified by the provided dag_id
        """
        dag_id = kwargs.get('dag_id')
        path = self.path + "dags/" + dag_id + "/tasks"
        params = ""
        query = ""
        fragment = ""
        url = urlunparse((
            self.scheme,
            self.netloc,
            path,
            params,
            query,
            fragment
        ))
        res = None
        try:
            res = requests.get(url=url, auth=(self.conn.user, self.conn.password))
        except requests.exceptions.RequestException as e:
            print("Exception thrown by trigger_dag. Exception message is: \"", str(e) + "\"")
        return res

    def dag_task_status(self, **kwargs):
        """provides python interface for /taskInstance endpoint
        :param:
            dag_id: the id of the dag that's to be triggered
            dag_run_id: the run_id of the dag for which status is to be known
        :returns:
            a list of response objects from airflow providing details of the tasks statuses of all the tasks
            assigned to the dag which can be identified by the provided dag_id for the given dag_run_id
        """
        dag_id = kwargs.get('dag_id')
        dag_run_id = kwargs.get('dag_run_id')
        params = ""
        query = ""
        fragment = ""
        tasks = json.loads(self.dag_tasks(dag_id=dag_id).content)['tasks']
        res = []
        try:
            tasks = [task['task_id'] for task in tasks]
            for task_id in tasks:
                path = self.path + "/dags/"+dag_id+"/dagRuns/"+dag_run_id+"/taskInstances/"+task_id
                url = urlunparse((
                    self.scheme,
                    self.netloc,
                    path,
                    params,
                    query,
                    fragment
                ))
                res.append(requests.get(url=url, auth=(self.conn.user, self.conn.password)))
                return res

        except Exception as e:
            print("Exception occured in listing tasks of the dag.",
                  "The dag may not have any tasks. Exception message is:\"", str(e) + "\"")



    def get_Log(self, dag_id, dag_run_id, validation_task_id):
        """
        :param:
            dag_id: the id of the dag that's to be triggered
        :returns:
            Get logs for a specific task instance and its try number.
        """
        task_try_number = 1
        path = self.path + "dags/" + dag_id + "/dagRuns/" + dag_run_id + "/taskInstances/" + validation_task_id + "/logs/" + str(task_try_number)
        params = ""
        query = ""
        fragment = ""
        url = urlunparse((
            self.scheme,
            self.netloc,
            path,
            params,
            query,
            fragment
        ))
        res = None
        try:
            res = requests.get(url=url, auth=(self.conn.user, self.conn.password))
        except requests.exceptions.RequestException as e:
            print("Exception thrown by trigger_dag. Exception message is: \"", str(e) + "\"")
        return res