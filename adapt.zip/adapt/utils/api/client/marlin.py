import requests
from urllib.parse import urlparse, urlunparse, urlencode
from configuration.models import ApiConfig


class Marlin:
    def __init__(self, url, credentials: dict = None, **params) -> None:
        # send the endpoint with the url
        # e.g. https://vmiceberg-stg-api-service-scdc1-staging-tesseract-iceberg-stg.svc-stage.eng.vmware.com:8443/api/marlin/v1/getIngestionInfoView
        self.url_parts = list(urlparse(url))
        self.query = urlencode(params)
        self.url_parts[4] = self.query
        self.url = urlunparse(self.url_parts)
        self.credentials = credentials

    def get_conf(self):
        try:
            res = requests.get(self.url, headers=self.credentials)
        except Exception as e:
            res = str(e)
        return res

    def parse(self, content):
        ''' parses get conf logic to fit adapt standards
        if data is for master_config table
        data = {
            'identifier': 'ts_form',
            'etl_name': '',
            'test_script_path': ''
        }
        elif data is for user_connections table
        data = {
            'identifier': '', [form1 if source data else target data]
            'platform': '',
            'service': '',
            ...
        }
        ... should have keys specific to the service as mentioned in
        the connection_details column of the services table
        '''
        # data = {'identifier': 'form1'}
        host = content.get("data")[0].get("connection_url").split(" ")[3].strip("(").strip(")").split("=")[1]
        port = content.get("data")[0].get("connection_url").split(" ")[4].strip("(").strip(")").split("=")[1]
        username = content.get("data")[0].get("user_name")
        print("ServiveName", content.get("data")[0].get("connection_url"))
        service_name = content.get("data")[0].get("connection_url").split(" ")[7].strip("(").strip(")").split("=")[1]
        pwd = content.get("data")[0].get("password_encrypted")
        driver_name = content.get("data")[0].get("driver_name")
        dbDriverName = ApiConfig.get_dataneeded(driver_name)
        db_name = ""
        print(db_name)
        dbServiceName = ApiConfig.query.all()
        for val in dbServiceName:
            if val.driver_name == driver_name:
                db_name += dbDriverName
                print("dbName", db_name)
        data = {
            'platform': 'Onpremises',
            'service': db_name,
            'Service_Name': service_name,
            'Password': 'u7dgw4bvf',
            'User': username,
            'Port': port,
            'Host': host
        }

        # conn = {"connection_details": {"password": pwd, "username": username, "port": port, "host": host,
        #                               "database": db_name}, "additional_details": {"table name": 'null'}}
        return data

