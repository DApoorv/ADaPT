class ObjectFactory:
    _objectlist = {}
    
    def create(self, key, **kwargs):
        """function takes a key (identifier) as argument and 
        returns corresponding class object"""
        try:
            return self._objectlist.get(key)(**kwargs)
        except:
            raise ValueError

    def register(self, key, cls):
        """function takes the key and the class as arguments and registers them
        in the _objectlist dictionary"""
        if not self._objectlist.get(key):
            self._objectlist[key] = cls


ob = ObjectFactory()