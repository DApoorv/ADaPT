from xmlrpc.client import Boolean
from configuration.models import *
from flask import g
from utils.objectfactory import ob

class ServiceProvider:

    def __call__(self, connection_name:str=None, val_type: str=None):
        if connection_name:
            con = UserConnections.query.filter_by(
                test_environment=g.current_env,
                stage=g.current_stage,
                connection_name=connection_name
            ).order_by(
                desc(UserConnections.updated_on)
            ).first()
            if con:
                resource_key = Services.query.filter_by(
                        service_name=con.service
                ).first().resource_key
                return ob.create(con.platform, service=resource_key).service()
        elif val_type:
            return ob.create('dags', val_type=val_type).dag
        else:
            return None
        
sp = ServiceProvider()
