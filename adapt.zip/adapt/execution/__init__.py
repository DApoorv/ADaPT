# encoded in UTF-8
from flask import Blueprint

from .views import *
from execution.views.bucketconfig import *

execution = Blueprint('execution', __name__)
execution.add_url_rule('/execution', view_func=execute_overview, methods=['GET', 'POST'])
execution.add_url_rule('/execute/workflow-mgmt', view_func=workflow, methods=['GET', 'POST'])
execution.add_url_rule('/accelerators', view_func=accelerator, methods=['GET'])
# execution.add_url_rule('/accelerators/test-script-gen', view_func=test_script_gen, methods=['GET', 'POST'])
execution.add_url_rule('/accelerators/test-script-gen', view_func=TestScriptLoader.as_view('test_script_gen'))
execution.add_url_rule('/accelerators/bucketconfig', view_func=BucketConfigView.as_view('bucketconfig'))
# execution.add_url_rule('/accelerators/test-data-gen', view_func=test_data_gen, methods=['GET', 'POST'])
execution.add_url_rule('/accelerators/test-data-gen', view_func=TestDataLoader.as_view('test_data_gen'))
execution.add_url_rule('/execution/results', view_func=result, methods=['GET'])
execution.add_url_rule('/execution/dashboard', view_func=dashboard, methods=['GET'])