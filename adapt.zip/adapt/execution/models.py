# encoded in UTF-8
from db import dbf_obj
from sqlalchemy import desc

db = dbf_obj.get_dbase()


class MasterConfig(db.Model):
    __tablename__ = "master_config_new"
    sno = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pipeline_identifier = db.Column(db.Integer)
    environment = db.Column(db.Text)
    stage = db.Column(db.Text)
    application_name = db.Column(db.Text)
    test_script_path = db.Column(db.Text)
    pipeline_to_testscript_mapped = db.Column(db.Text)
    source_system = db.Column(db.Text)
    ingestion_type = db.Column(db.Text)
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    status = db.Column(db.Text)
    timestamp = db.Column(db.DateTime)
    exp_time_taken = db.Column(db.Integer)
    exp_cpu_count = db.Column(db.Integer)
    buffer_time = db.Column(db.Integer)

    def __init__(self, pipeline_identifier, environment, stage, application_name, test_script_path,
                 pipeline_to_testscript_mapped, source_system, ingestion_type, start_time, end_time, status, timestamp,
                 exp_time_taken, exp_cpu_count, buffer_time):
        self.pipeline_identifier = pipeline_identifier
        self.environment = environment
        self.stage = stage
        self.application_name = application_name
        self.test_script_path = test_script_path
        self.pipeline_to_testscript_mapped = pipeline_to_testscript_mapped
        self.source_system = source_system
        self.ingestion_type = ingestion_type
        self.start_time = start_time
        self.end_time = end_time
        self.status = status
        self.timestamp = timestamp
        self.exp_time_taken = exp_time_taken
        self.exp_cpu_count = exp_cpu_count
        self.buffer_time = buffer_time

    def save(self):
        db.session.add(self)
        db.session.commit()


class APIresponse(db.Model):
    __tablename__ = 'apires_db2db'
    sno = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pipeline_id = db.Column(db.Integer)
    pipeline_name = db.Column(db.String(300))
    source_system = db.Column(db.String(300))
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    conn_details = db.Column(db.JSON)
    status = db.Column(db.String(100))
    updatedon = db.Column(db.DateTime)
    ingestion_type = db.Column(db.String)
    connection_id = db.Column(db.Integer)
    connection_name = db.Column(db.String)
    file_format = db.Column(db.String)
    created_by = db.Column(db.String)
    stage = db.Column(db.String)
    environment = db.Column(db.String)
    mode = db.Column(db.String)

    def __init__(self, pipeline_id, pipeline_name, source_system, start_time, end_time,
                 conn_details, status, updatedon, ingestion_type, connection_id,
                 connection_name, file_format, created_by, stage, environment, mode) -> None:
        self.pipeline_id = pipeline_id
        self.pipeline_name = pipeline_name
        self.source_system = source_system
        self.start_time = start_time
        self.end_time = end_time
        self.conn_details = conn_details
        self.status = status
        self.updatedon = updatedon
        self.ingestion_type = ingestion_type,
        self.connection_id = connection_id,
        self.connection_name = connection_name,
        self.file_format = file_format
        self.created_by = created_by
        self.stage = stage
        self.environment = environment
        self.mode = mode

    def __repr__(self) -> str:
        return self.pipeline_id

    def save(self):
        db.session.add(self)
        db.session.commit()


class APIF2F(db.Model):
    __tablename__ = 'apires_f2f'
    sno = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pipeline_id = db.Column(db.Integer)
    pipeline_name = db.Column(db.String)
    ingestion_type = db.Column(db.String)
    status = db.Column(db.String)
    source = db.Column(db.String)
    connection_id = db.Column(db.Integer)
    connection_name = db.Column(db.String)
    connection_url = db.Column(db.String)
    user_name = db.Column(db.String)
    password = db.Column(db.String)
    file_path = db.Column(db.String)
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    file_format = db.Column(db.String)
    updatedon = db.Column(db.DateTime)
    created_by = db.Column(db.String)
    stage = db.Column(db.String)
    environment = db.Column(db.String)
    mode = db.Column(db.String)

    def __init__(self, pipeline_id, pipeline_name, source, start_time, end_time,
                 connection_url, user_name, password, file_path, status, updatedon,
                 ingestion_type, connection_id, connection_name, file_format, created_by, stage,
                 environment, mode) -> None:
        self.pipeline_id = pipeline_id
        self.pipeline_name = pipeline_name
        self.source = source
        self.start_time = start_time
        self.end_time = end_time
        self.connection_url = connection_url
        self.status = status
        self.updatedon = updatedon
        self.ingestion_type = ingestion_type,
        self.connection_id = connection_id,
        self.connection_name = connection_name,
        self.file_format = file_format
        self.user_name = user_name
        self.password = password
        self.file_path = file_path
        self.created_by = created_by
        self.stage = stage
        self.environment = environment
        self.mode = mode

    def __repr__(self) -> str:
        return self.pipeline_id

    def save(self):
        db.session.add(self)
        db.session.commit()


class APIF2DB(db.Model):
    __tablename__ = 'apires_f2db'
    sno = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pipeline_id = db.Column(db.Integer)
    pipeline_name = db.Column(db.String)
    ingestion_type = db.Column(db.String)
    status = db.Column(db.String)
    source = db.Column(db.String)
    connection_id = db.Column(db.Integer)
    connection_name = db.Column(db.String)
    connection_url = db.Column(db.String)
    user_name = db.Column(db.String)
    password = db.Column(db.String)
    file_path = db.Column(db.String)
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    file_format = db.Column(db.String)
    updatedon = db.Column(db.DateTime)
    created_by = db.Column(db.String)
    stage = db.Column(db.String)
    environment = db.Column(db.String)
    mode = db.Column(db.String)

    def __init__(self, pipeline_id, pipeline_name, source, start_time, end_time,
                 connection_url, user_name, password, file_path, status, updatedon,
                 ingestion_type, connection_id, connection_name, file_format, created_by,
                 stage, environment, mode) -> None:
        self.pipeline_id = pipeline_id
        self.pipeline_name = pipeline_name
        self.source = source
        self.start_time = start_time
        self.end_time = end_time
        self.connection_url = connection_url
        self.status = status
        self.updatedon = updatedon
        self.ingestion_type = ingestion_type,
        self.connection_id = connection_id,
        self.connection_name = connection_name,
        self.file_format = file_format
        self.user_name = user_name
        self.password = password
        self.file_path = file_path
        self.created_by = created_by
        self.stage = stage
        self.environment = environment
        self.mode = mode

    def __repr__(self) -> str:
        return self.pipeline_id

    def save(self):
        db.session.add(self)
        db.session.commit()


class ApiSFDC2DB(db.Model):
    __tablename__ = 'apires_sfdc2db'
    sno = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pipeline_id = db.Column(db.Integer)
    pipeline_name = db.Column(db.String)
    ingestion_type = db.Column(db.String)
    status = db.Column(db.String)
    source_system = db.Column(db.String)
    connection_id = db.Column(db.Integer)
    connection_name = db.Column(db.String)
    connection_url = db.Column(db.String)
    user_name = db.Column(db.String)
    password_encrypted = db.Column(db.String)
    security_token = db.Column(db.String)
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    file_format = db.Column(db.String)
    created_by = db.Column(db.String)
    updatedon = db.Column(db.DateTime)
    sandbox = db.Column(db.String)
    stage = db.Column(db.String)
    environment = db.Column(db.String)


    def __init__(self, pipeline_id, pipeline_name, source_system, start_time, end_time,
                 connection_url, user_name, password_encrypted, security_token, status, updatedon,
                 ingestion_type, connection_id, connection_name, file_format, created_by, sandbox, stage, environment) -> None:
        self.pipeline_id = pipeline_id
        self.pipeline_name = pipeline_name
        self.source_system = source_system
        self.start_time = start_time
        self.end_time = end_time
        self.connection_url = connection_url
        self.status = status
        self.updatedon = updatedon
        self.ingestion_type = ingestion_type,
        self.connection_id = connection_id,
        self.connection_name = connection_name,
        self.file_format = file_format
        self.user_name = user_name
        self.password_encrypted = password_encrypted
        self.security_token = security_token
        self.created_by = created_by
        self.sandbox = sandbox
        self.stage = stage
        self.environment = environment


    def __repr__(self) -> str:
        return self.pipeline_id

    def save(self):
        db.session.add(self)
        db.session.commit()


class APIJSONALL():
    __tablename__ = 'api_json_all'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    data = db.Column(db.JSON)

    def __init__(self, data) -> None:
        self.data = data

    def __repr__(self) -> str:
        return self.data

    def save(self):
        db.session.add(self)
        db.session.commit()


class AirflowConf(db.Model):
    sno = db.Column(db.Integer, primary_key=True, autoincrement=True)
    air_host = db.Column(db.String(100), nullable=False, unique=True)
    air_port = db.Column(db.Integer, nullable=False)
    air_user = db.Column(db.String(100), nullable=False)
    air_pass = db.Column(db.String(100), nullable=False)

    def __init__(self, host, port, user, password) -> None:
        self.air_host = host
        self.air_port = port
        self.air_user = user
        self.air_pass = password

    @staticmethod
    def get_conn():
        return AirflowConf.query.first()

    def __repr__(self):
        return 'AirflowConf %r:%r' % (self.air_host, self.air_port)

    def save(self):
        db.session.add(self)
        db.session.commit()


class ValidationLog(db.Model):
    log_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    emp_id = db.Column(db.String(80), nullable=False)
    test_environment = db.Column(db.String(80), nullable=False)
    stage = db.Column(db.String(80), nullable=False)
    etl_run_id = db.Column(db.String(100), unique=True, nullable=False)
    dag_id = db.Column(db.String(100), nullable=False)
    dag_run_id = db.Column(db.String(100), nullable=False, unique=True)
    orchestration_task_id = db.Column(db.String(100), nullable=False)
    orchestration_status = db.Column(db.String(100), nullable=False)
    performance_task_id = db.Column(db.String(100), nullable=False)
    performance_status = db.Column(db.String(100), nullable=False)
    validation_task_id = db.Column(db.String(100), nullable=False)
    validation_status = db.Column(db.String(100), nullable=False)
    start_time = db.Column(db.DateTime, server_default=db.func.now())
    end_time = db.Column(db.DateTime, server_default=db.func.now(), server_onupdate=db.func.now())

    def __init__(self, emp_id, test_environment, stage, etl_run_id, dag_id, dag_run_id, orchestration_task_id,
                 orchestration_status, performance_task_id, performance_status, validation_task_id, validation_status):
        self.emp_id = emp_id
        self.test_environment = test_environment
        self.stage = stage
        self.etl_run_id = etl_run_id
        self.dag_id = dag_id
        self.dag_run_id = dag_run_id
        self.orchestration_task_id = orchestration_task_id
        self.orchestration_status = orchestration_status
        self.performance_task_id = performance_task_id
        self.performance_status = performance_status
        self.validation_task_id = validation_task_id
        self.validation_status = validation_status

    def save(self):
        db.session.add(self)
        db.session.commit()

class AirflowLogs(db.Model):
    __tablename__ = 'aiflow_logs'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dag_id = db.Column(db.String)
    dag_run_id = db.Column(db.String)
    task_id = db.Column(db.String)
    log_value = db.Column(db.String)
    updated_on = db.Column(db.DateTime)

    def __init__(self, dag_id, dag_run_id, task_id, log_value, updated_on):
        self.dag_id = dag_id
        self.dag_run_id = dag_run_id
        self.task_id = task_id
        self.log_value = log_value
        self.updated_on = updated_on

    def save(self):
        db.session.add(self)
        db.session.commit()


class DbConfigModel(db.Model):
    __tablename__ = "etl_trigger_log"
    run_id = db.Column(db.Integer, primary_key=True)
    etl_name = db.Column(db.Text)
    etl_run_id = db.Column(db.Text)
    etl_platform = db.Column(db.Text)
    etl_service = db.Column(db.Text)
    username = db.Column(db.Text)
    stage = db.Column(db.Text)
    environment = db.Column(db.Text)
    etl_status = db.Column(db.Text)
    trigger_val = db.Column(db.String(3), nullable=False)
    trigger_orch = db.Column(db.String(3), nullable=False)
    trigger_perform = db.Column(db.String(3), nullable=False)
    val_type = db.Column(db.String(120), nullable=False)
    time_stamp = db.Column(db.DateTime)
    mode = db.Column(db.String)

    def __init__(self, etl_name, etl_run_id, etl_platform, etl_service, username, stage, environment, etl_status,
                 trigger_perform, trigger_orch, trigger_val, val_type, time_stamp, mode):
        self.etl_name = etl_name
        self.username = username
        self.etl_run_id = etl_run_id
        self.etl_platform = etl_platform
        self.etl_service = etl_service
        self.stage = stage
        self.environment = environment
        self.etl_status = etl_status
        self.trigger_perform = trigger_perform
        self.trigger_orch = trigger_orch
        self.trigger_val = trigger_val
        self.val_type = val_type
        self.time_stamp = time_stamp
        self.mode = mode

    def log_entry(self):
        """function saves the log in the db config validation table"""
        db.session.add(self)
        db.session.commit()


class CONF_PERF(db.Model):
    __tablename__ = "conf_perf"
    id = db.Column(db.Integer, primary_key=True)
    job_name = db.Column(db.Text)
    exp_time_taken = db.Column(db.Integer)
    exp_cpu_count = db.Column(db.Integer)
    buffer_time = db.Column(db.Integer)

    def __init__(self, job_name, exp_time_taken, exp_cpu_count, buffer_time):
        self.job_name = job_name
        self.exp_time_taken = exp_time_taken
        self.exp_cpu_count = exp_cpu_count
        self.buffer_time = buffer_time

    def save(self):
        """function saves the log in the db config validation table"""
        db.session.add(self)
        db.session.commit()


class Output:
    def __init__(self, pipeline_id, App_ETL_Name, test_name, column_name, column_type, expected_results, Result,
                 Source_Count, Target_Count, source_mismatch_table, target_mismatch_table, Source_Mismatch_count,
                 Target_Mismatch_Count, error_details, source_query, target_query,
                 Test_Case_Execution_Start_Time, Test_Case_Execution_End_Time, Insertion_Date, Insertion_TimeStamp,
                 validation_run_id) -> None:
        self.pipeline_id = pipeline_id
        self.App_ETL_Name = App_ETL_Name
        self.tc = test_name
        self.column_name = column_name
        self.column_type = column_type
        self.expected_res = expected_results
        self.res = Result
        self.src_count = Source_Count
        self.tgt_count = Target_Count
        self.source_mismatch_table = source_mismatch_table
        self.target_mismatch_table = target_mismatch_table
        self.src_mismatch_count = Source_Mismatch_count
        self.tgt_mismatch_count = Target_Mismatch_Count
        self.err = error_details
        self.source_query = source_query
        self.target_query = target_query
        self.Test_Case_Execution_Start_Time = Test_Case_Execution_Start_Time
        self.Test_Case_Execution_End_Time = Test_Case_Execution_End_Time
        self.insertion_dt = Insertion_Date
        self.insertion_ts = Insertion_TimeStamp
        self.validation_run_id = validation_run_id


class OutputF2DB:
    def __init__(self, TEST_ID, TEST_NAME, SOURCE_FILE_PATH, SOURCE_FILE_FORMAT, TARGET_QUERY,
                 ROW_COUNT, validation_run_id, App_ETL_Name, Environment, Stage, USER, pipeline_id, Result, error_details, insertion_timestamp, insertion_date,
                 source_record_count, target_record_count, Source_Mismatch_Table_Name, Target_Mismatch_Table_Name,
                 Source_Name) -> None:
        self.TEST_ID = TEST_ID
        self.TEST_NAME = TEST_NAME
        self.SOURCE_FILE_PATH = SOURCE_FILE_PATH
        self.SOURCE_FILE_FORMAT = SOURCE_FILE_FORMAT
        self.TARGET_QUERY = TARGET_QUERY
        self.ROW_COUNT = ROW_COUNT
        self.validation_run_id = validation_run_id
        self.App_ETL_Name = App_ETL_Name
        self.Environment = Environment
        self.Stage = Stage
        self.USER = USER
        self.pipeline_id = pipeline_id
        self.res = Result
        self.error_details = error_details
        self.insertion_date = insertion_date
        self.insertion_timestamp = insertion_timestamp
        self.source_record_count = source_record_count
        self.target_record_count = target_record_count
        self.Source_Mismatch_Table_Name = Source_Mismatch_Table_Name
        self.Target_Mismatch_Table_Name = Target_Mismatch_Table_Name
        self.Source_Name = Source_Name


class OutputSFDC2DB:
    def __init__(self, App_ETL_Name, test_name, Source_Name, column_name, column_type, expected_results, Result,
                 Source_Count, Target_Count, source_mismatch_table, target_mismatch_table, Source_Mismatch_count,
                 Target_Mismatch_Count, error_details, source_query, target_query,
                 Test_Case_Execution_Start_Time, Test_Case_Execution_End_Time, Insertion_Date, Insertion_TimeStamp,
                 App_ETL_Run_Id) -> None:
        self.App_ETL_Name = App_ETL_Name
        self.test_name = test_name
        self.Source_Name = Source_Name
        self.column_name = column_name
        self.column_type = column_type
        self.expected_res = expected_results
        self.res = Result
        self.src_count = Source_Count
        self.tgt_count = Target_Count
        self.source_mismatch_table = source_mismatch_table
        self.target_mismatch_table = target_mismatch_table
        self.src_mismatch_count = Source_Mismatch_count
        self.tgt_mismatch_count = Target_Mismatch_Count
        self.err = error_details
        self.source_query = source_query
        self.target_query = target_query
        self.Test_Case_Execution_Start_Time = Test_Case_Execution_Start_Time
        self.Test_Case_Execution_End_Time = Test_Case_Execution_End_Time
        self.insertion_dt = Insertion_Date
        self.insertion_ts = Insertion_TimeStamp
        self.App_ETL_Run_Id = App_ETL_Run_Id


class MetricDataDB2DB:
    def __init__(self, Component_Name, Run_Id, CPU_Utilisation, Memory_Used_in_GB, Source_File_Size_in_GB, expected_results,
                 Target_File_Size_in_GB, Test_Case_Execution_Start_Time, Test_Case_Execution_End_Time,
                 Test_Case_Run_Time, Number_of_Test_Cases, Total_Run_Time_Taken, Error_Details, Insertion_TimeStamp) -> None:
        self.Component_Name = Component_Name
        self.Run_Id = Run_Id
        self.CPU_Utilisation = CPU_Utilisation
        self.Memory_Used_in_GB = Memory_Used_in_GB
        self.Source_File_Size_in_GB = Source_File_Size_in_GB
        self.expected_res = expected_results
        self.Target_File_Size_in_GB = Target_File_Size_in_GB
        self.Test_Case_Execution_Start_Time = Test_Case_Execution_Start_Time
        self.Test_Case_Execution_End_Time = Test_Case_Execution_End_Time
        self.Test_Case_Run_Time = Test_Case_Run_Time
        self.Number_of_Test_Cases = Number_of_Test_Cases
        self.Total_Run_Time_Taken = Total_Run_Time_Taken
        self.Error_Details = Error_Details
        self.Insertion_TimeStamp = Insertion_TimeStamp


class MetricDataF2DB:
    def __init__(self, CPU_Utilisation, Memory_Used_in_GB, Source_File_Size_in_GB,
                 Target_File_Size_in_GB, Test_Case_Execution_Start_Time, Test_Case_Execution_End_Time,
                 Test_Case_Run_Time, Number_of_Test_Cases, Total_Run_Time_Taken, Insertion_TimeStamp) -> None:
        self.CPU_Utilisation = CPU_Utilisation
        self.Memory_Used_in_GB = Memory_Used_in_GB
        self.Source_File_Size_in_GB = Source_File_Size_in_GB
        self.Target_File_Size_in_GB = Target_File_Size_in_GB
        self.Test_Case_Execution_Start_Time = Test_Case_Execution_Start_Time
        self.Test_Case_Execution_End_Time = Test_Case_Execution_End_Time
        self.Test_Case_Run_Time = Test_Case_Run_Time
        self.Number_of_Test_Cases = Number_of_Test_Cases
        self.Total_Run_Time_Taken = Total_Run_Time_Taken
        self.Insertion_TimeStamp = Insertion_TimeStamp


class OutputPERFORM(db.Model):
    __tablename__ = "performance"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    job_name = db.Column(db.String)
    job_id = db.Column(db.Integer)
    expected_time_taken_in_sec = db.Column(db.Integer)
    expected_cpu_capacity = db.Column(db.Integer)
    buffer = db.Column(db.Integer)
    actual_time_taken_in_sec = db.Column(db.Integer)
    actual_capacity = db.Column(db.Integer)
    result = db.Column(db.String)
    error_details = db.Column(db.String)

    def __init__(self, job_name,job_id, expected_time_taken_in_sec, expected_cpu_capacity,
                 buffer, actual_time_taken_in_sec, actual_capacity, result, error_details) -> None:
        self.job_name = job_name
        self.job_id = job_id
        self.expected_time_taken_in_sec = expected_time_taken_in_sec
        self.expected_cpu_capacity = expected_cpu_capacity
        self.buffer = buffer
        self.actual_time_taken_in_sec = actual_time_taken_in_sec
        self.actual_capacity = actual_capacity
        self.result = result
        self.error_details = error_details

    def save(self):
        """function saves the log in the db performance table"""
        db.session.add(self)
        db.session.commit()

