from flask_wtf import FlaskForm
from flask_wtf import Form
from wtforms import StringField, validators, RadioField, SubmitField, SelectMultipleField, SelectField, IntegerField, PasswordField, HiddenField
from flask_wtf.file import  DataRequired, FileAllowed, FileRequired, FileField
from wtforms.validators import InputRequired


class SingleButtonForm(FlaskForm):
    identifier = StringField()
    submit = SubmitField("Submit")

class GenerateForm(SingleButtonForm):
    pass


class WorkflowMgmt(FlaskForm):
    x = SelectMultipleField('Select multiple', choices=[(1, 'File to File'), (2, 'File to DB'), (3, 'DB to DB')])
    target_entity_name = StringField(u'ETL Pipeline Name', validators=[validators.input_required()])
    etl_validation = RadioField(u'ETL Validation', choices=[(1, 'File to File'), (2, 'File to DB'), (3, 'DB to DB')])
    performance_validation = RadioField(u'Performance Validation', choices=[(1, 'Yes'), (0, 'No')])
    orchestration_validation = RadioField(u'Orchestration Validation', choices=[(1, 'Yes'), (0, 'No')])
    trigger_etl = RadioField(u'Trigger ETL', choices=[(1, 'Yes'), (0, 'No')])
    submit = SubmitField('Execute')


class ManualTestForm(FlaskForm):
    indentifier= StringField()
    t_file= FileField("Upload", validators = [ FileRequired("File needs to be selected"), FileAllowed(['xlsx'], "WRONG FILETYPE: Allowed file type= xlsx")])
    upload= SubmitField("Upload")


class AutoTestForm(FlaskForm):
    indentifier= StringField()
    t_file= FileField("Upload", validators = [ FileRequired("File needs to be selected"), FileAllowed(['xlsx'], "WRONG FILETYPE: Allowed file type= xlsx")])
    upload= SubmitField("Upload")


class GenerateForm(FlaskForm):
    indentifier= StringField()
    generate= SubmitField("Generate Test Script")


class GenerateDataForm(FlaskForm):
    indentifier= StringField()
    Host = StringField("Db Host", validators=[DataRequired()])
    Port = StringField("Db Port", validators=[DataRequired()])
    DbName = StringField("DbName", validators=[DataRequired()])
    TableName = StringField("TableName", validators=[DataRequired()])
    UserName = StringField("UserName", validators=[(DataRequired())])
    Password = PasswordField("Password", validators=[(DataRequired())])
    M_Host = StringField("Db Host", validators=[DataRequired()])
    M_Port = StringField("Db Port", validators=[DataRequired()])
    M_DbName = StringField("DbName", validators=[DataRequired()])
    M_TableName = StringField("TableName", validators=[DataRequired()])
    M_UserName = StringField("UserName", validators=[(DataRequired())])
    M_Password = PasswordField("Password", validators=[(DataRequired())])
    M_service_name= SelectField("service_name", choices=[("postgresql", "postgresql")])
    total_records= IntegerField("Total Records",  validators=[validators.input_required()])
    duplicate_Records= IntegerField("Duplicate Records",  validators=[validators.input_required()])
    storage_platform= SelectField("StoragePlatform", choices=[("cloud", "cloud")])
    service_name= SelectField("service_name", choices=[("postgresql", "postgresql")])
    country= SelectField("Country", choices=[("en_US", "United States"), ("en_IN", "India"),('da_DK', 'Denmark'), ('cs_CZ', 'Czech Republic'),
                            ('bs_BA','Bosnia and Herzegovina'), ('bg_BG', 'Bulgaria'), ('ar_SA', 'Saudi Arabia'), ('ar_PS', 'Palästina'), ('ar_JO','Jordan'), ('ar_EG', 'Egypt'), ('ar_AE', 'United Arab Emirates')])
    output_path= StringField("Output File Path", validators=[validators.input_required()])
    output_format= SelectField("Output Format", choices=[("csv", "csv"), ("xml", "xml"), ("parquet", "parquet")])
    schema_path= SelectField("Schema Path", choices=[("s3://test-doc-file-storage-temp-bucket/Test Environment 1/Stage 1/Synthetic Data Configuration File/synthetic_data_configuration_file.json", "s3://test-doc-file-storage-temp-bucket/Test Environment 1/Stage 1/Synthetic Data Configuration File/synthetic_data_configuration_file.json")])
    generate= SubmitField("Generate Data")


class Overview(FlaskForm):
    validate = SubmitField("Submit")


class BucketConfigForm(FlaskForm):
    identifier = HiddenField()
    test_case = StringField(label='Test Case', validators=[validators.InputRequired()])
    bucket_list = SelectField(label='Expected Result', choices=[(None, 'Choose expected result')], validators=[DataRequired()])
    submit = SubmitField(label='submit')


class TSForm(FlaskForm):
    identifier = HiddenField(default="ts_form")
    form_type = HiddenField(default="manual")
    etl_name = SelectField("Select Pipelines", validators=[InputRequired()], choices=[("", "Select Pipelines"),("", "Select Pipelines")])
    # test_script_loc = FileField("Test Script Location", validators=[InputRequired()])
    test_script_path = SelectField("Select Test Script", validators=[InputRequired()], choices=[("", "Select Test Script")])
    # src_ftype = SelectField("Source File Type", validators=[InputRequired()], choices=[("", "Select File Type"), (".csv", ".csv"), (".excel", ".excel"), (".paraquet", ".paraquet")])
    # tgt_ftype = SelectField("Target File Type", validators=[InputRequired()], choices=[("", "Select File Type"), (".csv", ".csv"), (".excel", ".excel"), (".paraquet", ".paraquet")])
    submit = SubmitField()


class APIForm(FlaskForm):
    form_type = HiddenField(default='api')
    identifier = HiddenField(default='configure-etl-endpoints')
    url = StringField('URL', validators=[InputRequired()])
    ingestionType = SelectField('Ingestion Type:', validators=[InputRequired()], choices=[("", "Select Ingestion Type")])
    sourceName = SelectField('Source Name:', validators=[InputRequired()],choices=[("", "Select Source Name")])
    conn_db_name = SelectField('Database Names:', validators=[InputRequired()], choices=[("", "Select Database Type")])
    conn_url_type = SelectField("Connection Urls:", validators=[InputRequired()], choices=[("", "Select Connection Urls")])
    targetDBName = SelectField("Target Database:", validators=[InputRequired()])
    conn_type = StringField('Connection Type', validators=[InputRequired()])
    configure = SubmitField("Save")