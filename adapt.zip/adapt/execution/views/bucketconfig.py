from email import message
from utils.defaults import validate_request
from sqlalchemy.exc import IntegrityError
from flask import flash, jsonify, redirect, render_template, request, url_for
from flask.views import MethodView
from configuration.models import BucketConfig
from execution.forms import BucketConfigForm
from werkzeug.exceptions import BadRequestKeyError



class BucketConfigView(MethodView):
    decorators = [validate_request]

    def get(self):
        """
        function to return testcases byBucketRule
        In case a bucket rule is given as an argument [as part of the query
        string] then only test cases corresponding to that bucket rule is returned.
        """
        if not request.args:

            testcasesbyBucketRule = BucketConfig.get_bucketrules()
            bucketConfigTable = BucketConfig.query.all()
            form1 = BucketConfigForm()
            for tc in testcasesbyBucketRule:
                form1.bucket_list.choices.append((tc, tc))

            return render_template('accelerators/test_scenarios.html',
                                   form1=form1,
                                   table=bucketConfigTable
                                   )
        try:
            bucket_rule = request.args.get('bucket_rule')
            test_cases = jsonify(BucketConfig.get_testcasesbyBucketRule(bucket_rule))
        except BadRequestKeyError as e:
            test_cases = jsonify("No test cases found for the bucket_rule passed")
        return test_cases

    def post(self):

        query_dict = request.form.to_dict()
        tc = query_dict['new-test-case']
        if tc:
            bucket_rule = query_dict['bucket_list']
            dataneeded = BucketConfig.get_dataneeded(bucket_rule)
            try:
                bucket_entry = BucketConfig(
                    test_case=tc,
                    bucket_rule=bucket_rule,
                    data_needed=dataneeded
                )
                bucket_entry.save()
                message = tc+': New test case added successfully'
            except IntegrityError as e:
                print(e)
                message = 'Provided test case already exists'
            # flash(message)
        # return redirect(url_for('execution.bucketconfig'))
        return jsonify((200, message))
    

    def patch(self):
        query_dict = request.form.to_dict()
        tc_oldname = query_dict['tc_old']
        tc_newname = query_dict['tc_new']
        BucketConfig.update_testcasename(tc_newname, dict(test_case=tc_oldname))
        return redirect(url_for('execution.bucketconfig'))

    def delete(self):
        pass




