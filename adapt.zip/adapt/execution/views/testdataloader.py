from sqlalchemy import desc
from flask.views import MethodView
from utils.defaults import validate_request
from configuration.forms import *
from execution.forms import *
from flask import session, flash, render_template, redirect, url_for
from configuration.models import TestLog, UserConnections, Services
from utils.serviceprovider import sp
from werkzeug.utils import secure_filename
from datetime import datetime
from utils.objectfactory import ob
from db import dbf_obj
import json


class TestDataLoader(MethodView):
    decorators = [validate_request]

    def get(self):
        g_form= GenerateDataForm()
        qdata= TestLog.query.filter_by(
            stage=session['stage'],
            environment=session['environment'],
            document_name="synthetic_data_configuration_file.json"
        ).order_by(desc('time_stamp')).first()
        tlist=[] 
        if qdata:
            location= UserConnections.query.filter_by(stage= session['stage']).filter_by(test_environment= session['environment']).filter_by(connection_name= "TestDoc Storage Configuration").order_by(desc('updated_on')).first()
            if location:
                buck=""
                resource_key = Services.query.filter_by(service_name=location.service).with_entities(Services.resource_key).first()[0]
                if location.service== "Simple Storage Service":
                    buck= str(qdata.document_path).split('/', 3)
                    s3 = ob.create(location.platform, service=resource_key).service().client
                    try:
                        resp= s3.list_objects(Bucket= buck[2], Prefix= session['environment']+"/"+session['stage']+"/Synthetic Data Configuration File/")
                        for l in resp['Contents']:
                            k=""
                            if location.service== "Simple Storage Service":
                                k= "s3://"+str(buck[2])+"/"+str(l['Key'])
                            tlist.append(k)
                        print(tlist)
                    except Exception as e:
                        flash(e)
            else:
                flash(" please provide the test script location")
        else:
            flash(" please provide config file in test doc page")
        qdata= TestLog.query.filter_by(stage= session['stage']).filter_by( environment= session['environment']).filter_by(document_name= session['environment']+"/"+session['stage']+"/Synthetic Data Configuration File/synthetic_data_configuration_file.json").order_by(desc('time_stamp')).first()
        location= UserConnections.query.filter_by(stage= session['stage']).filter_by(test_environment= session['environment']).filter_by(connection_name= "TestDoc Storage Configuration").order_by(desc('updated_on')).first()
        ldata = [[]]
        if qdata:
            if location:
                if location.service== "Simple Storage Service":
                    resource_key=  "s3"
                    ldata= self.generated_script_links(location.platform, config= qdata.document_path, loc= resource_key)
            else:
                flash(" please provide the test script location")
        else:
            flash(" please provide config file in test doc page, only if you want to use auto data gen")
        ldata=[[]]
        check=0
        location= UserConnections.query.filter_by(stage= session['stage']).filter_by(test_environment= session['environment']).filter_by(connection_name= "TestData Configuration").order_by(desc('updated_on')).first()
        if location:
            buck=""
            if location.service== "Simple Storage Service":
                try:
                    confi= location.connection_details
                    buck= str(confi['conf']['config_details']['out_path']).split('/', 3)
                    print(buck)
                    if len(buck) <= 3:
                        resp= s3.list_objects(Bucket= buck[2])
                    else:
                        resp= s3.list_objects(Bucket= buck[2], Prefix= buck[3])
                    for l in resp['Contents']:
                        tklist=[]
                        res= s3.generate_presigned_url('get_object', Params={'Bucket':  buck[2], 'Key': l['Key']})
                        tklist.append(l['Key']) 
                        tklist.append(l['LastModified']) 
                        tklist.append(res)
                        ldata.append(tklist)
                    print(ldata)
                except Exception as e:
                    check=1
                    print(e)
        else:
            check=1
        slist=[]
        for i in tlist:
            a= (i, i)
            slist.append(a)
        g_form.schema_path.choices =slist
        return render_template('accelerators/test-data-generator.html',  g_form=g_form, ldata=ldata, tlist= tlist, check=check)


    def post(self):
        g_form= GenerateDataForm()
        if g_form.indentifier.data== "g_form":
            db_data={}
            if g_form.storage_platform.data == 'cloud':
                storage_platform= "cloud"
                resource_key= "s3"
            elif g_form.storage_platform.data == 'on-premises':
                storage_platform= "on-premises"

            if g_form.output_format.data== 'db':
                db_data= {
                    "host": g_form.Host.data,
                    "port": g_form.Port.data,
                    "dbname": g_form.DbName.data,
                    "service": g_form.service_name.data,
                    "tablename": g_form.TableName.data,
                    "username": g_form.UserName.data,
                    "password": g_form.Password.data
                }
            dag_data= {"dag_run_id": "Data-Gen" + ''.join(str(datetime.now()).split()),
                        "conf": {
                            "config_details": {
                            "schema_file_path": g_form.schema_path.data,
                            "total_record_count": g_form.total_records.data,
                            "resource_key": resource_key,
                            "storage_platform": storage_platform,
                            "duplicate_record_count": g_form.duplicate_Records.data,
                            "country": g_form.country.data,
                            "out_path": g_form.output_path.data,
                            "output_format": g_form.output_format.data,
                            "db_config_details": db_data,
                            "metrics_config_details": {
                                "host": g_form.M_Host.data,
                                "port": g_form.M_Port.data,
                                "dbname": g_form.M_DbName.data,
                                "service": g_form.M_service_name.data,
                                "tablename": g_form.M_TableName.data,
                                "username": g_form.M_UserName.data,
                                "password": g_form.M_Password.data
                            }
                                }}}
            print(dag_data)
            location= UserConnections.query.filter_by(stage= session['stage']).filter_by(test_environment= session['environment']).filter_by(connection_name= "TestDoc Storage Configuration").order_by(desc('updated_on')).first()
            if location:
                adduser= UserConnections(emp_id= session['user'], test_environment=session['environment'], stage=session['stage'], platform=location.platform, service=location.service,
                        connection_name="TestData Configuration", connection_details=dag_data, created_on=datetime.now(), updated_on = datetime.now())
                db = dbf_obj.get_dbase()
                db.session.add(adduser)
                db.session.commit()
                air_client = ob.create('airflowapiclient')        
                try:
                    res = air_client.trigger(dag_id="Synthetic-Data-Gen", data=json.dumps(dag_data))
                    res = json.loads(res.content)
                    status="running"
                    while status != "completed":
                        respo = air_client.dag_task_status(dag_id= res['dag_id'], dag_run_id=res['dag_run_id'])
                        print("dag task status", respo)
                        if json.loads(respo[0].content)['state'] == "success":
                            status="completed"
                            flash("DAG ran successfully")
                        elif json.loads(respo[0].content)['state'] == "failed":
                            status="completed"
                            flash("DAG run failed")
                    return redirect(url_for('execution.test_data_gen'))
                except Exception as e:
                    print("trigger dag failed", str(e))

    @staticmethod
    def generated_script_links(platform, config, loc):
        buck= config.split('/', 3)
        service = ob.create(platform, service=loc).service()
        #fo= signed_object(loc)
        return service.gen_links(bucke= buck[2], key=buck[3])