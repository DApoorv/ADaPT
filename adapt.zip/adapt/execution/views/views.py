# encoded in UTF-8
from itertools import chain
from pathlib import Path
import io
from time import sleep

from minio import Minio
from pytz import timezone
import pandas as pd
import numpy as np
from sqlalchemy.engine import create_engine
import plotly
import plotly.graph_objects as go
import plotly.express as px
from config import *
from utils.defaults import validate_request
from flask import render_template, request, session, flash, redirect, url_for, g
from werkzeug.utils import secure_filename
from execution.forms import *
from execution.models import *
from configuration.models import UserConnections, BucketConfig, Services, TestLog, user_connection_f2db, \
    UserConnectionsManual, UserConnectionSFDC2DB, user_connection_db2db, user_connection_f2f
from globals.constants import *
from utils.objectfactory import ob
from utils.serviceprovider import sp
from db import dbf_obj
from datetime import datetime
from sqlalchemy import desc, or_
from sqlalchemy.exc import OperationalError, ProgrammingError
import json
from configuration.view.configurationcollectors import getApiDb2Db

count = 0


@validate_request
def workflow():
    if request.method == 'GET':

        db_form3 = TSForm()
        api_form = APIForm()
        testscriptsnames=[]
        checkpipelists = []
        source_names_sfdc = []
        show_validate_table_db2db = []
        show_validate_table_f2f = []
        show_validate_table_f2db = []
        show_validate_table_sfdc = []
        etl_names = []
        conf_perf = []
        try:
            connection_name = testdocstorage
            script_path_list = TestLog.query.filter(
                TestLog.document_path.like("%cript%")).distinct(
                TestLog.document_path).all()
            service = sp(connection_name)

            all_test_scripts = []
            for row in script_path_list:
                path = Path(row.document_path)
                manual_listedfiles = service.manual_listedfiles(path)
                automated_listedfiles = service.listdir(path)
                final_listedfiles = manual_listedfiles + automated_listedfiles
                for file in final_listedfiles:
                    all_test_scripts.append([path, file])
            testscriptsnames = [testscripts[1] for testscripts in all_test_scripts]
            testscriptsnames = set(testscriptsnames)
        except Exception as e:
            flash("Unable to found test-scripts: \"" + str(e) + "\"")

        try:
            checkpipelists = []
            checkpipeonly = MasterConfig.query.distinct(MasterConfig.application_name).with_entities(
                MasterConfig.application_name).all()
            for i in checkpipeonly:
                for j in i:
                    checkpipelists.append(j)
        except Exception as e:
            flash(e)

        try:
            show_validate_table_db2db = db.session.query(APIresponse, MasterConfig).outerjoin(
                MasterConfig, APIresponse.pipeline_name == MasterConfig.application_name).filter(
                APIresponse.stage == session['stage'], APIresponse.environment == session['environment']).distinct(
                APIresponse.pipeline_name, MasterConfig.test_script_path).with_entities(
                APIresponse.pipeline_id, APIresponse.pipeline_name, APIresponse.mode, APIresponse.start_time, APIresponse.end_time,
                APIresponse.status, MasterConfig.test_script_path).all()
        except Exception as e:
            flash("Unable to fetch db2db pipeline details: \"" + str(e) + "\"")

        try:
            show_validate_table_f2f = db.session.query(APIF2F, MasterConfig).outerjoin(
                MasterConfig, APIF2F.pipeline_name == MasterConfig.application_name).filter(
                APIF2F.stage == session['stage'], APIF2F.environment == session['environment']).distinct(
                APIF2F.pipeline_name, MasterConfig.test_script_path).with_entities(
                APIF2F.pipeline_id, APIF2F.pipeline_name, APIF2F.mode, APIF2F.start_time, APIF2F.end_time,
                APIF2F.status, MasterConfig.test_script_path).all()
        except Exception as e:
            flash("Unable to fetch f2f pipeline details: \"" + str(e) + "\"")

        try:
            show_validate_table_f2db = db.session.query(APIF2DB, MasterConfig).outerjoin(
                MasterConfig, APIF2DB.pipeline_name == MasterConfig.application_name).filter(
                APIF2DB.stage == session['stage'], APIF2DB.environment == session['environment']).distinct(
                APIF2DB.pipeline_name, MasterConfig.test_script_path).with_entities(
                APIF2DB.pipeline_id, APIF2DB.pipeline_name, APIF2DB.mode, APIF2DB.start_time, APIF2DB.end_time,
                APIF2DB.status, MasterConfig.test_script_path).all()
        except Exception as e:
            flash("Unable to fetch f2db pipeline details: \"" + str(e) + "\"")

        try:
            source_names_sfdc = ['SFDC']
            show_validate_table_sfdc = db.session.query(ApiSFDC2DB, MasterConfig).outerjoin(
                MasterConfig, ApiSFDC2DB.pipeline_name == MasterConfig.application_name).filter(
                ApiSFDC2DB.stage == session['stage'], ApiSFDC2DB.environment == session['environment']).distinct(
                ApiSFDC2DB.pipeline_name, MasterConfig.test_script_path).with_entities(
                ApiSFDC2DB.pipeline_id, ApiSFDC2DB.pipeline_name, ApiSFDC2DB.start_time, ApiSFDC2DB.end_time,
                ApiSFDC2DB.status, MasterConfig.test_script_path).all()
        except Exception as e:
            flash("Unable to fetch sfdc pipeline details: \"" + str(e) + "\"")

        try:
            # ETL names from AWS api
            etl_platform = ob.create('Amazon Web Services', service='glue').service()
            etl_names = etl_platform.list_jobs()
            # configured perf parameters table
            conf_perf = CONF_PERF.query.all()
        except Exception as e:
            flash("Unable to fetch ETL names: \"" + str(e) + "\"")

        if not request.args:
            return render_template('execution/test-workflow.html',
                                   db_form3=db_form3,
                                   api_form=api_form,
                                   checkpipelists=checkpipelists,
                                   all_test_scripts=testscriptsnames,
                                   source_names_sfdc=source_names_sfdc,
                                   show_validate_table_db2db=show_validate_table_db2db,
                                   show_validate_table_f2f=show_validate_table_f2f,
                                   show_validate_table_f2db=show_validate_table_f2db,
                                   show_validate_table_sfdc=show_validate_table_sfdc,
                                   etl_names=etl_names,
                                   conf_perf=conf_perf
                                   )
        val = request.args.get('val')
        data = request.args.get('data')
        print("Val:", val, ",data:", data)
        # processing for validate
        if val == 'db_name':
            db_name = request.args.get('data')
            session['db'] = db_name
            conn_detailsK = UserConnections.query.filter_by(service=db_name).distinct(
                UserConnections.pipeline_name).with_entities(UserConnections.pipeline_name).all()
            conn_detailsV = UserConnections.query.filter_by(service=db_name).distinct(
                UserConnections.pipeline_name).with_entities(UserConnections.updated_on).all()

            try:
                conn_detailsK_manual = UserConnectionsManual.query.filter_by(service=db_name).distinct(
                    UserConnectionsManual.pipeline_name).with_entities(UserConnectionsManual.pipeline_name).all()
                conn_detailsV_manual = UserConnectionsManual.query.filter_by(service=db_name).distinct(
                    UserConnectionsManual.pipeline_name).with_entities(UserConnectionsManual.updated_on).all()
                conn_detailsK_manual = [val1 for val in conn_detailsK_manual for val1 in val]
                conn_detailsV_manual = [val1 for val in conn_detailsV_manual for val1 in val]
                conn_detailsK.append(conn_detailsK_manual)
                conn_detailsV.append(conn_detailsV_manual)
            except:
                pass

            conn_details_list_Key = []
            conn_details_list_Val = []
            for conn in conn_detailsK:
                for t in conn:
                    conn_details_list_Key.append(t)
            for conn in conn_detailsV:
                for t in conn:
                    conn_details_list_Val.append(str(t))
            dicts = {}
            for i in range(len(conn_details_list_Key)):
                dicts[conn_details_list_Key[i]] = conn_details_list_Val[i]

            return json.dumps(dicts)

        elif val == 'src_name':
            db_name = request.args.get('data')
            session['src'] = db_name
            conn_detailsK = user_connection_f2db.query.distinct(
                user_connection_f2db.pipeline_name).with_entities(user_connection_f2db.pipeline_name).all()
            conn_detailsV = user_connection_f2db.query.distinct(
                user_connection_f2db.pipeline_name).with_entities(user_connection_f2db.updated_on).all()
            try:
                conn_detailsK_manual = UserConnectionsManual.query.distinct(
                    UserConnectionsManual.pipeline_name).with_entities(UserConnectionsManual.pipeline_name).all()
                conn_detailsV_manual = UserConnectionsManual.query.distinct(
                    UserConnectionsManual.pipeline_name).with_entities(UserConnectionsManual.updated_on).all()

                conn_detailsK_manual = [val1 for val in conn_detailsK_manual for val1 in val]
                conn_detailsV_manual = [val1 for val in conn_detailsV_manual for val1 in val]
                conn_detailsK.append(conn_detailsK_manual)
                conn_detailsV.append(conn_detailsV_manual)
            except:
                pass

            conn_details_list_Key = []
            conn_details_list_Val = []
            for conn in conn_detailsK:
                for t in conn:
                    conn_details_list_Key.append(t)
            for conn in conn_detailsV:
                for t in conn:
                    conn_details_list_Val.append(str(t))
            dicts = {}
            for i in range(len(conn_details_list_Key)):
                dicts[conn_details_list_Key[i]] = conn_details_list_Val[i]
            return json.dumps(dicts)

        elif val == 'sfdc_src_name':
            db_name = request.args.get('data')
            session['sfdc_src_name'] = db_name
            conn_detailsK = UserConnectionSFDC2DB.query.filter_by(service=db_name).distinct(
                UserConnectionSFDC2DB.pipeline_name).with_entities(UserConnectionSFDC2DB.pipeline_name).all()
            conn_detailsV = UserConnectionSFDC2DB.query.filter_by(service=db_name).distinct(
                UserConnectionSFDC2DB.pipeline_name).with_entities(UserConnectionSFDC2DB.updated_on).all()

            conn_details_list_Key = []
            conn_details_list_Val = []
            for conn in conn_detailsK:
                for t in conn:
                    conn_details_list_Key.append(t)
            for conn in conn_detailsV:
                for t in conn:
                    conn_details_list_Val.append(str(t))
            dicts = {}
            for i in range(len(conn_details_list_Key)):
                dicts[conn_details_list_Key[i]] = conn_details_list_Val[i]
            print(dicts)
            return json.dumps(dicts)

    elif request.method == 'POST':
        data = request.form.to_dict()
        message=""
        if data:
            form_name = data['identifier']
            if form_name == 'ts_form':
                formastervalue = APIresponse.query.with_entities(
                    APIresponse.pipeline_id, APIresponse.pipeline_name, APIresponse.source_system,
                    APIresponse.start_time, APIresponse.end_time, APIresponse.status, APIresponse.updatedon,
                    APIresponse.ingestion_type).order_by(
                    desc(APIresponse.updatedon)).first()

                dict1 = {}
                dict1['pipeline_id'] = formastervalue[0]
                dict1['pipeline_name'] = formastervalue[1]
                dict1['source_system'] = formastervalue[2]
                dict1['start_time'] = formastervalue[3]
                dict1['end_time'] = formastervalue[4]
                dict1['status'] = formastervalue[5]
                dict1['updatedon'] = formastervalue[6]
                dict1['ingestion_type'] = formastervalue[7]

                new_entry = MasterConfig(
                    pipeline_identifier=dict1.get("pipeline_id"),
                    environment=g.current_env,
                    stage=g.current_stage,
                    application_name=data['pipeline_name'],
                    test_script_path=data['test_script_path'],
                    pipeline_to_testscript_mapped='',
                    source_system=dict1.get("source_system"),
                    ingestion_type=dict1.get("ingestion_type"),
                    start_time=dict1.get("start_time"),
                    end_time=dict1.get("end_time"),
                    status=dict1.get("status"),
                    timestamp=datetime.now(),
                    exp_time_taken=data['exp_time_taken'],
                    exp_cpu_count=data['exp_cpu_count'],
                    buffer_time=data['buffer_time']

                )
                new_entry.save()
                message = 'Data saved successfully to master_config table'

            elif form_name == 'sfdc_ts_form':
                formastervalue = ApiSFDC2DB.query.with_entities(
                    ApiSFDC2DB.pipeline_id, ApiSFDC2DB.pipeline_name, ApiSFDC2DB.source_system,
                    ApiSFDC2DB.start_time, ApiSFDC2DB.end_time, ApiSFDC2DB.status, ApiSFDC2DB.updatedon,
                    ApiSFDC2DB.ingestion_type).order_by(
                    desc(ApiSFDC2DB.updatedon)).first()

                dict1 = {}
                dict1['pipeline_id'] = formastervalue[0]
                dict1['pipeline_name'] = formastervalue[1]
                dict1['source_system'] = formastervalue[2]
                dict1['start_time'] = formastervalue[3]
                dict1['end_time'] = formastervalue[4]
                dict1['status'] = formastervalue[5]
                dict1['updatedon'] = formastervalue[6]
                dict1['ingestion_type'] = formastervalue[7]

                new_entry = MasterConfig(
                    pipeline_identifier=dict1.get("pipeline_id"),
                    environment=g.current_env,
                    stage=g.current_stage,
                    application_name=data['pipeline_name'],
                    test_script_path=data['test_script_path'],
                    pipeline_to_testscript_mapped='',
                    source_system=dict1.get("source_system"),
                    ingestion_type=dict1.get("ingestion_type"),
                    start_time=dict1.get("start_time"),
                    end_time=dict1.get("end_time"),
                    status=dict1.get("status"),
                    timestamp=datetime.now()
                )
                new_entry.save()
                message = 'Data saved successfully to master_config table'

            elif form_name == 'sfdc_form1':
                req = request.form
                list_etls = req.getlist('target-etls')
                trigger_orch = req.get('orchestration') if req.get('orchestration') else "off"
                trigger_perform = req.get('performance') if req.get('performance') else "off"
                trigger_etl = "off"  # req.get('triggerETL') if req.get('triggerETL') else "off"
                val_type = req['etl-val-field-set']

                for etname in list_etls:
                    if "manual" in etname:
                        pipeline_id = etname.split(" ")[2]
                        val_type = val_type + " " + etname.split(" ")[1]
                        var = etname.split(" ")
                        list_etls = var[0] + " " + var[1]
                    else:
                        pipeline_id = etname.split(" ")[1]
                        list_etls = etname.split(" ")[0]
                    run_id = None
                    etl_status = None
                    etl = DbConfigModel(etl_name=etname, etl_run_id=run_id, etl_platform='Amazon Web Services',
                                        etl_service='Glue',
                                        username=session['user'], stage=session['stage'],
                                        environment=session['environment'],
                                        etl_status=etl_status, trigger_perform=trigger_perform,
                                        trigger_orch=trigger_orch,
                                        trigger_val=trigger_etl, val_type=val_type, time_stamp=datetime.now())
                    try:
                        if trigger_etl == "off":
                            print("TRI", trigger_etl)
                            no_run_etl_SFDC(etl, list_etls, pipeline_id)
                        else:
                            etl_run_stat = run_etl(etl, val_type)
                            print("etl triggered", etl_run_stat)
                    except Exception as e:
                        flash("Error at ETL. Error is: \"" + str(e) + "\"")
                        continue
                return redirect(url_for('execution.result'))

            elif form_name == "form_perf":
                req = request.form
                if req:
                    etl_jobs = req.get('etl_jobs')
                    exp_time_taken = req.get('exp_time_taken')
                    exp_cpu_count = req.get('exp_cpu_cnt')
                    buffer_time = req.get('buffer_time')

                    etl = DbConfigModel(etl_name=etl_jobs, etl_run_id="",
                                        etl_platform='Amazon Web Services', etl_service='Glue',
                                        username=session['user'], stage=session['stage'],
                                        environment=session['environment'],
                                        etl_status="No RUN", trigger_perform="",
                                        trigger_orch="", trigger_val="", val_type="",
                                        time_stamp=datetime.now(), mode="")
                    etl.log_entry()
                    entry = CONF_PERF(
                        job_name=etl_jobs,
                        exp_time_taken=exp_time_taken,
                        exp_cpu_count=exp_cpu_count,
                        buffer_time=buffer_time
                    )
                    entry.save()

                flash("Performance Testing parameters got configured!!")
                return redirect(url_for('execution.workflow'))

            elif form_name == "form_perf_table":
                req = request.form
                if req.get('job_name'):
                    job_name = req.get('job_name').split(" ")[0]
                    try:
                        job_name = req.get('job_name').split(" ")[0]
                        exp_time_taken = req.get('job_name').split(" ")[1]
                        exp_cpu_count = req.get('job_name').split(" ")[2]
                        buffer_time = req.get('job_name').split(" ")[3]
                        status = ""
                        error_message = ""

                        etl_platform = ob.create('Amazon Web Services', service='glue').service()
                        perf = etl_platform.perf_cal(job_name)
                        try:
                            if perf.loc['ErrorMessage']['JobRun']:
                                error_message = perf.loc['ErrorMessage']['JobRun']
                        except:
                            error_message = "None"

                        try:
                            JobRunState = 'RUNNING'
                            while JobRunState == 'RUNNING':
                                perf = etl_platform.perf_cal(job_name)
                                JobRunState = perf.loc['JobRunState']['JobRun']
                                if int(perf.loc['ExecutionTime']['JobRun']) <= int(
                                        exp_time_taken + buffer_time):
                                    status = 'SUCCEEDED'
                                else:
                                    status = 'FAILED'

                            data = OutputPERFORM(
                                job_name=perf.loc['JobName']['JobRun'],
                                job_id=perf.loc['Id']['JobRun'],
                                expected_time_taken_in_sec=exp_time_taken,
                                expected_cpu_capacity=exp_cpu_count,
                                buffer=buffer_time,
                                actual_time_taken_in_sec=int(perf.loc['ExecutionTime']['JobRun']),
                                actual_capacity=1,
                                result=status,
                                error_details=error_message
                            )
                            data.save()
                        except Exception as e:
                            flash(e)
                    except Exception as e:
                        flash("Unable to fetch Performance details!")
                else:
                    flash("Select Pipeline to get Performance details!")
                return redirect(url_for('execution.workflow'))

            else:
                req = request.form
                list_etls = req.getlist('target-etls')
                trigger_orch = req.get('orchestration') if req.get('orchestration') else "off"
                trigger_perform = req.get('performance') if req.get('performance') else "off"
                trigger_etl = req.get('triggerETL') if req.get('triggerETL') else "off"
                val_type = req['etl-val-field-set'] if req.get('etl-val-field-set') else "off"

                if list_etls:
                    for etname in list_etls:
                        try:
                            run_id = None
                            etl_status = None
                            pipeline_name = etname.split(" ")[0]
                            pipeline_id = etname.split(" ")[1]
                            mode = etname.split(" ")[2]

                            etl = DbConfigModel(etl_name=pipeline_name, etl_run_id=run_id,
                                                etl_platform='Amazon Web Services', etl_service='Glue',
                                                username=session['user'], stage=session['stage'],
                                                environment=session['environment'],
                                                etl_status=etl_status, trigger_perform=trigger_perform,
                                                trigger_orch=trigger_orch, trigger_val=trigger_etl, val_type=val_type,
                                                time_stamp=datetime.now(), mode=mode)

                            print("TRIGGER ETL ON/OFF:", trigger_etl)
                            if trigger_etl == "on":
                                try:
                                    run_etl(etl, val_type)
                                except Exception as e:
                                    flash("Error at Trigger ETL: \"" + str(e) + "\"")
                                # try:
                                #     pass
                                #     # run_performance_testing(pipeline_name)
                                # except Exception as e:
                                #     flash("Error at Performance Testing: \"" + str(e) + "\"")
                            else:
                                try:
                                    no_run_etl(etl, pipeline_name, pipeline_id)
                                except Exception as e:
                                    flash("Error at Validation: \"" + str(e) + "\"")
                                # try:
                                #     pass
                                #     # run_performance_testing(pipeline_name)
                                # except Exception as e:
                                #     flash("Error at Performance Testing: \"" + str(e) + "\"")
                        except Exception as e:
                            flash("Error: \"" + str(e) + "\"")
                            continue
                    return redirect(url_for('execution.result'))
                else:
                    message="Select Pipeline to Validate"
        flash(message)
        return redirect(url_for('execution.workflow'))


def run_performance_testing(job_name):
    etl_platform = ob.create('Amazon Web Services', service='glue').service()
    perf = etl_platform.perf_cal(job_name)
    try:
        if perf.loc['ErrorMessage']['JobRun']:
            error_message = perf.loc['ErrorMessage']['JobRun']
    except:
        error_message = "None"

    try:
        master_data = MasterConfig.query.filter_by(application_name=job_name + " manual").with_entities(
            MasterConfig.exp_time_taken,
            MasterConfig.exp_cpu_count,
            MasterConfig.buffer_time).order_by(
            desc(MasterConfig.timestamp)).all()

        exp_time_taken, exp_cpu_count, buffer_time = master_data[0]

        JobRunState = 'RUNNING'
        while JobRunState == 'RUNNING':
            import time
            time.sleep(exp_time_taken + buffer_time)
            perf = etl_platform.perf_cal(job_name)
            JobRunState = perf.loc['JobRunState']['JobRun']
            if int(perf.loc['ExecutionTime']['JobRun']) <= exp_time_taken + buffer_time:
                status = 'SUCCEEDED'
            else:
                status = 'FAILED'

        data = OutputPERFORM(
            job_name=perf.loc['JobName']['JobRun'],
            job_id=perf.loc['Id']['JobRun'],
            expected_time_taken_in_sec=exp_time_taken,
            expected_cpu_capacity=exp_cpu_count,
            buffer=buffer_time,
            actual_time_taken_in_sec=int(perf.loc['ExecutionTime']['JobRun']),
            actual_capacity=1,
            result=status,
            error_details=error_message
        )
        data.save()
    except Exception as e:
        flash(e)


def run_etl(etl, val_type):
    """function to trigger the etl and log its status"""
    etl_platform = ob.create('Amazon Web Services', service='glue').service()
    etl.etl_run_id = etl_platform.trigger_job(etl.etl_name.split(" ")[0])
    etl.etl_status = "In Progress"
    etl.log_entry()
    flash("ETL successfully triggered!!")


def no_run_etl(etl, list_etls, pipeline_id):
    etl.etl_run_id = etl.etl_name + '_no_run_' + str(datetime.now())
    etl.etl_status = "NO RUN"
    etl.log_entry()
    payload = prep_payload(etl.etl_run_id, list_etls, pipeline_id)
    print("PayloadValue", payload[0], payload[1])
    if payload[0] == 'OK':
        print("Payload prep successful. DAG trigger start for etl:", etl.etl_run_id)
        res = run_parent_dag(payload[1], etl.etl_run_id)
        flash(res[1])


def prep_payload(etl_run_id, list_etls, pipeline_id):
    """function prepares payload for dagRuns endpoint of airflow
     for triggering the validation dag."""
    try:
        row = DbConfigModel.query.filter_by(etl_run_id=etl_run_id).with_entities(
            DbConfigModel.etl_name,
            DbConfigModel.trigger_val,
            DbConfigModel.trigger_orch,
            DbConfigModel.trigger_perform,
            DbConfigModel.val_type,
            DbConfigModel.environment,
            DbConfigModel.stage,
            DbConfigModel.mode
        ).all()
        etl_id, trigger_val, trigger_orch, trigger_perform, val_type, env, stage, mode = row[0]

        if mode == 'manual':
            if val_type == "db2db":
                data = user_connection_db2db.query.filter_by(test_environment=env).filter_by(stage=stage)
                x = data.with_entities(
                    user_connection_db2db.connection_name,
                    user_connection_db2db.platform,
                    user_connection_db2db.service,
                    user_connection_db2db.connection_details,
                    user_connection_db2db.pipeline_name,
                    user_connection_db2db.emp_id
                )

                source = x.filter_by(
                    connection_name='Db2Db Source Configuration').filter_by(pipeline_name=list_etls).order_by(
                    desc(user_connection_db2db.updated_on)).limit(1).all()
                target = x.filter_by(
                    connection_name='Db2Db Target Configuration').order_by(
                    desc(user_connection_db2db.updated_on)).limit(
                    1).all()
            elif val_type == 'f2db':
                data = user_connection_f2db.query.filter_by(test_environment=env).filter_by(stage=stage)
                x = data.with_entities(
                    user_connection_f2db.connection_name,
                    user_connection_f2db.platform,
                    user_connection_f2db.service,
                    user_connection_f2db.connection_details,
                    user_connection_f2db.pipeline_name,
                    user_connection_f2db.emp_id
                )

                source = x.filter_by(
                    connection_name='F2Db Source Configuration').filter_by(pipeline_name=list_etls).order_by(
                    desc(user_connection_f2db.updated_on)).limit(1).all()
                target = x.filter_by(
                    connection_name='F2Db Target Configuration').order_by(desc(user_connection_f2db.updated_on)).limit(
                    1).all()

            elif val_type == 'f2f':
                data = user_connection_f2f.query.filter_by(test_environment=env).filter_by(stage=stage)
                x = data.with_entities(
                    user_connection_f2f.connection_name,
                    user_connection_f2f.platform,
                    user_connection_f2f.service,
                    user_connection_f2f.connection_details,
                    user_connection_f2f.pipeline_name,
                    user_connection_f2f.emp_id
                )

                source = x.filter_by(
                    connection_name='F2F Source Configuration').filter_by(pipeline_name=list_etls).order_by(
                    desc(user_connection_f2f.updated_on)).limit(1).all()
                target = x.filter_by(
                    connection_name='F2F Target Configuration').order_by(desc(user_connection_f2f.updated_on)).limit(
                    1).all()
        else:
            pass
            # if val_type == "db2db":
            #     data = UserConnectionsManual.query.filter_by(test_environment=env).filter_by(stage=stage)
            #     x = data.with_entities(
            #         UserConnectionsManual.connection_name,
            #         UserConnectionsManual.platform,
            #         UserConnectionsManual.service,
            #         UserConnectionsManual.connection_details,
            #         UserConnectionsManual.pipeline_name,
            #         UserConnectionsManual.emp_id
            #     )
            #
            #     source = x.filter_by(
            #         connection_name='Db2Db Source Configuration').filter_by(pipeline_name=list_etls).order_by(
            #         desc(UserConnectionsManual.updated_on)).limit(1).all()
            #     target = x.filter_by(
            #         connection_name='Db2Db Target Configuration').order_by(desc(UserConnectionsManual.updated_on)).limit(
            #         1).all()
            #
            # elif val_type == "f2db":
            #     data = UserConnectionsManual.query.filter_by(test_environment=env).filter_by(stage=stage)
            #     x = data.with_entities(
            #         UserConnectionsManual.connection_name,
            #         UserConnectionsManual.platform,
            #         UserConnectionsManual.service,
            #         UserConnectionsManual.connection_details,
            #         UserConnectionsManual.pipeline_name,
            #         UserConnectionsManual.emp_id
            #     )
            #
            #     source = x.filter_by(
            #         connection_name='F2Db Source Configuration').filter_by(pipeline_name=list_etls).order_by(
            #         desc(UserConnectionsManual.updated_on)).limit(1).all()
            #     target = x.filter_by(
            #         connection_name='F2Db Target Configuration').order_by(desc(UserConnectionsManual.updated_on)).limit(
            #         1).all()
            #
            # elif val_type == "f2f":
            #     data = UserConnectionsManual.query.filter_by(test_environment=env).filter_by(stage=stage)
            #     x = data.with_entities(
            #         UserConnectionsManual.connection_name,
            #         UserConnectionsManual.platform,
            #         UserConnectionsManual.service,
            #         UserConnectionsManual.connection_details,
            #         UserConnectionsManual.pipeline_name,
            #         UserConnectionsManual.emp_id
            #     )
            #
            #     source = x.filter_by(
            #         connection_name='F2F Source Configuration').filter_by(pipeline_name=list_etls).order_by(
            #         desc(UserConnectionsManual.updated_on)).limit(1).all()
            #     target = x.filter_by(
            #         connection_name='F2F Target Configuration').order_by(desc(UserConnectionsManual.updated_on)).limit(
            #         1).all()
        data1 = UserConnections.query.filter_by(test_environment=env).filter_by(stage=stage)
        y = data1.with_entities(
            UserConnections.connection_name,
            UserConnections.platform,
            UserConnections.service,
            UserConnections.connection_details,
            UserConnections.pipeline_name,
            UserConnections.conn_id,
            UserConnections.emp_id
        )
        output = y.filter_by(
            connection_name='TestResult Storage Configuration').order_by(desc(UserConnections.updated_on)).limit(
            1).all()
        mismatch = y.filter_by(
            connection_name='Mismatch Record').order_by(desc(UserConnections.updated_on)).limit(1).all()
        metrics = y.filter_by(
            connection_name='Metrics Storage Configuration').order_by(desc(UserConnections.updated_on)).limit(
            1).all()
    except Exception as e:
        flash("Something went wrong! Unable to gather info from database: \"" + str(e) + "\"")

    try:
        source_details = {
            'platform': source[0][1].lower(),
            'name': source[0][2].lower(),
            'connection_details': source[0][3].get('connection_details'),
            'additional_details': source[0][3].get('additional_details')
        }
    except Exception as e:
        flash("source details not configured: \"" + str(e) + "\"")

    try:
        target_details = {
            'platform': target[0][1].lower(),
            'name': target[0][2].lower(),
            'connection_details': target[0][3].get('connection_details'),
            'additional_details': target[0][3].get('additional_details')
        }
    except Exception as e:
        flash("target details not configured: \"" + str(e) + "\"")

    try:
        output_details = {
            'platform': output[0][1].lower(),
            'name': output[0][2].lower(),
            'connection_details': output[0][3].get('connection_details'),
            'additional_details': {key: output[0][3].get('additional_details')[key].get(val_type) for key in
                                   output[0][3].get('additional_details')}
        }
    except Exception as e:
        flash("output details not configured: \"" + str(e) + "\"")

    try:
        mismatch_details = {
            'platform': mismatch[0][1].lower(),
            'name': mismatch[0][2].lower(),
            'connection_details': mismatch[0][3].get('connection_details'),
            'additional_details': mismatch[0][3].get('additional_details')
        }
    except Exception as e:
        flash("mismatch details not configured: \"" + str(e) + "\"")

    try:
        metrics_details = {
            'platform': metrics[0][1].lower(),
            'name': metrics[0][2].lower(),
            'connection_details': metrics[0][3].get('connection_details'),
            'additional_details': metrics[0][3].get('additional_details')
        }
    except Exception as e:
        flash("metrics details not configured: \"" + str(e) + "\"")

    try:
        test_script_path = MasterConfig.query.filter_by(
            environment=env,
            stage=stage,
            application_name=etl_id
        ).order_by(desc(MasterConfig.timestamp)).with_entities(MasterConfig.test_script_path).all()[0][0]
    except Exception as e:
        flash("Unable to fetch Testscript path: \"" + str(e) + "\"")

    try:
        query_res = BucketConfig.query.with_entities(
            BucketConfig.data_needed,
            BucketConfig.bucket_rule
        ).all()
        data_needed = {row[0]: [] for row in query_res}
        for row in query_res:
            data_needed[row[0]].append(row[1])

        query_res = BucketConfig.query.with_entities(
            BucketConfig.bucket_rule,
            BucketConfig.test_case
        ).all()
        validation_buckets = {row[0]: [] for row in query_res}
        for row in query_res:
            validation_buckets[row[0]].append(row[1])
    except Exception as e:
        flash("Unable to fetch Bucket Testcases: \"" + str(e) + "\"")

    try:
        resource_key = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name='TestDoc Storage Configuration').join(
            Services, UserConnections.service == Services.service_name).order_by(
            desc(UserConnections.updated_on)
        ).limit(1).with_entities(Services.resource_key).all()[0][0]
    except Exception as e:
        flash("Unable to fetch Resource Key: \"" + str(e) + "\"")

    pipeline_name = None
    conn_id = None
    source_name = None

    # incorporating all query results in the payload
    data = {
        "dag_run_id": sp(val_type=val_type) + ''.join(str(datetime.now()).split()),
        "conf": {
            "environment": session['environment'],
            "stage": session['stage'],
            "pipeline_id": pipeline_id,
            "etl": etl_id,
            "etl_run_id": etl_run_id,
            "conn_id": conn_id,
            "pipeline_name": pipeline_name,
            "source_name": source_name,
            "resource_key": resource_key,
            "test_script_path": test_script_path,
            "val_type": val_type,
            # "val_type": "db2db1" if 'pg_to_rs' in pipeline_name else 'db2db2',
            "trigger_val": trigger_val,
            "trigger_perform": trigger_perform,
            "trigger_orch": trigger_orch,
            "conf": {
                "source_details": source_details,
                "target_details": target_details,
                "output_details": output_details,
                "mismatch_details": mismatch_details,
                "metrics_details": metrics_details
            },
            "bucketconf": {
                "data_needed": data_needed,
                "validation_buckets": validation_buckets
            }
        }
    }
    response = 'OK'
    return response, data


def run_parent_dag(data, etl_run_id):
    print("  ___________request handled_________________  ")
    # conn = AirflowConn()
    air_client = ob.create('airflowapiclient')
    dag = ob.create('dags', val_type=data['conf']['val_type']).dag
    try:
        print("1. preparing for dag_run")
        res = air_client.trigger(dag_id=dag, data=json.dumps(data))
        if res.status_code == 200:
            res = json.loads(res.content)
            val_log(etl_run_id, res['dag_id'], res['dag_run_id'])
        else:
            return res.status_code, json.dumps(res.content.decode('utf-8'))
    except Exception as e:
        print("trigger dag failed", str(e))
        return 401, "Bad request"
    return 200, dag + " dag triggered!"


def val_log(etl_run_id, dag_id, dag_run_id):
    """logs into the validation_log table"""
    # conn = AirflowConn()
    air_client = ob.create('airflowapiclient')
    row = DbConfigModel.query.filter_by(etl_run_id=etl_run_id).with_entities(
        DbConfigModel.environment,
        DbConfigModel.stage,
        DbConfigModel.username
    ).all()
    env, stage, user = row[0]

    retry = 3
    while retry != 0:
        retry -= 1
        res = air_client.dag_task_status(dag_id=dag_id, dag_run_id=dag_run_id)
        if res[0].status_code != 404:
            break
        else:
            continue
    try:
        validation_task_id = json.loads(res[0].content)['task_id']
        validation_status = json.loads(res[0].content)['state']
    except:
        validation_task_id = res[0].status_code
        validation_status = 'UNAVAILABLE'

    log_entry = ValidationLog(
        emp_id=user,
        test_environment=env,
        stage=stage,
        etl_run_id=etl_run_id,
        dag_id=dag_id,
        dag_run_id=dag_run_id,
        orchestration_task_id='NA' + str(datetime.now()),
        orchestration_status='NA',
        performance_task_id='NA' + str(datetime.now()),
        performance_status='NA',
        validation_task_id=validation_task_id,
        validation_status="Failed",
        # validation_status=validation_status
    )
    db = dbf_obj.get_dbase()
    db.session.add(log_entry)
    db.session.commit()


@validate_request
def execute_overview():
    form = Overview()
    return render_template('execution/overview.html', data=form)


def accelerator():
    return render_template('accelerators/overview.html')


# -----------------------------------Avinash's code---------------------------------------------
@validate_request
def test_script_gen():
    m_form = ManualTestForm()
    a_form = AutoTestForm()
    g_form = GenerateForm()
    if m_form.indentifier.data == "m_form" and m_form.validate_on_submit():
        per_filename = secure_filename(m_form.t_file.data.filename)
        # 1st: file's content. 2nd: naming the file in s3. 3rd: actual filename. 4th: folder where file's to be stored
        filetransfer(m_form.t_file.data, "manual_test_script", per_filename, "Manual Test Script")
        flash(f"File manual_test_script Uploaded Successfully")
        return redirect(url_for('execution.test_script_gen'))
    elif m_form.indentifier.data == "a_form" and a_form.validate_on_submit():
        per_filename = secure_filename(m_form.t_file.data.filename)
        filetransfer(m_form.t_file.data, "automated_test_script", per_filename, "Automated Test Script")
        flash(f"File automated_test_script Uploaded Successfully")
        return redirect(url_for('execution.test_script_gen'))
    elif m_form.indentifier.data == "g_form" and g_form.validate_on_submit():
        qdata = TestLog.query.filter_by(stage=session['stage']).filter_by(environment=session['environment']).filter_by(
            document_name=session['environment'] + "/" + session[
                'stage'] + "/Configuration File/configuration_file.json").order_by(desc('time_stamp')).first()
        if qdata:
            location = UserConnections.query.filter_by(stage=session['stage']).filter_by(
                test_environment=session['environment']).filter_by(
                connection_name="TestDoc Storage Configuration").order_by(desc('updated_on')).first()
            if location:
                if location.service == "Simple Storage Service":
                    resource_key = "s3"
                dag_data = {
                    "dag_run_id": "Test-Script-Gen" + ''.join(str(datetime.now()).split()),
                    "conf": {
                        "resource_key": resource_key,
                        "config_path": qdata.document_path
                    }
                }
                air_client = ob.create('airflowapiclient')
                try:
                    res = air_client.trigger(dag_id="Test-Script-Gen", data=json.dumps(dag_data))
                    res = json.loads(res.content)
                    status = "running"
                    while status != "completed":
                        respo = air_client.dag_task_status(dag_id=res['dag_id'], dag_run_id=res['dag_run_id'])
                        print("dag task status", respo)
                        if json.loads(respo[0].content)['state'] == "success":
                            status = "completed"
                            flash("DAG ran successfully")
                        elif json.loads(respo[0].content)['state'] == "failed":
                            status = "completed"
                            flash("DAG run failed")
                except Exception as e:
                    print("trigger dag failed", str(e))
            else:
                flash(" please provide the test script location")
        else:
            flash(" please provide config file in test doc page")
    data = TestLog.query.filter_by(stage=session['stage']).filter_by(environment=session['environment']).filter_by(
        document_type="Manual Test Script").all()
    cdata = TestLog.query.filter_by(stage=session['stage']).filter_by(environment=session['environment']).filter_by(
        document_type="Automated Test Script").all()
    qdata = TestLog.query.filter_by(stage=session['stage']).filter_by(environment=session['environment']).filter_by(
        document_name=session['environment'] + "/" + session[
            'stage'] + "/Configuration File/configuration_file.json").order_by(desc('time_stamp')).first()
    location = UserConnections.query.filter_by(stage=session['stage']).filter_by(
        test_environment=session['environment']).filter_by(connection_name="TestDoc Storage Configuration").order_by(
        desc('updated_on')).first()

    ldata = [[]]

    if qdata:
        if location:
            resource_key = \
                Services.query.filter_by(service_name=location.service).with_entities(Services.resource_key).first()[0]
            ldata = generated_script_links(platform=location.platform, config=qdata.document_path, loc=resource_key)
        else:
            flash(" please provide the test script location")
    else:
        flash(" please provide config file in test doc page, only if you want to use auto script gen")
    return render_template('accelerators/test-script-generator.html', m_form=m_form, g_form=g_form, a_form=a_form,
                           data=data, cdata=cdata, ldata=ldata[1:])


def generated_script_links(platform, config, loc):
    buck = config.split('/', 3)
    service = ob.create(platform, service=loc).service()
    # fo= signed_object(loc)
    return service.gen_links(bucke=buck[2], key=buck[3])


def filetransfer(u_file, mes, per_filename, d_type):
    ext = per_filename.split(".")[-1]
    key = session['environment'] + "/" + session['stage'] + "/" + mes + "/" + per_filename
    data = UserConnections.query.filter_by(stage=session['stage']).filter_by(
        test_environment=session['environment']).filter_by(connection_name="TestDoc Storage Configuration").order_by(
        desc('updated_on')).first()
    service = Services.query.filter_by(service_name=data.service).with_entities(Services.resource_key).first()[0]
    # test code
    store = ob.create(data.platform, service=service).service()
    buck = data.connection_details
    bucke = buck.get('connection_details')['bucket']
    res = store.upload(u_file=u_file, mes=mes, per_filename=per_filename, bucke=bucke)
    db = dbf_obj.get_dbase()
    addtest = TestLog(username=session['user'], environment=session['environment'], stage=session['stage'],
                      time_stamp=datetime.now(), document_type=d_type, document_link=res, document_name=key,
                      document_path='s3://' + bucke + '/' + key)
    db.session.add(addtest)
    db.session.commit()


@validate_request
def result():
    res = []
    metric_data =[]
    logs=[]
    graph1JSON_perf = []
    graph2JSON_perf = []
    all_performance_data = []
    data2 = []
    datal = []
    datal2 = []
    etl_data = []
    try:
        etl_data = DbConfigModel.query.filter_by(
            stage=session['stage'],
            environment=session['environment'],
        ).where(DbConfigModel.etl_status.notin_(["SUCCEEDED", "FAILED", "NO RUN"])).all()
        datal = DbConfigModel.query.filter_by(stage=session['stage']).filter_by(
            environment=session['environment']).filter_by(etl_status="SUCCEEDED").order_by(desc('time_stamp')).limit(
            1).all()
        val_type = DbConfigModel.query.filter_by(
            stage=session['stage'],
            environment=session['environment'],
            username=session['user']
        ).order_by(desc(DbConfigModel.time_stamp)).with_entities(DbConfigModel.val_type).all()[0][0]
    except Exception as e:
        flash(" ETL/pipeline details not found!: \"" + str(e) + "\"")

    try:
        data2 = ValidationLog.query.filter_by(
            stage=session['stage'],
            test_environment=session['environment'],
            emp_id=session['user']
        ).where(ValidationLog.validation_status.notin_(["success", "failed", "UNAVAILABLE"])).all()
        datal2 = ValidationLog.query.filter_by(
            stage=session['stage'],
            test_environment=session['environment'],
            emp_id=session['user']).order_by(desc('start_time')).limit(1).all()
    except Exception as e:
        flash(" Validation details not found!: \"" + str(e) + "\"")

    # getting live logs from airflow
    try:
        pass
        # logs_from_validation_log_table = ValidationLog.query.filter_by(
        #     stage=session['stage'],
        #     test_environment=session['environment'],
        #     emp_id=session['user']).order_by(desc('end_time')).limit(1).with_entities(
        #     ValidationLog.dag_id, ValidationLog.dag_run_id, ValidationLog.validation_task_id).all()
        #
        # dag_id = logs_from_validation_log_table[0][0]
        # dag_run_id = logs_from_validation_log_table[0][1]
        # task_id = logs_from_validation_log_table[0][2]
        # logs = get_airflow_logs(dag_id, dag_run_id, task_id)
        # logs = str(logs.content)
    except Exception as e:
        flash("Unable to fetch Airflow logs: \"" + str(e) + "\"")

    # Getting performance data
    try:
        all_performance_data = OutputPERFORM.query.with_entities(OutputPERFORM.id,
                                                                 OutputPERFORM.job_name,
                                                                 OutputPERFORM.job_id,
                                                                 OutputPERFORM.expected_time_taken_in_sec,
                                                                 OutputPERFORM.expected_cpu_capacity,
                                                                 OutputPERFORM.buffer,
                                                                 OutputPERFORM.actual_time_taken_in_sec,
                                                                 OutputPERFORM.actual_capacity,
                                                                 OutputPERFORM.result,
                                                                 OutputPERFORM.error_details).all()
        df = pd.DataFrame(all_performance_data)
        job_name = df['job_name']
        # Bar chart
        fig_bar = go.Figure(data=[
            go.Bar(name='Exp. time(in secs)', x=job_name, y=df['expected_time_taken_in_sec']),
            go.Bar(name='Actual time(in secs)', x=job_name, y=df['actual_time_taken_in_sec'])
        ])
        fig_bar.update_layout(barmode='group', autosize=False, width=400, height=400)
        graph1JSON_perf = json.dumps(fig_bar, cls=plotly.utils.PlotlyJSONEncoder)

        # Pie chart
        labels = ['Expected CPU Usage', 'Actual CPU Usage']
        values = []
        for items in df['expected_cpu_capacity']:
            values.append(int(items))
        for items in df['actual_capacity']:
            values.append(int(items))
        fig_pie = go.Figure(data=[go.Pie(labels=labels, values=values, hole=.3)])
        fig_pie.update_layout(autosize=False, width=400, height=400)
        graph2JSON_perf = json.dumps(fig_pie, cls=plotly.utils.PlotlyJSONEncoder)
    except Exception as e:
        flash("Unable to fetch Performance details.", e)

    try:
        pass
        # res = query_output(val_type)
    except OperationalError as e:
        flash("Trouble in connecting to Database. "
              "Either Database server is unreachable or you don't have permission to view results")
    except IndexError as e:
        flash("Proper Test Result Storage Configuration not provided")
        return redirect(url_for('configuration.add_app_configuration'))
    except AttributeError as e:
        flash("Proper Test Result Storage Configuration not provided. Missing connection details or table name")
        return redirect(url_for('configuration.add_app_configuration'))
    except ProgrammingError as e:
        table_name = str(e).split()[2]
        res = []
        flash(e)
        flash("Couldn't find a table by the name " + table_name + ". \
            Ensure this is the correct table name. \
            If so, wait till the table is created and reload the page.\
            The table will be created in a few minutes")
    except Exception as e:
        res = []
        # flash(str(e))
        flash('Oops, something went wrong!', e)

    try:
        pass
        # env = session['environment']
        # stage = session['stage']
        # data = UserConnections.query.filter_by(
        #     test_environment=env,
        #     stage=stage,
        #     connection_name=testresstorage
        # ).with_entities(
        #     UserConnections.connection_details
        # ).order_by(desc(UserConnections.updated_on)).limit(1).all()[0][0]
        # connection_det = data.get('connection_details')
        # table_names = [data.get('additional_details').get('table name')]
        # from sqlalchemy import create_engine
        # engine = create_engine(
        #     'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}'.format_map(connection_det))
        # con = engine.connect()
        # results = {}
        # for table_name in table_names:
        #     result = con.execute('SELECT  * from ' + table_name).fetchall()
        #     res = [MetricDataDB2DB(*row) for row in result]
        #     results[table_name] = res
        # metric_data = results
    except:
        flash("Trouble in connecting to Database. "
              "Either Database server is unreachable or you don't have permission to view metric results")

    if request.args:
        return result_process_args(res)
    return render_template("dashboard/results.html",
                           output=res,
                           metric_data=metric_data,
                           data2=data2,
                           datal=datal,
                           datal2=datal2,
                           data=etl_data,
                           logs=logs,
                           graph1JSON_perf=graph1JSON_perf,
                           graph2JSON_perf=graph2JSON_perf,
                           all_performance_data=all_performance_data
                           )


def result_process_args(res):
    val = request.args.get('val')
    failed_counter = 0
    success_counter = 0
    overall_status = ''
    for log1 in res:
        for log2 in res[log1]:
            if val == log2.validation_run_id:
                if log2.res.lower() == 'failed':
                    failed_counter += 1
                else:
                    success_counter += 1
    if failed_counter > success_counter:
        overall_status += 'Failed'
    else:
        overall_status += 'Success'
    return json.dumps(overall_status)


def get_airflow_logs(dag_id, dag_run_id, validation_task_id):
    air_client = ob.create('airflowapiclient')
    res = air_client.get_Log(dag_id, dag_run_id, validation_task_id)
    return res


def query_output(val_type):
    env = session['environment']
    stage = session['stage']
    print("val_type, env, stage", val_type, env, stage)
    if val_type == 'db2db' or val_type.split(" ")[0] == 'db2db':
        data = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name=testresstorage
        ).with_entities(
            UserConnections.connection_details
        ).order_by(desc(UserConnections.updated_on)).limit(1).all()[0][0]
        connection_det = data.get('connection_details')
        table_names = [data.get('additional_details').get('table name').get('db2db')]

        from sqlalchemy import create_engine, MetaData, Table, select, and_
        engine = create_engine(
            'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}'.format_map(connection_det))
        con = engine.connect()
        results = {}

        for table_name in table_names:
            result = con.execute('SELECT "pipeline_id", "App_ETL_Name", "test_name", \
                                    "column_name", "column_type", "expected_results", "Result", \
                                    "Source_Count", "Target_Count", "source_mismatch_table", "target_mismatch_table", \
                                    "Source_Mismatch_count", "Target_Mismatch_Count", "error_details", \
                                    "source_query", "target_query", "Test_Case_Execution_Start_Time",\
                                    "Test_Case_Execution_End_Time","Insertion_Date", "Insertion_TimeStamp", "validation_run_id" \
                                    from ' + table_name + ' order by \
                                    "Insertion_TimeStamp" desc,"test_name"  limit 100;').fetchall()
            # result = con.execute('SELECT  * from '+table_name).fetchall()
            res = [Output(*row) for row in result]
            results[table_name] = res

    elif val_type == 'f2db' or val_type.split(" ")[0] == 'f2db':
        data = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name=testresstorage
        ).with_entities(
            UserConnections.connection_details
        ).order_by(desc(UserConnections.updated_on)).limit(1).all()[0][0]
        connection_det = data.get('connection_details')
        table_names = [data.get('additional_details').get('table name').get('f2db')]
        print("table_names", table_names)

        from sqlalchemy import create_engine, MetaData, Table, select, and_
        engine = create_engine(
            'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}'.format_map(connection_det))
        con = engine.connect()
        results = {}

        for table_name in table_names:
            result = con.execute('SELECT  * from ' + table_name).fetchall()
            res = [OutputF2DB(*row) for row in result]
            results[table_name] = res

    elif val_type == 'sfdc2db' or val_type.split(" ")[0] == 'sfdc2db':
        data = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name=testresstorage
        ).with_entities(
            UserConnections.connection_details
        ).order_by(desc(UserConnections.updated_on)).limit(1).all()[0][0]
        connection_det = data.get('connection_details')
        table_names = [data.get('additional_details').get('table name').get('sfdc2db')]

        from sqlalchemy import create_engine, MetaData, Table, select, and_
        engine = create_engine(
            'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}'.format_map(connection_det))
        con = engine.connect()
        results = {}

        for table_name in table_names:
            result = con.execute('SELECT  * from ' + table_name).fetchall()
            res = [OutputSFDC2DB(*row) for row in result]
            results[table_name] = res

    return results


@validate_request
def test_data_gen():
    g_form = GenerateDataForm()
    if g_form.indentifier.data == "g_form":
        db_data = {}
        if g_form.storage_platform.data == 'cloud':
            storage_platform = "cloud"
            resource_key = "s3"
        elif g_form.storage_platform.data == 'on-premises':
            storage_platform = "on-premises"

        if g_form.output_format.data == 'db':
            db_data = {
                "host": g_form.Host.data,
                "port": g_form.Port.data,
                "dbname": g_form.DbName.data,
                "service": g_form.service_name.data,
                "tablename": g_form.TableName.data,
                "username": g_form.UserName.data,
                "password": g_form.Password.data
            }
        dag_data = {"dag_run_id": "Data-Gen" + ''.join(str(datetime.now()).split()),
                    "conf": {
                        "config_details": {
                            "schema_file_path": g_form.schema_path.data,
                            "total_record_count": g_form.total_records.data,
                            "resource_key": resource_key,
                            "storage_platform": storage_platform,
                            "duplicate_record_count": g_form.duplicate_Records.data,
                            "country": g_form.country.data,
                            "out_path": g_form.output_path.data,
                            "output_format": g_form.output_format.data,
                            "db_config_details": db_data,
                            "metrics_config_details": {
                                "host": g_form.M_Host.data,
                                "port": g_form.M_Port.data,
                                "dbname": g_form.M_DbName.data,
                                "service": g_form.M_service_name.data,
                                "tablename": g_form.M_TableName.data,
                                "username": g_form.M_UserName.data,
                                "password": g_form.M_Password.data
                            }
                        }}}
        print(dag_data)
        location = UserConnections.query.filter_by(stage=session['stage']).filter_by(
            test_environment=session['environment']).filter_by(
            connection_name="TestDoc Storage Configuration").order_by(desc('updated_on')).first()
        if location:
            adduser = UserConnections(emp_id=session['user'], test_environment=session['environment'],
                                      stage=session['stage'], platform=location.platform, service=location.service,
                                      connection_name="TestData Configuration", connection_details=dag_data,
                                      created_on=datetime.now(), updated_on=datetime.now())
            db = dbf_obj.get_dbase()
            db.session.add(adduser)
            db.session.commit()
            air_client = ob.create('airflowapiclient')
            try:
                res = air_client.trigger(dag_id="Synthetic-Data-Gen", data=json.dumps(dag_data))
                res = json.loads(res.content)
                status = "running"
                while status != "completed":
                    respo = air_client.dag_task_status(dag_id=res['dag_id'], dag_run_id=res['dag_run_id'])
                    print("dag task status", respo)
                    if json.loads(respo[0].content)['state'] == "success":
                        status = "completed"
                        flash("DAG ran successfully")
                    elif json.loads(respo[0].content)['state'] == "failed":
                        status = "completed"
                        flash("DAG run failed")
                return redirect(url_for('execution.test_data_gen'))
            except Exception as e:
                print("trigger dag failed", str(e))
    qdata = TestLog.query.filter_by(stage=session['stage']).filter_by(environment=session['environment']).filter_by(
        document_name=session['environment'] + "/" + session[
            'stage'] + "/Synthetic Data Configuration File/synthetic_data_configuration_file.json").order_by(
        desc('time_stamp')).first()
    tlist = []
    if qdata:
        location = UserConnections.query.filter_by(stage=session['stage']).filter_by(
            test_environment=session['environment']).filter_by(
            connection_name="TestDoc Storage Configuration").order_by(desc('updated_on')).first()
        if location:
            buck = ""
            resource_key = \
                Services.query.filter_by(service_name=location.service).with_entities(Services.resource_key).first()[0]
            if location.service == "Simple Storage Service":
                buck = str(qdata.document_path).split('/', 3)
                s3 = ob.create(location.platform, service=resource_key).service().client
                try:
                    resp = s3.list_objects(Bucket=buck[2], Prefix=session['environment'] + "/" + session[
                        'stage'] + "/Synthetic Data Configuration File/")
                    for l in resp['Contents']:
                        k = ""
                        if location.service == "Simple Storage Service":
                            k = "s3://" + str(buck[2]) + "/" + str(l['Key'])
                        tlist.append(k)
                    print(tlist)
                except Exception as e:
                    flash(e)
        else:
            flash(" please provide the test script location")
    else:
        flash(" please provide config file in test doc page")
    qdata = TestLog.query.filter_by(stage=session['stage']).filter_by(environment=session['environment']).filter_by(
        document_name=session['environment'] + "/" + session[
            'stage'] + "/Synthetic Data Configuration File/synthetic_data_configuration_file.json").order_by(
        desc('time_stamp')).first()
    location = UserConnections.query.filter_by(stage=session['stage']).filter_by(
        test_environment=session['environment']).filter_by(connection_name="TestDoc Storage Configuration").order_by(
        desc('updated_on')).first()
    ldata = [[]]
    if qdata:
        if location:
            if location.service == "Simple Storage Service":
                resource_key = "s3"
                ldata = generated_script_links(location.platform, config=qdata.document_path, loc=resource_key)
        else:
            flash(" please provide the test script location")
    else:
        flash(" please provide config file in test doc page, only if you want to use auto data gen")
    ldata = [[]]
    check = 0
    location = UserConnections.query.filter_by(stage=session['stage']).filter_by(
        test_environment=session['environment']).filter_by(connection_name="TestData Configuration").order_by(
        desc('updated_on')).first()
    if location:
        buck = ""
        if location.service == "Simple Storage Service":
            try:
                confi = location.connection_details
                buck = str(confi['conf']['config_details']['out_path']).split('/', 3)
                print(buck)
                if len(buck) <= 3:
                    resp = s3.list_objects(Bucket=buck[2])
                else:
                    resp = s3.list_objects(Bucket=buck[2], Prefix=buck[3])
                for l in resp['Contents']:
                    tklist = []
                    res = s3.generate_presigned_url('get_object', Params={'Bucket': buck[2], 'Key': l['Key']})
                    tklist.append(l['Key'])
                    tklist.append(l['LastModified'])
                    tklist.append(res)
                    ldata.append(tklist)
                print(ldata)
            except Exception as e:
                check = 1
                print(e)
    else:
        check = 1
    slist = []
    for i in tlist:
        a = (i, i)
        slist.append(a)
    g_form.schema_path.choices = slist
    return render_template('accelerators/test-data-generator.html', g_form=g_form, ldata=ldata, tlist=tlist,
                           check=check)


# SFDC
def no_run_etl_SFDC(etl, list_etls, pipeline_id):
    etl.etl_run_id = etl.etl_name + '_no_run_' + str(datetime.now())
    etl.etl_status = "NO RUN"
    etl.log_entry()
    payload = prep_payload_SFDC(etl.etl_run_id, list_etls, pipeline_id)
    print("PayloadValue", payload[0], payload[1])
    if payload[0] == 'OK':
        print("Payload prep successful. DAG trigger start for etl:", etl.etl_run_id)
        res = run_parent_dag(payload[1], etl.etl_run_id)
        flash(res[1])


def prep_payload_SFDC(etl_run_id, list_etls, pipeline_id):
    """function prepares payload for dagRuns endpoint of airflow
     for triggering the validation dag."""
    row = DbConfigModel.query.filter_by(etl_run_id=etl_run_id).with_entities(
        DbConfigModel.etl_name,
        DbConfigModel.trigger_val,
        DbConfigModel.trigger_orch,
        DbConfigModel.trigger_perform,
        DbConfigModel.val_type,
        DbConfigModel.environment,
        DbConfigModel.stage
    ).all()
    etl_id, trigger_val, trigger_orch, trigger_perform, val_type, env, stage = row[0]
    pipeline_name = None
    conn_id = None
    source_name = None
    if val_type == "sfdc2db":
        etl_id = etl_id.split()[0]
        data = UserConnectionSFDC2DB.query.filter_by(test_environment=env).filter_by(stage=stage)
        x = data.with_entities(
            UserConnectionSFDC2DB.connection_name,
            UserConnectionSFDC2DB.platform,
            UserConnectionSFDC2DB.service,
            UserConnectionSFDC2DB.connection_details,
            UserConnectionSFDC2DB.pipeline_name,
            UserConnectionSFDC2DB.conn_id,
            UserConnectionSFDC2DB.emp_id
        )
        data1 = UserConnections.query.filter_by(test_environment=env).filter_by(stage=stage)
        y = data1.with_entities(
            UserConnections.connection_name,
            UserConnections.platform,
            UserConnections.service,
            UserConnections.connection_details,
            UserConnections.pipeline_name,
            UserConnections.conn_id,
            UserConnections.emp_id
        )

        source = x.filter_by(
            connection_name='SFDC2Db Source Configuration').filter_by(pipeline_name=list_etls).order_by(
            desc(UserConnectionSFDC2DB.updated_on)).limit(1).all()
        target = x.filter_by(
            connection_name='SFDC2Db Target Configuration').order_by(desc(UserConnectionSFDC2DB.updated_on)).limit(
            1).all()
        output = y.filter_by(
            connection_name='TestResult Storage Configuration').order_by(desc(UserConnections.updated_on)).limit(
            1).all()
        mismatch = y.filter_by(
            connection_name='Mismatch Record').order_by(desc(UserConnections.updated_on)).limit(1).all()
        metrics = y.filter_by(
            connection_name='Metrics Storage Configuration').order_by(desc(UserConnections.updated_on)).limit(1).all()

    elif val_type.split(" ")[1] == 'manual':
        if val_type.split(" ")[0] == "sfdc2db":
            data = UserConnectionsManual.query.filter_by(test_environment=env).filter_by(stage=stage)
            x = data.with_entities(
                UserConnectionsManual.connection_name,
                UserConnectionsManual.platform,
                UserConnectionsManual.service,
                UserConnectionsManual.connection_details,
                UserConnectionsManual.pipeline_name,
                UserConnectionsManual.emp_id
            )
            data1 = UserConnections.query.filter_by(test_environment=env).filter_by(stage=stage)
            y = data1.with_entities(
                UserConnections.connection_name,
                UserConnections.platform,
                UserConnections.service,
                UserConnections.connection_details,
                UserConnections.pipeline_name,
                UserConnections.conn_id,
                UserConnections.emp_id
            )
            source = x.filter_by(
                connection_name='SFDC2Db Source Configuration').filter_by(pipeline_name=list_etls).order_by(
                desc(UserConnectionsManual.updated_on)).limit(1).all()
            target = x.filter_by(connection_name='SFDC2Db Target Configuration').order_by(
                desc(UserConnectionsManual.updated_on)).limit(1).all()
            output = y.filter_by(connection_name='TestResult Storage Configuration').order_by(
                desc(UserConnections.updated_on)).limit(1).all()
            mismatch = y.filter_by(
                connection_name='Mismatch Record').order_by(desc(UserConnections.updated_on)).limit(1).all()
            metrics = y.filter_by(
                connection_name='Metrics Storage Configuration').order_by(desc(UserConnections.updated_on)).limit(
                1).all()

        source_details = {
            'platform': source[0][1].lower(),
            'name': source[0][2].lower(),
            'connection_details': source[0][3].get('connection_details'),
            'additional_details': source[0][3].get('additional_details')
        }
        pipeline_id = pipeline_id
        pipeline_name = source[0][4]
        emp_id = source[0][5]

        var = etl_id.split(" ")
        etl_id = var[0] + " " + var[1]

    try:
        target_details = {
            'platform': target[0][1].lower(),
            'name': target[0][2].lower(),
            'connection_details': target[0][3].get('connection_details'),
            'additional_details': target[0][3].get('additional_details')
        }
    except Exception as e:
        response = (2, "target details not configured for test_environment " + env + " and stage " + stage)
        return response, None
    try:
        output_details = {
            'platform': output[0][1].lower(),
            'name': output[0][2].lower(),
            'connection_details': output[0][3].get('connection_details'),
            'additional_details': {key: output[0][3].get('additional_details')[key].get("sfdc2db") for key in
                                   output[0][3].get('additional_details')}
        }
    except Exception as e:
        response = (3, "output details not configured for test_environment " + env + " and stage " + stage)
        return response, None

    try:
        mismatch_details = {
            'platform': mismatch[0][1].lower(),
            'name': mismatch[0][2].lower(),
            'connection_details': mismatch[0][3].get('connection_details'),
            'additional_details': mismatch[0][3].get('additional_details')
        }
    except Exception as e:
        response = (4, "mismatch details not configured for test_environment " + env + " and stage " + stage)
        return response, None

    try:
        metrics_details = {
            'platform': metrics[0][1].lower(),
            'name': metrics[0][2].lower(),
            'connection_details': metrics[0][3].get('connection_details'),
            'additional_details': metrics[0][3].get('additional_details')
        }
    except Exception as e:
        response = (1, "metrics details not configured for test_environment " + env + " and stage " + stage)
        return response, None

    print("querying the master_config table to get the test_script path for the etl in list_etl")
    test_script_path = MasterConfig.query.filter_by(
        environment=env,
        stage=stage,
        application_name=etl_id
    ).order_by(desc(MasterConfig.timestamp)).with_entities(MasterConfig.test_script_path).all()[0][0]

    # querying the bucket_config table to create the bucket config json.
    query_res = BucketConfig.query.with_entities(
        BucketConfig.data_needed,
        BucketConfig.bucket_rule
    ).all()

    # jsonifying the query results
    data_needed = {row[0]: [] for row in query_res}
    for row in query_res:
        data_needed[row[0]].append(row[1])

    query_res = BucketConfig.query.with_entities(
        BucketConfig.bucket_rule,
        BucketConfig.test_case
    ).all()

    # jsonifying the query results
    validation_buckets = {row[0]: [] for row in query_res}
    for row in query_res:
        validation_buckets[row[0]].append(row[1])

    # fetching resource key
    if val_type == 'sfdc2db':
        resource_key = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name='TestDoc Storage Configuration').join(
            Services, UserConnections.service == Services.service_name).order_by(
            desc(UserConnections.updated_on)
        ).limit(1).with_entities(Services.resource_key).all()[0][0]
        try:
            source_details = {
                'platform': source[0][1].lower(),
                'name': source[0][2].lower(),
                'connection_details': source[0][3].get('connection_details'),
                'additional_details': source[0][3].get('additional_details')
            }
            pipeline_id = pipeline_id
            pipeline_name = source[0][4]
            conn_id = source[0][5]
            emp_id = source[0][6]

            source_name = ApiSFDC2DB.query.where(
                ApiSFDC2DB.pipeline_name == pipeline_name).with_entities(
                ApiSFDC2DB.source_system).all()[0][0]

        except Exception as e:
            response = (1, "source details not configured for test_environment " + env + " and stage " + stage)
            return response, None

    elif val_type.split(" ")[1] == 'manual':
        if val_type.split(" ")[0] == "sfdc2db":
            resource_key = UserConnections.query.filter_by(
                test_environment=env,
                stage=stage,
                connection_name='TestDoc Storage Configuration').join(
                Services, UserConnections.service == Services.service_name).order_by(
                desc(UserConnections.updated_on)
            ).limit(1).with_entities(Services.resource_key).all()[0][0]
            val_type = 'sfdc2db'
            source_name = ApiSFDC2DB.query.where(
                ApiSFDC2DB.pipeline_name == pipeline_name).with_entities(
                ApiSFDC2DB.source_system).all()[0][0]

    # incorporating all query results in the payload
    data = {
        "dag_run_id": sp(val_type=val_type) + ''.join(str(datetime.now()).split()),
        "conf": {
            "environment": session['environment'],
            "stage": session['stage'],
            "pipeline_id": pipeline_id,
            "etl": etl_id,
            "etl_run_id": etl_run_id,
            "emp_id": emp_id,
            "conn_id": conn_id,
            "pipeline_name": pipeline_name,
            "source_name": source_name,
            "resource_key": resource_key,
            "test_script_path": test_script_path,
            "val_type": val_type,
            "trigger_val": trigger_val,
            "trigger_perform": trigger_perform,
            "trigger_orch": trigger_orch,
            "conf": {
                "source_details": source_details,
                "target_details": target_details,
                "output_details": output_details,
                "metrics_details": metrics_details,
                "mismatch_details": mismatch_details
            },
            "bucketconf": {
                "data_needed": data_needed,
                "validation_buckets": validation_buckets
            }
        }
    }
    response = 'OK'
    return response, data


@validate_request
def dashboard():
    graph1JSON_db2db = None
    graph2JSON_db2db = None
    graph1JSON_f2db = None
    graph2JSON_f2db = None
    graph1JSON_sfdc2db = None
    graph2JSON_sfdc2db = None
    env = session['environment']
    stage = session['stage']

    try:
        # DB2DB
        data = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name=testresstorage
        ).with_entities(
            UserConnections.connection_details
        ).order_by(desc(UserConnections.updated_on)).limit(1).all()[0][0]
        connection_det = data.get('connection_details')
        table_names = [data.get('additional_details').get('table name').get('db2db')]

        from sqlalchemy import create_engine, MetaData, Table, select, and_
        engine = create_engine(
            'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}'.format_map(connection_det))
        conn = engine.connect()

        # Bar Chart
        data_read_bar = pd.read_sql(
            """(select "validation_run_id", "Source_Name",
                case when "Result"='failed' then count("Result") end fail_cnt,
                case when "Result"='passed' then count("Result") end pass_cnt,
                case when  "Result"='error' then count("Result") end error_cnt
                from db_to_db_validation_output group by "Validation_Run_Id","Result", "Source_Name")""", conn)
        df = pd.DataFrame(data_read_bar)
        df1 = df.groupby("Validation_Run_Id").first().reset_index()
        fig_bar = px.bar(df1, x=df1["Source_Name"], y=[df1["error_cnt"], df1["fail_cnt"], df1["pass_cnt"]])
        graph1JSON_db2db = json.dumps(fig_bar, cls=plotly.utils.PlotlyJSONEncoder)

        # Pie Chart
        import plotly.graph_objects as go
        data_read_pie = pd.read_sql(
            """(select distinct("Source_Name"), count(distinct("Source_Name")) as count 
                from db_to_db_validation_output group by "Source_Name")""", conn)
        fig_pie = go.Figure(data=[go.Pie(labels=data_read_pie["Source_Name"], values=data_read_pie["count"])])
        graph2JSON_db2db = json.dumps(fig_pie, cls=plotly.utils.PlotlyJSONEncoder)
    except Exception as e:
        flash("DB2DB Exception", e)

    try:
        # F2DB
        data = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name=testresstorage
        ).with_entities(
            UserConnections.connection_details
        ).order_by(desc(UserConnections.updated_on)).limit(1).all()[0][0]
        connection_det = data.get('connection_details')
        table_names = [data.get('additional_details').get('table name').get('f2db')]

        from sqlalchemy import create_engine, MetaData, Table, select, and_
        engine = create_engine(
            'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}'.format_map(connection_det))
        conn = engine.connect()

        # Bar chart
        data_read_bar = pd.read_sql(
            """(select "validation_run_id", "Source_Name",
                case when "Result"='failed' then count("Result") end fail_cnt,
                case when "Result"='passed' then count("Result") end pass_cnt,
                case when  "Result"='error' then count("Result") end error_cnt
                from file_to_db_validation_output group by "validation_run_id","Result", "Source_Name")""", conn)
        df = pd.DataFrame(data_read_bar)
        df1 = df.groupby("validation_run_id").first().reset_index()
        df1["error_cnt"] = df1["error_cnt"].astype(float, errors='raise')
        fig_bar = px.bar(df1, x=df1["Source_Name"], y=[df1["error_cnt"], df1["fail_cnt"], df1["pass_cnt"]])
        graph1JSON_f2db = json.dumps(fig_bar, cls=plotly.utils.PlotlyJSONEncoder)

        # Pie Chart
        import plotly.graph_objects as go
        data_read_pie = pd.read_sql(
            """(select distinct("Source_Name"), count(distinct("Source_Name")) as count 
                from file_to_db_validation_output group by "Source_Name")""", conn)
        fig_pie = go.Figure(data=[go.Pie(labels=data_read_pie["Source_Name"], values=data_read_pie["count"])])
        graph2JSON_f2db = json.dumps(fig_pie, cls=plotly.utils.PlotlyJSONEncoder)
    except Exception as e:
        flash("F2DB Exception", e)

    try:
        # SFDC2DB
        data = UserConnections.query.filter_by(
            test_environment=env,
            stage=stage,
            connection_name=testresstorage
        ).with_entities(
            UserConnections.connection_details
        ).order_by(desc(UserConnections.updated_on)).limit(1).all()[0][0]
        connection_det = data.get('connection_details')
        table_names = [data.get('additional_details').get('table name').get('sfdc2db')]

        from sqlalchemy import create_engine, MetaData, Table, select, and_
        engine = create_engine(
            'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}'.format_map(connection_det))
        conn = engine.connect()

        # Bar Chart
        data_read_bar = pd.read_sql(
            """(select "App_ETL_Run_Id", "Source_Name",
                case when "Result"='failed' then count("Result") end fail_cnt,
                case when "Result"='passed' then count("Result") end pass_cnt,
                case when  "Result"='error' then count("Result") end error_cnt
                from sfdc_to_db_validation_output group by "App_ETL_Run_Id","Result", "Source_Name")""", conn)
        df = pd.DataFrame(data_read_bar)
        df1 = df.groupby("App_ETL_Run_Id").first().reset_index()
        df1["error_cnt"] = df1["error_cnt"].astype(float, errors='raise')
        # df1["fail_cnt"] = df1["fail_cnt"].astype(float, errors='raise')
        # df1["pass_cnt"] = df1["pass_cnt"].astype(float, errors='raise')
        fig_bar = px.bar(df1, x=df1["Source_Name"], y=[df1["error_cnt"], df1["fail_cnt"], df1["pass_cnt"]])
        graph1JSON_sfdc2db = json.dumps(fig_bar, cls=plotly.utils.PlotlyJSONEncoder)

        # Pie Chart
        import plotly.graph_objects as go
        data_read_pie = pd.read_sql(
            """(select distinct("Source_Name"), count(distinct("Source_Name")) as count 
                from sfdc_to_db_validation_output group by "Source_Name")""", conn)
        fig_pie = go.Figure(data=[go.Pie(labels=data_read_pie["Source_Name"], values=data_read_pie["count"])])
        graph2JSON_sfdc2db = json.dumps(fig_pie, cls=plotly.utils.PlotlyJSONEncoder)
    except Exception as e:
        flash("SFDC Exception", e)
    return render_template("dashboard/final_dashboard.html",
                           graph1JSON_db2db=graph1JSON_db2db,
                           graph2JSON_db2db=graph2JSON_db2db,
                           graph1JSON_f2db=graph1JSON_f2db,
                           graph2JSON_f2db=graph2JSON_f2db,
                           graph1JSON_sfdc2db=graph1JSON_sfdc2db,
                           graph2JSON_sfdc2db=graph2JSON_sfdc2db,
                           )
