import json
from pathlib import Path

from globals.fileloader import SingleFileLoader
from globals.constants import *
from flask.views import MethodView
from utils.defaults import validate_request
from configuration.forms import *
from execution.forms import *
from flask import flash, render_template, redirect, url_for, g, request, session
from configuration.models import TestLog, UserConnections, Services
from configuration.models import *
from utils.platforms.onprem import MinIO
from utils.serviceprovider import sp
from datetime import datetime
from utils.objectfactory import ob
from utils.orchestrator.orchestrate import test_script_auto_run_dag, test_script_standard_dag


class TestScriptLoader(MethodView, SingleFileLoader):
    def __init__(self) -> None:
        super().__init__()
        self.connection_name = None
        self.con = None
        self.resource_key = None
        self.file = None
        self.metadata_config = None

    decorators = [validate_request]

    def get(self):
        if request.args:
            return self.process_args()
        form = SingleFileUploadForm()
        generate_script = SingleButtonForm()
        generate_script.submit(value="Generate Test Script")
        env = g.current_env
        stg = g.current_stage
        ldata = []
        all_buckets = []
        data = []
        testscriptsnames1 = set()
        pipeline_names = []
        try:
            data = TestLog.get_log(dict(
                stage=stg,
                environment=env,
                document_type='Manual Test Script'
            ))
            data.extend(TestLog.get_log(dict(
                stage=stg,
                environment=env,
                document_type="Automated Test Script"
            )))

            # SFDC
            path = "Unit Testing/Data Ingestion/Automated Test Script"
            ldata = MinIO.download(path)
            # SFDC ends..

            connection_name = testdocstorage
            script_path_list = TestLog.query.filter(
                TestLog.document_path.like("%Mapping Sheet%")).distinct(
                TestLog.document_path).all()
            service = sp(connection_name)

            all_test_scripts = []
            for row in script_path_list:
                path = Path(row.document_path)
                mapping_listedfiles = service.mapping_listedfiles(path)
                for file in mapping_listedfiles:
                    all_test_scripts.append([path, file])
            testscriptsnames = [testscripts[1] for testscripts in all_test_scripts]
            testscriptsnames1 = set(testscriptsnames)

            # get all buckets names and their objects from Minio
            all_buckets = MinIO.all_buckets()
        except Exception as e:
            flash("Something went wrong! Unable to connect to Storage Service.")
        try:
            pipeline_names = user_connection_db2db.query.distinct(
                user_connection_db2db.pipeline_name).with_entities(
                user_connection_db2db.pipeline_name).all()
            # db2db_pipelineNames = user_connection_db2db.query.with_entities(user_connection_db2db.pipeline_name).all()
        except Exception as e:
            flash("Unable to fetch Pipeline names: \"" + str(e) + "\"")

        return render_template(
            'accelerators/test-script-generator.html',
            m_form=form,
            g_form=generate_script,
            a_form=form,
            data=data,
            ldata=ldata,
            new_form=form,
            testscriptsnames1=testscriptsnames1,
            all_buckets=all_buckets,
            pipeline_names=pipeline_names
        )

    def process_args(self):
        val = request.args.get('val')
        data = request.args.get('data')
        if val == 'minio_buckets':
            session['minio_buckets'] = data
            bucket_objects = MinIO.all_objects(data)
            print("b..........", bucket_objects)
            return json.dumps(bucket_objects)
        else:
            bucket_name = session.get('minio_buckets')
            dot_data = data.find(".")
            bucket_objects = MinIO.all_objects_prefix(bucket_name, data)
            print("b..........", bucket_objects)
            return json.dumps(bucket_objects)

    def generate_test_scripts(self):
        try:
            metadata_config = TestLog.get_log(dict(
                stage=g.current_stage,
                environment=g.current_env,
                document_name="configuration_file.json"
            ))[0]
        except Exception as e:
            message = 'Configuration file may not be uploaded. Please check.'
            message = str(e)
        else:
            conf = dict(
                resource_key=self.resource_key,
                config_path=metadata_config.document_path
            )
            orch = ob.create(dags)
            orch(val_type='gen-script', conf=conf)
            message = orch.run_dag()
        finally:
            return message

    def post(self):
        data = request.form.to_dict()
        form_name = data['identifier']

        if form_name == 'ts_form':
            try:
                input_format = data['input_format']
                resource_key = data['storage_platform']
                output_format = data['output_format']
                output_path = data['output_path']
                mapping_sheet = data['mapping_sheet']
                output_template_file = "Unit Testing/Data Ingestion/Test_Docs/QueryOutputTemplate_updated.csv"
                source_db_name = data['source_db_name']
                target_db_name = data['target_db_name']
                message = test_script_auto_run_dag(input_format, resource_key,
                                                   output_format, output_path, mapping_sheet, output_template_file,
                                                   source_db_name, target_db_name)
            except Exception as e:
                flash("Unable to create automatic testscript. The error is:  \"" + str(e) + "\"")
        elif form_name == 'standard_ts_form':
            try:
                pipeline_type = data['pipeline_type']
                pipeline_name = data['pipeline_name']
                output_path = data['output_path']
                mapping_sheet = data['mapping_sheet']
                source_conn_details = user_connection_db2db.query.filter_by(
                    pipeline_name=pipeline_name,
                    connection_name=db2dbsrcconf).with_entities(
                    user_connection_db2db.connection_details).order_by(
                    desc(user_connection_db2db.updated_on)).first()
                target_conn_details = user_connection_db2db.query.filter_by(
                    pipeline_name=pipeline_name,
                    connection_name=db2dbtgtconf).with_entities(
                    user_connection_db2db.connection_details).order_by(
                    desc(user_connection_db2db.updated_on)).first()
                metadata_conn_details = UserConnections.query.filter_by(
                    connection_name=metadatastorage).with_entities(
                    UserConnections.connection_details).order_by(
                    desc(UserConnections.updated_on)).first()
                message = test_script_standard_dag(pipeline_type, pipeline_name, output_path, mapping_sheet,
                                                   source_conn_details, target_conn_details, metadata_conn_details)
            except Exception as e:
                flash("Unable to create standard testscript. The error is:  \"" + str(e) + "\"")

        else:
            self.connection_name = testdocstorage
            location = UserConnections.get_connection(self.connection_name, filter_by=dict(
                test_environment=g.current_env,
                stage=g.current_stage
            ))
            # emp_id=g.current_user,
            if not location:
                message = 'Location to upload Test Scripts not configured. \
                            Please configure Pre-requisite Document Storage in Configure Application \
                            to proceed further'
            else:
                self.con = self.parse_connection_details(location)
                self.resource_key = Services.get_resource_key(location.service)
                if request.files:
                    self.connection_name = testdocstorage
                    response = self.save()
                else:
                    # for generate scripts
                    response = self.generate_test_scripts()
                message = response
        flash(message)
        return redirect(url_for('execution.test_script_gen'))

    # @staticmethod
    # def filetransfer(u_file, mes, per_filename, d_type):
    #     ext= per_filename.split(".")[-1]
    #     key= session['environment']+"/"+session['stage']+"/"+mes+"/"+per_filename
    #     data= UserConnections.query.filter_by(
    #         stage=session['stage'],
    #         test_environment=session['environment'],
    #         connection_name= "TestDoc Storage Configuration"
    #     ).order_by(desc('updated_on')).first()
    #     service = Services.query.filter_by(service_name=data.service).with_entities(Services.resource_key).first()[0]
    #     # test code    
    #     store = ob.create(data.platform, service=service).service()
    #     buck= data.connection_details
    #     bucke= buck.get('connection_details')['bucket']
    #     res = store.upload(u_file=u_file, mes=mes, per_filename=per_filename, bucke=bucke)
    #     db = dbf_obj.get_dbase()
    #     addtest= TestLog(username= session['user'], environment= session['environment'], stage= session['stage'], time_stamp= datetime.now(), document_type= d_type,document_link= res, document_name=key, document_path='s3://'+bucke+'/'+key)
    #     db.session.add(addtest)
    #     db.session.commit()
